"use client"
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip"
import { Info } from "lucide-react"
import { getBillingMethod } from "@/lib/constants"

interface TamilNaduBillingInfoProps {
  region: string
  className?: string
}

export function TamilNaduBillingInfo({ region, className = "" }: TamilNaduBillingInfoProps) {
  const billingMethod = getBillingMethod(region)
  const isTamilNadu = region === "Tamil Nadu"

  if (!isTamilNadu) return null

  return (
    <div className={`card-modern bg-primary-green-light border-green-200 p-6 ${className}`}>
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center space-x-3">
          <span className="text-2xl">🎯</span>
          <h4 className="text-lg font-semibold text-green-800">Tamil Nadu LT-1 Proportional Billing</h4>
        </div>
        <TooltipProvider>
          <Tooltip>
            <TooltipTrigger asChild>
              <div className="cursor-help p-2 hover:bg-green-100 rounded-lg transition-colors">
                <Info className="h-5 w-5 text-green-600" />
              </div>
            </TooltipTrigger>
            <TooltipContent side="left" className="max-w-xs">
              <p>{billingMethod.tooltip}</p>
            </TooltipContent>
          </Tooltip>
        </TooltipProvider>
      </div>

      <p className="text-green-700 mb-4 leading-relaxed">
        Total electricity usage is calculated using official TANGEDCO slab rates, then distributed proportionally across
        all appliances based on their consumption share.
      </p>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <div className="bg-white p-3 rounded-lg border border-green-100 hover:shadow-sm transition-shadow">
          <div className="font-semibold text-green-800 text-sm">0-100 units</div>
          <div className="text-green-600 font-bold">Free</div>
        </div>
        <div className="bg-white p-3 rounded-lg border border-green-100 hover:shadow-sm transition-shadow">
          <div className="font-semibold text-green-800 text-sm">101-200</div>
          <div className="text-green-600 font-bold">₹2.5/unit</div>
        </div>
        <div className="bg-white p-3 rounded-lg border border-green-100 hover:shadow-sm transition-shadow">
          <div className="font-semibold text-green-800 text-sm">201-400</div>
          <div className="text-green-600 font-bold">₹4.5/unit</div>
        </div>
        <div className="bg-white p-3 rounded-lg border border-green-100 hover:shadow-sm transition-shadow">
          <div className="font-semibold text-green-800 text-sm">401-500</div>
          <div className="text-green-600 font-bold">₹5.5/unit</div>
        </div>
      </div>
    </div>
  )
}
