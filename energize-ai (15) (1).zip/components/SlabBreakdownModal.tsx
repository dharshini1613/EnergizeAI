"use client"

import { useState } from "react"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Calculator, Eye } from "lucide-react"
import { getTamilNaduSlabBreakdown, formatExactCurrency } from "@/lib/constants"

interface SlabBreakdownModalProps {
  units: number
  totalCost: number
}

export function SlabBreakdownModal({ units, totalCost }: SlabBreakdownModalProps) {
  const [open, setOpen] = useState(false)
  const breakdown = getTamilNaduSlabBreakdown(units)

  if (breakdown.length === 0) return null

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button variant="outline" size="sm" className="text-xs">
          <Eye className="h-3 w-3 mr-1" />
          View Breakdown
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center space-x-2">
            <Calculator className="h-5 w-5 text-green-600" />
            <span>Tamil Nadu Slab Breakdown</span>
          </DialogTitle>
          <DialogDescription>
            Detailed calculation for {units.toFixed(1)} units using TANGEDCO LT-1 rates
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Slab Range</TableHead>
                <TableHead>Units</TableHead>
                <TableHead>Rate</TableHead>
                <TableHead>Cost</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {breakdown.map((slab, index) => (
                <TableRow key={index}>
                  <TableCell className="font-medium">{slab.range}</TableCell>
                  <TableCell>{slab.units.toFixed(1)}</TableCell>
                  <TableCell>
                    {slab.isFree ? (
                      <Badge variant="default" className="bg-green-100 text-green-800">
                        Free
                      </Badge>
                    ) : (
                      `₹${slab.rate}/unit`
                    )}
                  </TableCell>
                  <TableCell className="font-semibold">{slab.isFree ? "₹0" : formatExactCurrency(slab.cost)}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>

          <div className="bg-green-50 p-3 rounded-lg border border-green-200">
            <div className="flex items-center justify-between">
              <span className="font-medium text-green-800">Total Bill:</span>
              <span className="text-lg font-bold text-green-800">{formatExactCurrency(totalCost)}</span>
            </div>
            <p className="text-xs text-green-600 mt-1">Based on official TANGEDCO LT-1 Domestic Consumer rates</p>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  )
}
