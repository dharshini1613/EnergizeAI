"use client"

import { AlertCircle, RefreshCw, ExternalLink } from "lucide-react"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { Button } from "@/components/ui/button"

interface ErrorAlertProps {
  title: string
  description: string
  action?: string
  onRetry?: () => void
  onAction?: () => void
  className?: string
}

export function ErrorAlert({ title, description, action, onRetry, onAction, className }: ErrorAlertProps) {
  return (
    <Alert variant="destructive" className={className}>
      <AlertCircle className="h-4 w-4" />
      <AlertTitle className="font-semibold">{title}</AlertTitle>
      <AlertDescription className="mt-2">
        <p className="mb-3">{description}</p>
        <div className="flex gap-2">
          {onRetry && (
            <Button variant="outline" size="sm" onClick={onRetry} className="h-8">
              <RefreshCw className="h-3 w-3 mr-1" />
              Try Again
            </Button>
          )}
          {onAction && action && (
            <Button variant="outline" size="sm" onClick={onAction} className="h-8">
              <ExternalLink className="h-3 w-3 mr-1" />
              {action}
            </Button>
          )}
        </div>
      </AlertDescription>
    </Alert>
  )
}
