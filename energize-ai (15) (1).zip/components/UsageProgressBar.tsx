"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { Badge } from "@/components/ui/badge"
import { Target, TrendingUp, TrendingDown, AlertTriangle } from "lucide-react"
import { formatExactCurrency } from "@/lib/constants"

interface UsageProgressBarProps {
  currentUsage: number
  currentCost: number
  goalUsage?: number
  goalBudget?: number
  className?: string
}

export function UsageProgressBar({
  currentUsage,
  currentCost,
  goalUsage = 400,
  goalBudget = 2000,
  className = "",
}: UsageProgressBarProps) {
  const usagePercentage = Math.min((currentUsage / goalUsage) * 100, 100)
  const budgetPercentage = Math.min((currentCost / goalBudget) * 100, 100)

  const isUsageOverGoal = currentUsage > goalUsage
  const isBudgetOverGoal = currentCost > goalBudget

  const getStatusColor = (percentage: number, isOver: boolean) => {
    if (isOver) return "red"
    if (percentage > 80) return "orange"
    if (percentage > 60) return "yellow"
    return "green"
  }

  const usageStatusColor = getStatusColor(usagePercentage, isUsageOverGoal)
  const budgetStatusColor = getStatusColor(budgetPercentage, isBudgetOverGoal)

  return (
    <Card className={`card-modern ${className}`}>
      <CardHeader>
        <CardTitle className="flex items-center space-x-2 text-xl">
          <Target className="h-6 w-6 text-blue-600" />
          <span>Monthly Goals Progress</span>
        </CardTitle>
        <CardDescription>Track your usage against monthly targets</CardDescription>
      </CardHeader>

      <CardContent className="space-y-6">
        {/* Usage Progress */}
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <span className="font-medium text-gray-900">Energy Usage</span>
              <Badge
                className={`${
                  usageStatusColor === "green"
                    ? "bg-green-100 text-green-800 border-green-200"
                    : usageStatusColor === "yellow"
                      ? "bg-yellow-100 text-yellow-800 border-yellow-200"
                      : usageStatusColor === "orange"
                        ? "bg-orange-100 text-orange-800 border-orange-200"
                        : "bg-red-100 text-red-800 border-red-200"
                }`}
              >
                {isUsageOverGoal ? (
                  <>
                    <AlertTriangle className="h-3 w-3 mr-1" />
                    Over Goal
                  </>
                ) : usagePercentage > 80 ? (
                  <>
                    <TrendingUp className="h-3 w-3 mr-1" />
                    High
                  </>
                ) : (
                  <>
                    <TrendingDown className="h-3 w-3 mr-1" />
                    Good
                  </>
                )}
              </Badge>
            </div>
            <div className="text-right">
              <div className="font-semibold text-gray-900">
                {currentUsage.toFixed(1)} / {goalUsage} kWh
              </div>
              <div className="text-sm text-gray-600">
                {isUsageOverGoal ? "+" : ""}
                {(currentUsage - goalUsage).toFixed(1)} kWh
              </div>
            </div>
          </div>

          <div className="space-y-2">
            <Progress value={Math.min(usagePercentage, 100)} className="h-3" />
            <div className="flex justify-between text-xs text-gray-600">
              <span>0 kWh</span>
              <span className="font-medium">{usagePercentage.toFixed(1)}%</span>
              <span>{goalUsage} kWh</span>
            </div>
          </div>
        </div>

        {/* Budget Progress */}
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <span className="font-medium text-gray-900">Budget</span>
              <Badge
                className={`${
                  budgetStatusColor === "green"
                    ? "bg-green-100 text-green-800 border-green-200"
                    : budgetStatusColor === "yellow"
                      ? "bg-yellow-100 text-yellow-800 border-yellow-200"
                      : budgetStatusColor === "orange"
                        ? "bg-orange-100 text-orange-800 border-orange-200"
                        : "bg-red-100 text-red-800 border-red-200"
                }`}
              >
                {isBudgetOverGoal ? (
                  <>
                    <AlertTriangle className="h-3 w-3 mr-1" />
                    Over Budget
                  </>
                ) : budgetPercentage > 80 ? (
                  <>
                    <TrendingUp className="h-3 w-3 mr-1" />
                    High
                  </>
                ) : (
                  <>
                    <TrendingDown className="h-3 w-3 mr-1" />
                    Good
                  </>
                )}
              </Badge>
            </div>
            <div className="text-right">
              <div className="font-semibold text-gray-900">
                {formatExactCurrency(currentCost)} / {formatExactCurrency(goalBudget)}
              </div>
              <div className="text-sm text-gray-600">
                {isBudgetOverGoal ? "+" : ""}
                {formatExactCurrency(currentCost - goalBudget)}
              </div>
            </div>
          </div>

          <div className="space-y-2">
            <Progress value={Math.min(budgetPercentage, 100)} className="h-3" />
            <div className="flex justify-between text-xs text-gray-600">
              <span>₹0</span>
              <span className="font-medium">{budgetPercentage.toFixed(1)}%</span>
              <span>{formatExactCurrency(goalBudget)}</span>
            </div>
          </div>
        </div>

        {/* Recommendations */}
        <div
          className={`p-4 rounded-lg border ${
            isUsageOverGoal || isBudgetOverGoal
              ? "bg-red-50 border-red-200"
              : usagePercentage > 80 || budgetPercentage > 80
                ? "bg-yellow-50 border-yellow-200"
                : "bg-green-50 border-green-200"
          }`}
        >
          <div className="text-sm font-medium mb-1">
            {isUsageOverGoal || isBudgetOverGoal
              ? "⚠️ Action Needed"
              : usagePercentage > 80 || budgetPercentage > 80
                ? "⚡ Watch Usage"
                : "✅ Great Job!"}
          </div>
          <div className="text-sm">
            {isUsageOverGoal || isBudgetOverGoal
              ? "You've exceeded your monthly goals. Consider reducing high-consumption appliances."
              : usagePercentage > 80 || budgetPercentage > 80
                ? "You're approaching your monthly limits. Monitor usage closely."
                : "You're on track to meet your monthly goals. Keep up the good work!"}
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
