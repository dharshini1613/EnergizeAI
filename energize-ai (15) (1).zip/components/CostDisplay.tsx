"use client"

import { Badge } from "@/components/ui/badge"
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip"
import { formatCurrency, formatExactCurrency, getBillingMethod, isSlabBasedRegion } from "@/lib/constants"
import { SlabBreakdownModal } from "./SlabBreakdownModal"

interface CostDisplayProps {
  amount: number
  region: string
  label?: string
  showBadge?: boolean
  className?: string
  exact?: boolean
  units?: number // Add this for slab breakdown
}

export function CostDisplay({
  amount,
  region,
  label,
  showBadge = true,
  className = "",
  exact = false,
  units = 0,
}: CostDisplayProps) {
  const billingMethod = getBillingMethod(region)
  const isTamilNadu = isSlabBasedRegion(region)
  const tooltipMessage = isTamilNadu
    ? "Cost calculated using Tamil Nadu's official LT-1 slab rates applied proportionally"
    : billingMethod.tooltip

  return (
    <TooltipProvider>
      <div className={`flex items-center space-x-3 ${className}`}>
        <Tooltip>
          <TooltipTrigger asChild>
            <div className="cursor-help">
              <div className="text-2xl font-bold text-primary-green">
                {exact ? formatExactCurrency(amount) : formatCurrency(amount)}
              </div>
              {label && <div className="text-sm text-gray-600">{label}</div>}
            </div>
          </TooltipTrigger>
          <TooltipContent side="top" className="max-w-xs bg-white border border-gray-200 shadow-lg">
            <div className="space-y-2">
              <p className="font-medium text-gray-900">
                {isTamilNadu ? "Tamil Nadu LT-1 Proportional Billing" : "Standard Rate Billing"}
              </p>
              <p className="text-xs text-gray-700">{tooltipMessage}</p>
            </div>
          </TooltipContent>
        </Tooltip>

        <div className="flex flex-col items-end space-y-1">
          {showBadge && (
            <Badge
              variant={isTamilNadu ? "default" : "secondary"}
              className={`text-xs transition-all duration-300 ${
                isTamilNadu
                  ? "bg-primary-green-light text-green-800 border-green-200 hover:bg-green-100"
                  : "bg-gray-100 text-gray-700 border-gray-200"
              }`}
            >
              {billingMethod.badge}
            </Badge>
          )}

          {/* Show slab breakdown for Tamil Nadu */}
          {isTamilNadu && units > 0 && <SlabBreakdownModal units={units} totalCost={amount} />}
        </div>
      </div>
    </TooltipProvider>
  )
}
