"use client"

import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip } from "recharts"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Zap, TrendingUp, Info } from "lucide-react"
import {
  formatCurrency,
  formatExactCurrency,
  calculateTamilNaduApplianceCosts,
  isSlabBasedRegion,
} from "@/lib/constants"
import type { Appliance } from "@/lib/types"
import { useState, useEffect } from "react"
import { fetchUserSettings } from "@/lib/utils"

interface ApplianceBreakdownProps {
  appliances: Appliance[]
}

const COLORS = ["#ef4444", "#f97316", "#eab308", "#22c55e", "#3b82f6", "#8b5cf6", "#ec4899", "#6b7280"]

export function ApplianceBreakdown({ appliances }: ApplianceBreakdownProps) {
  const [settings, setSettings] = useState<any>(null)
  const [processedData, setProcessedData] = useState<any>(null)

  useEffect(() => {
    fetchUserSettings().then(setSettings)
  }, [])

  useEffect(() => {
    if (settings && appliances.length > 0) {
      if (isSlabBasedRegion(settings.region)) {
        const result = calculateTamilNaduApplianceCosts(appliances)
        setProcessedData(result)
      } else {
        // Standard calculation for other regions
        const processed = appliances.map((appliance) => ({
          ...appliance,
          monthlyKwh: (appliance.power * appliance.hoursPerDay * appliance.daysPerMonth) / 1000,
          monthlyCost:
            (appliance.power * appliance.hoursPerDay * appliance.daysPerMonth * settings.electricityRate) / 1000,
        }))
        setProcessedData({
          appliances: processed,
          totalMonthlyKwh: processed.reduce((sum, app) => sum + app.monthlyKwh, 0),
          totalMonthlyCost: processed.reduce((sum, app) => sum + app.monthlyCost, 0),
        })
      }
    }
  }, [settings, appliances])

  if (appliances.length === 0) {
    return (
      <Card className="card-modern">
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Zap className="h-5 w-5 text-orange-600" />
            <span>Appliance Breakdown</span>
          </CardTitle>
          <CardDescription>Add appliances to see cost breakdown</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="text-center py-8 text-gray-500">
            <Zap className="h-12 w-12 text-gray-300 mx-auto mb-3" />
            <p>No appliances added yet</p>
          </div>
        </CardContent>
      </Card>
    )
  }

  if (!processedData) {
    return (
      <Card className="card-modern">
        <CardContent className="p-8">
          <div className="text-center">Loading appliance data...</div>
        </CardContent>
      </Card>
    )
  }

  // Prepare data for pie chart
  const chartData = processedData.appliances.map((appliance: any, index: number) => ({
    name: appliance.name,
    value: appliance.monthlyCost,
    percentage: (appliance.monthlyCost / processedData.totalMonthlyCost) * 100,
    color: COLORS[index % COLORS.length],
    kwh: appliance.monthlyKwh,
  }))

  const CustomTooltip = ({ active, payload }: any) => {
    if (active && payload && payload.length) {
      const data = payload[0].payload
      return (
        <div className="bg-white p-3 border border-gray-200 rounded-lg shadow-lg">
          <p className="font-medium capitalize">{data.name}</p>
          <p className="text-green-600">Cost: {formatExactCurrency(data.value)}/month</p>
          <p className="text-blue-600">Usage: {data.kwh.toFixed(1)} kWh</p>
          <p className="text-purple-600">Share: {data.percentage.toFixed(1)}%</p>
        </div>
      )
    }
    return null
  }

  const topAppliances = [...processedData.appliances].sort((a, b) => b.monthlyCost - a.monthlyCost).slice(0, 5)

  return (
    <div className="space-y-6">
      {/* Tamil Nadu Billing Alert */}
      {settings && isSlabBasedRegion(settings.region) && (
        <Alert className="card-modern border-green-200 bg-green-50">
          <Info className="h-4 w-4 text-green-600" />
          <AlertDescription className="text-green-800">
            <strong>Tamil Nadu LT-1 Slab Billing Applied:</strong> Total consumption of{" "}
            {processedData.totalMonthlyKwh.toFixed(1)} kWh costs {formatExactCurrency(processedData.totalMonthlyCost)}{" "}
            using official slab rates. Costs below are distributed proportionally based on each appliance's consumption
            share.
          </AlertDescription>
        </Alert>
      )}

      {/* Pie Chart */}
      <Card className="card-modern">
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Zap className="h-5 w-5 text-orange-600" />
            <span>Monthly Cost Breakdown</span>
            {settings && isSlabBasedRegion(settings.region) && (
              <Badge className="bg-green-100 text-green-800 border-green-200">TN Slab-Based</Badge>
            )}
          </CardTitle>
          <CardDescription>
            {settings && isSlabBasedRegion(settings.region)
              ? `Proportional distribution of ${formatExactCurrency(processedData.totalMonthlyCost)} total bill`
              : "Which appliances cost you the most"}
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={chartData}
                  cx="50%"
                  cy="50%"
                  outerRadius={80}
                  fill="#8884d8"
                  dataKey="value"
                  label={({ percentage }) => `${percentage.toFixed(0)}%`}
                >
                  {chartData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip content={<CustomTooltip />} />
              </PieChart>
            </ResponsiveContainer>
          </div>

          <div className="mt-4 grid grid-cols-2 gap-2">
            {chartData.slice(0, 6).map((item, index) => (
              <div key={index} className="flex items-center space-x-2 text-sm">
                <div className="w-3 h-3 rounded-full" style={{ backgroundColor: item.color }}></div>
                <span className="capitalize truncate">{item.name}</span>
                <span className="text-gray-600">{formatCurrency(item.value)}</span>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Top Appliances List */}
      <Card className="card-modern">
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <TrendingUp className="h-5 w-5 text-red-600" />
            <span>Highest Cost Appliances</span>
          </CardTitle>
          <CardDescription>
            {settings && isSlabBasedRegion(settings.region)
              ? "Your biggest opportunities to save money (based on proportional share)"
              : "Your biggest opportunities to save money"}
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {topAppliances.map((appliance, index) => {
              const savingsPerHour = appliance.monthlyCost * (1 / appliance.hoursPerDay) // Proportional savings
              return (
                <div
                  key={appliance.id}
                  className="flex items-center justify-between p-4 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors"
                >
                  <div className="flex items-center space-x-3">
                    <div
                      className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold ${
                        index === 0
                          ? "bg-red-100 text-red-800"
                          : index === 1
                            ? "bg-orange-100 text-orange-800"
                            : index === 2
                              ? "bg-yellow-100 text-yellow-800"
                              : "bg-gray-100 text-gray-800"
                      }`}
                    >
                      #{index + 1}
                    </div>
                    <div>
                      <h4 className="font-medium capitalize">{appliance.name}</h4>
                      <p className="text-sm text-gray-600">
                        {appliance.power}W • {appliance.hoursPerDay}h/day • {appliance.monthlyKwh.toFixed(1)} kWh/month
                      </p>
                      {settings && isSlabBasedRegion(settings.region) && appliance.proportionalShare && (
                        <p className="text-xs text-green-600">
                          {appliance.proportionalShare.toFixed(1)}% of total consumption
                        </p>
                      )}
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="font-bold text-green-600">{formatCurrency(appliance.monthlyCost)}/month</div>
                    <div className="text-xs text-gray-600">
                      Save {formatCurrency(savingsPerHour)}/month per hour reduced
                    </div>
                    {appliance.monthlyCost > 500 && (
                      <Badge variant="destructive" className="text-xs mt-1">
                        High Cost
                      </Badge>
                    )}
                  </div>
                </div>
              )
            })}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
