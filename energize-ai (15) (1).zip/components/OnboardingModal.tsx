"use client"

import { useState } from "react"
import { motion, AnimatePresence } from "framer-motion"
import { useForm } from "react-hook-form"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Zap, Target, MapPin, CheckCircle } from "lucide-react"
import { REGIONAL_RATES } from "@/lib/constants"
import { saveUserSettings } from "@/lib/utils"
import { trackOnboardingComplete, trackBudgetSet } from "@/lib/analytics"
import type { UserSettings } from "@/lib/types"

interface OnboardingModalProps {
  isOpen: boolean
  onComplete: (settings: UserSettings) => void
}

export function OnboardingModal({ isOpen, onComplete }: OnboardingModalProps) {
  const [step, setStep] = useState(1)
  const [loading, setLoading] = useState(false)

  const form = useForm<UserSettings>({
    defaultValues: {
      name: "",
      monthlyBudget: 3000,
      electricityRate: 8,
      region: "Other",
      onboardingComplete: false,
    },
  })

  const handleRegionChange = (region: string) => {
    form.setValue("region", region)
    if (region in REGIONAL_RATES) {
      form.setValue("electricityRate", REGIONAL_RATES[region as keyof typeof REGIONAL_RATES])
    }
  }

  const nextStep = () => {
    if (step < 3) setStep(step + 1)
  }

  const prevStep = () => {
    if (step > 1) setStep(step - 1)
  }

  const onSubmit = async (data: UserSettings) => {
    setLoading(true)
    try {
      const settings = { ...data, onboardingComplete: true }
      await saveUserSettings(settings)
      trackOnboardingComplete()
      trackBudgetSet(data.monthlyBudget)
      onComplete(settings)
    } catch (error) {
      console.error("Error saving settings:", error)
    } finally {
      setLoading(false)
    }
  }

  return (
    <Dialog open={isOpen} onOpenChange={() => {}}>
      <DialogContent className="sm:max-w-md" hideCloseButton>
        <DialogHeader>
          <DialogTitle className="flex items-center space-x-2">
            <Zap className="h-6 w-6 text-green-600" />
            <span>Welcome to EnergizeAI!</span>
          </DialogTitle>
          <DialogDescription>Let's set up your personalized electricity tracking in just 3 steps.</DialogDescription>
        </DialogHeader>

        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
          <AnimatePresence mode="wait">
            {step === 1 && (
              <motion.div
                key="step1"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="space-y-4"
              >
                <div className="text-center">
                  <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                    <span className="text-2xl">👋</span>
                  </div>
                  <h3 className="text-lg font-semibold">Nice to meet you!</h3>
                  <p className="text-gray-600">What should we call you?</p>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="name">Your Name (Optional)</Label>
                  <Input id="name" placeholder="e.g., Rajesh Kumar" {...form.register("name")} className="w-full" />
                </div>

                <Button type="button" onClick={nextStep} className="w-full">
                  Continue
                </Button>
              </motion.div>
            )}

            {step === 2 && (
              <motion.div
                key="step2"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="space-y-4"
              >
                <div className="text-center">
                  <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                    <MapPin className="h-8 w-8 text-green-600" />
                  </div>
                  <h3 className="text-lg font-semibold">Where are you located?</h3>
                  <p className="text-gray-600">This helps us set the right electricity rate</p>
                </div>

                <div className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="region">Your State/Region</Label>
                    <Select onValueChange={handleRegionChange} value={form.watch("region")}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select your state" />
                      </SelectTrigger>
                      <SelectContent>
                        {Object.entries(REGIONAL_RATES).map(([state, rate]) => (
                          <SelectItem key={state} value={state}>
                            {state} - ₹{rate}/kWh
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="electricityRate">Electricity Rate (₹/kWh)</Label>
                    <Input
                      id="electricityRate"
                      type="number"
                      step="0.1"
                      {...form.register("electricityRate", { valueAsNumber: true })}
                      className="w-full"
                    />
                    <p className="text-xs text-gray-600">Check your electricity bill for the exact rate</p>
                  </div>
                </div>

                <div className="flex space-x-2">
                  <Button type="button" variant="outline" onClick={prevStep} className="flex-1">
                    Back
                  </Button>
                  <Button type="button" onClick={nextStep} className="flex-1">
                    Continue
                  </Button>
                </div>
              </motion.div>
            )}

            {step === 3 && (
              <motion.div
                key="step3"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="space-y-4"
              >
                <div className="text-center">
                  <div className="w-16 h-16 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-4">
                    <Target className="h-8 w-8 text-purple-600" />
                  </div>
                  <h3 className="text-lg font-semibold">Set your monthly budget</h3>
                  <p className="text-gray-600">We'll help you stay on track and save money</p>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="monthlyBudget">Monthly Electricity Budget (₹)</Label>
                  <Input
                    id="monthlyBudget"
                    type="number"
                    placeholder="e.g., 3000"
                    {...form.register("monthlyBudget", { valueAsNumber: true })}
                    className="w-full"
                  />
                  <p className="text-xs text-gray-600">
                    Daily budget: ₹{Math.round((form.watch("monthlyBudget") || 3000) / 30)}
                  </p>
                </div>

                <div className="bg-blue-50 p-4 rounded-lg border border-blue-200">
                  <h4 className="font-medium text-blue-800 mb-2">💡 What happens next:</h4>
                  <ul className="text-sm text-blue-700 space-y-1">
                    <li>• Track daily usage against your budget</li>
                    <li>• Get alerts when you exceed limits</li>
                    <li>• Receive personalized saving tips</li>
                    <li>• Monitor appliance costs</li>
                  </ul>
                </div>

                <div className="flex space-x-2">
                  <Button type="button" variant="outline" onClick={prevStep} className="flex-1">
                    Back
                  </Button>
                  <Button type="submit" disabled={loading} className="flex-1 bg-green-600 hover:bg-green-700">
                    {loading ? (
                      "Setting up..."
                    ) : (
                      <>
                        <CheckCircle className="h-4 w-4 mr-2" />
                        Get Started
                      </>
                    )}
                  </Button>
                </div>
              </motion.div>
            )}
          </AnimatePresence>

          {/* Progress indicator */}
          <div className="flex justify-center space-x-2">
            {[1, 2, 3].map((i) => (
              <div key={i} className={`w-2 h-2 rounded-full ${i <= step ? "bg-green-600" : "bg-gray-300"}`} />
            ))}
          </div>
        </form>
      </DialogContent>
    </Dialog>
  )
}
