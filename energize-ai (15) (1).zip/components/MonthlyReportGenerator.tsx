"use client"

import { useState } from "react"
import { motion } from "framer-motion"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { FileText, Download, Calendar, Zap, Target } from "lucide-react"
import { formatCurrency, formatExactCurrency } from "@/lib/constants"
import { generateMonthlyReport } from "@/lib/utils"
import { trackReportGenerated } from "@/lib/analytics"
import type { MeterReading, Appliance, UserSettings, MonthlyReport } from "@/lib/types"

interface MonthlyReportGeneratorProps {
  readings: MeterReading[]
  appliances: Appliance[]
  settings: UserSettings
}

export function MonthlyReportGenerator({ readings, appliances, settings }: MonthlyReportGeneratorProps) {
  const [generating, setGenerating] = useState(false)
  const [report, setReport] = useState<MonthlyReport | null>(null)

  const generateReport = async () => {
    setGenerating(true)
    try {
      const monthlyReport = generateMonthlyReport(readings, appliances, settings)
      setReport(monthlyReport)
      trackReportGenerated("monthly")
    } catch (error) {
      console.error("Error generating report:", error)
    } finally {
      setGenerating(false)
    }
  }

  const downloadPDF = () => {
    if (!report) return

    // Create HTML content for PDF
    const htmlContent = `
      <!DOCTYPE html>
      <html>
      <head>
        <title>EnergizeAI Monthly Report - ${report.month} ${report.year}</title>
        <style>
          body { font-family: Arial, sans-serif; margin: 20px; color: #333; }
          .header { text-align: center; margin-bottom: 30px; border-bottom: 2px solid #10b981; padding-bottom: 20px; }
          .logo { color: #10b981; font-size: 24px; font-weight: bold; }
          .summary { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 20px; margin: 20px 0; }
          .summary-card { background: #f8fafc; padding: 15px; border-radius: 8px; border-left: 4px solid #10b981; }
          .summary-card h3 { margin: 0 0 5px 0; color: #10b981; }
          .summary-card p { margin: 0; font-size: 18px; font-weight: bold; }
          .section { margin: 30px 0; }
          .section h2 { color: #1f2937; border-bottom: 1px solid #e5e7eb; padding-bottom: 10px; }
          .appliance-list { list-style: none; padding: 0; }
          .appliance-item { background: #f9fafb; margin: 10px 0; padding: 15px; border-radius: 8px; display: flex; justify-content: between; }
          .recommendations { background: #fef3c7; padding: 20px; border-radius: 8px; border-left: 4px solid #f59e0b; }
          .recommendations ul { margin: 10px 0; }
          .footer { text-align: center; margin-top: 40px; padding-top: 20px; border-top: 1px solid #e5e7eb; color: #6b7280; }
        </style>
      </head>
      <body>
        <div class="header">
          <div class="logo">⚡ EnergizeAI</div>
          <h1>Monthly Electricity Report</h1>
          <p>${report.month} ${report.year}</p>
        </div>

        <div class="summary">
          <div class="summary-card">
            <h3>Total Usage</h3>
            <p>${report.totalUsage.toFixed(1)} kWh</p>
          </div>
          <div class="summary-card">
            <h3>Total Cost</h3>
            <p>${formatExactCurrency(report.totalCost)}</p>
          </div>
          <div class="summary-card">
            <h3>Budget Used</h3>
            <p>${report.budgetUsed.toFixed(1)}%</p>
          </div>
          <div class="summary-card">
            <h3>Savings</h3>
            <p>${formatExactCurrency(report.savings)}</p>
          </div>
        </div>

        <div class="section">
          <h2>🏠 Top Energy Consuming Appliances</h2>
          <ul class="appliance-list">
            ${report.topAppliances
              .map(
                (appliance, index) => `
              <li class="appliance-item">
                <div>
                  <strong>#${index + 1} ${appliance.name}</strong><br>
                  <small>${appliance.power}W • ${appliance.hoursPerDay}h/day • ${appliance.daysPerMonth} days/month</small>
                </div>
                <div style="text-align: right;">
                  <strong>${formatCurrency(appliance.monthlyCost)}/month</strong><br>
                  <small>${appliance.monthlyKwh.toFixed(1)} kWh</small>
                </div>
              </li>
            `,
              )
              .join("")}
          </ul>
        </div>

        <div class="section">
          <h2>📊 Usage Trends</h2>
          <ul>
            ${report.trends.map((trend) => `<li>${trend}</li>`).join("")}
          </ul>
        </div>

        <div class="recommendations">
          <h2>💡 Personalized Recommendations</h2>
          <ul>
            ${report.recommendations.map((rec) => `<li>${rec}</li>`).join("")}
          </ul>
        </div>

        <div class="footer">
          <p>Generated by EnergizeAI on ${new Date().toLocaleDateString("en-IN")}</p>
          <p>Your personal electricity bill assistant</p>
        </div>
      </body>
      </html>
    `

    // Create and download PDF
    const blob = new Blob([htmlContent], { type: "text/html" })
    const url = URL.createObjectURL(blob)
    const a = document.createElement("a")
    a.href = url
    a.download = `EnergizeAI-Report-${report.month}-${report.year}.html`
    a.click()
    URL.revokeObjectURL(url)

    trackReportGenerated("pdf_download")
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center space-x-2">
          <FileText className="h-5 w-5 text-purple-600" />
          <span>Monthly Report</span>
        </CardTitle>
        <CardDescription>Generate a comprehensive report of your electricity usage and savings</CardDescription>
      </CardHeader>
      <CardContent>
        {!report ? (
          <div className="text-center py-8">
            <FileText className="h-16 w-16 text-gray-300 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">Generate Your Monthly Report</h3>
            <p className="text-gray-600 mb-6">
              Get insights into your usage patterns, costs, and personalized recommendations
            </p>
            <Button onClick={generateReport} disabled={generating} className="bg-purple-600 hover:bg-purple-700">
              {generating ? "Generating..." : "Generate Report"}
            </Button>
          </div>
        ) : (
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="space-y-6">
            {/* Report Summary */}
            <div className="bg-gradient-to-r from-purple-50 to-blue-50 p-6 rounded-lg border border-purple-200">
              <h3 className="text-lg font-semibold mb-4 flex items-center space-x-2">
                <Calendar className="h-5 w-5 text-purple-600" />
                <span>
                  {report.month} {report.year} Summary
                </span>
              </h3>

              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div className="text-center">
                  <div className="text-2xl font-bold text-blue-600">{report.totalUsage.toFixed(1)}</div>
                  <div className="text-sm text-gray-600">kWh Used</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-green-600">{formatCurrency(report.totalCost)}</div>
                  <div className="text-sm text-gray-600">Total Cost</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-purple-600">{report.budgetUsed.toFixed(0)}%</div>
                  <div className="text-sm text-gray-600">Budget Used</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-orange-600">{formatCurrency(report.savings)}</div>
                  <div className="text-sm text-gray-600">Saved</div>
                </div>
              </div>
            </div>

            {/* Budget Status */}
            <div className="flex items-center justify-center">
              <Badge
                variant={report.budgetUsed <= 80 ? "default" : report.budgetUsed <= 100 ? "secondary" : "destructive"}
                className="text-lg px-4 py-2"
              >
                {report.budgetUsed <= 80
                  ? "🟢 Under Budget"
                  : report.budgetUsed <= 100
                    ? "🟡 On Track"
                    : "🔴 Over Budget"}
              </Badge>
            </div>

            {/* Top Appliances */}
            <div>
              <h4 className="font-semibold mb-3 flex items-center space-x-2">
                <Zap className="h-4 w-4 text-orange-600" />
                <span>Top 3 Cost Contributors</span>
              </h4>
              <div className="space-y-2">
                {report.topAppliances.slice(0, 3).map((appliance, index) => (
                  <div key={index} className="flex items-center justify-between p-3 bg-gray-50 rounded">
                    <div className="flex items-center space-x-3">
                      <div
                        className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold ${
                          index === 0
                            ? "bg-red-100 text-red-800"
                            : index === 1
                              ? "bg-orange-100 text-orange-800"
                              : "bg-yellow-100 text-yellow-800"
                        }`}
                      >
                        #{index + 1}
                      </div>
                      <div>
                        <div className="font-medium capitalize">{appliance.name}</div>
                        <div className="text-sm text-gray-600">{appliance.monthlyKwh.toFixed(1)} kWh</div>
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="font-bold text-green-600">{formatCurrency(appliance.monthlyCost)}</div>
                      <div className="text-xs text-gray-600">per month</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Recommendations */}
            <div>
              <h4 className="font-semibold mb-3 flex items-center space-x-2">
                <Target className="h-4 w-4 text-green-600" />
                <span>Key Recommendations</span>
              </h4>
              <div className="space-y-2">
                {report.recommendations.slice(0, 3).map((rec, index) => (
                  <div key={index} className="p-3 bg-yellow-50 rounded border border-yellow-200">
                    <p className="text-sm text-yellow-800">💡 {rec}</p>
                  </div>
                ))}
              </div>
            </div>

            {/* Download Button */}
            <div className="flex justify-center pt-4">
              <Button onClick={downloadPDF} className="bg-purple-600 hover:bg-purple-700">
                <Download className="h-4 w-4 mr-2" />
                Download Full Report
              </Button>
            </div>
          </motion.div>
        )}
      </CardContent>
    </Card>
  )
}
