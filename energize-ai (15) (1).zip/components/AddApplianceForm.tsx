"use client"

import { useState, useMemo, useCallback } from "react"
import { useForm } from "react-hook-form"
import { zodResolver } from "@hookform/resolvers/zod"
import { z } from "zod"
import { motion, AnimatePresence } from "framer-motion"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Plus, Loader2, Calculator, Lightbulb, AlertTriangle, CheckCircle, Zap, Clock, Calendar } from "lucide-react"
import {
  getAppliancePower,
  getApplianceSuggestions,
  formatExactCurrency,
  calculateMonthlyCost,
  isSlabBasedRegion,
} from "@/lib/constants"
import type { UserSettings } from "@/lib/types"

// Form validation schema
const applianceSchema = z.object({
  name: z.string().min(1, "Appliance name is required").max(50, "Name must be less than 50 characters"),
  hoursPerDay: z.number().min(0.1, "Hours per day must be at least 0.1").max(24, "Hours per day cannot exceed 24"),
  daysPerMonth: z.number().min(1, "Days per month must be at least 1").max(31, "Days per month cannot exceed 31"),
  category: z.enum(["essential", "optional"]).default("optional"),
})

type ApplianceFormData = z.infer<typeof applianceSchema>

interface AddApplianceFormProps {
  onSubmit: (data: ApplianceFormData & { power: number }) => Promise<void>
  settings: UserSettings | null
  currentTotal?: { kWh: number; cost: number }
  isSubmitting?: boolean
}

export function AddApplianceForm({
  onSubmit,
  settings,
  currentTotal = { kWh: 0, cost: 0 },
  isSubmitting = false,
}: AddApplianceFormProps) {
  const [suggestions, setSuggestions] = useState<any[]>([])
  const [showSuggestions, setShowSuggestions] = useState(false)
  const [showSuccess, setShowSuccess] = useState(false)

  const form = useForm<ApplianceFormData>({
    resolver: zodResolver(applianceSchema),
    defaultValues: {
      name: "",
      hoursPerDay: 0,
      daysPerMonth: 30,
      category: "optional",
    },
  })

  const {
    watch,
    setValue,
    reset,
    formState: { errors },
  } = form

  // Watch form values - memoize to prevent unnecessary re-renders
  const formValues = watch()
  const { name, hoursPerDay, daysPerMonth } = formValues

  // Memoize the live calculation to prevent infinite loops
  const liveCalculation = useMemo(() => {
    if (!name || !hoursPerDay || hoursPerDay <= 0 || !daysPerMonth || daysPerMonth <= 0 || !settings) {
      return { kwh: 0, cost: 0, additionalCost: 0 }
    }

    const power = getAppliancePower(name)
    const monthlyKwh = (power * hoursPerDay * daysPerMonth) / 1000

    if (isSlabBasedRegion(settings.region)) {
      // For Tamil Nadu, calculate additional cost
      const newTotal = currentTotal.kWh + monthlyKwh
      const newTotalCost = calculateMonthlyCost(newTotal, settings.electricityRate, settings.region)
      const additionalCost = Math.max(0, newTotalCost - currentTotal.cost)

      return {
        kwh: monthlyKwh,
        cost: monthlyKwh * settings.electricityRate, // Standard rate for comparison
        additionalCost,
      }
    } else {
      const cost = calculateMonthlyCost(monthlyKwh, settings.electricityRate, settings.region)
      return { kwh: monthlyKwh, cost, additionalCost: cost }
    }
  }, [name, hoursPerDay, daysPerMonth, settings, currentTotal.kWh, currentTotal.cost])

  // Handle appliance name input with suggestions - use useCallback to prevent re-renders
  const handleNameChange = useCallback(
    (value: string) => {
      setValue("name", value)

      if (value.length > 1) {
        const applianceSuggestions = getApplianceSuggestions(value)
        setSuggestions(applianceSuggestions)
        setShowSuggestions(applianceSuggestions.length > 0)
      } else {
        setShowSuggestions(false)
        setSuggestions([])
      }
    },
    [setValue],
  )

  // Handle suggestion selection - use useCallback
  const selectSuggestion = useCallback(
    (suggestion: any) => {
      setValue("name", suggestion.name)
      setShowSuggestions(false)
      setSuggestions([])
    },
    [setValue],
  )

  // Handle form submission - use useCallback
  const handleSubmit = useCallback(
    async (data: ApplianceFormData) => {
      try {
        const power = getAppliancePower(data.name)
        await onSubmit({ ...data, power })

        // Show success animation
        setShowSuccess(true)
        setTimeout(() => setShowSuccess(false), 2000)

        // Reset form
        reset()
        setShowSuggestions(false)
        setSuggestions([])
      } catch (error) {
        console.error("Error submitting form:", error)
      }
    },
    [onSubmit, reset],
  )

  const hasLiveData = liveCalculation.kwh > 0
  const estimatedPower = name ? getAppliancePower(name) : 0

  return (
    <Card className="card-modern">
      <CardHeader>
        <CardTitle className="flex items-center space-x-2 text-xl">
          <Plus className="h-6 w-6 text-green-600" />
          <span>Add New Appliance</span>
          {showSuccess && (
            <motion.div
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              className="flex items-center space-x-1 text-green-600"
            >
              <CheckCircle className="h-5 w-5" />
              <span className="text-sm">Added!</span>
            </motion.div>
          )}
        </CardTitle>
        <CardDescription className="text-base">
          Just type the appliance name - we'll automatically detect the power consumption!
        </CardDescription>
      </CardHeader>

      <CardContent>
        <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-6">
          {/* Input Fields */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            {/* Appliance Name with Suggestions */}
            <div className="space-y-2 relative">
              <Label htmlFor="name" className="text-sm font-medium flex items-center space-x-1">
                <Zap className="h-3 w-3" />
                <span>Appliance Name</span>
              </Label>
              <Input
                id="name"
                value={name}
                onChange={(e) => handleNameChange(e.target.value)}
                placeholder="e.g., Fan, AC, TV"
                className={`input-modern ${errors.name ? "border-red-500" : ""}`}
              />
              {errors.name && (
                <p className="text-xs text-red-600 flex items-center space-x-1">
                  <AlertTriangle className="h-3 w-3" />
                  <span>{errors.name.message}</span>
                </p>
              )}

              {/* Auto-detected power */}
              {estimatedPower > 0 && (
                <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-200">
                  Auto-detected: {estimatedPower}W
                </Badge>
              )}

              {/* Suggestions Dropdown */}
              <AnimatePresence>
                {showSuggestions && suggestions.length > 0 && (
                  <motion.div
                    initial={{ opacity: 0, y: -10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -10 }}
                    className="absolute z-10 w-full bg-white border border-gray-200 rounded-xl shadow-lg max-h-48 overflow-y-auto"
                  >
                    {suggestions.map((suggestion, index) => (
                      <button
                        key={`${suggestion.name}-${index}`}
                        type="button"
                        onClick={() => selectSuggestion(suggestion)}
                        className="w-full px-4 py-3 text-left hover:bg-green-50 transition-colors flex items-center justify-between border-b border-gray-50 last:border-b-0"
                      >
                        <span className="capitalize font-medium">{suggestion.name}</span>
                        <Badge variant="secondary" className="text-xs">
                          {suggestion.power}W
                        </Badge>
                      </button>
                    ))}
                  </motion.div>
                )}
              </AnimatePresence>
            </div>

            {/* Hours per Day */}
            <div className="space-y-2">
              <Label htmlFor="hoursPerDay" className="text-sm font-medium flex items-center space-x-1">
                <Clock className="h-3 w-3" />
                <span>Hours per Day</span>
              </Label>
              <Input
                id="hoursPerDay"
                type="number"
                step="0.5"
                min="0.1"
                max="24"
                {...form.register("hoursPerDay", { valueAsNumber: true })}
                placeholder="e.g., 8"
                className={`input-modern ${errors.hoursPerDay ? "border-red-500" : ""}`}
              />
              {errors.hoursPerDay && (
                <p className="text-xs text-red-600 flex items-center space-x-1">
                  <AlertTriangle className="h-3 w-3" />
                  <span>{errors.hoursPerDay.message}</span>
                </p>
              )}
            </div>

            {/* Days per Month */}
            <div className="space-y-2">
              <Label htmlFor="daysPerMonth" className="text-sm font-medium flex items-center space-x-1">
                <Calendar className="h-3 w-3" />
                <span>Days per Month</span>
              </Label>
              <Input
                id="daysPerMonth"
                type="number"
                min="1"
                max="31"
                {...form.register("daysPerMonth", { valueAsNumber: true })}
                placeholder="30"
                className={`input-modern ${errors.daysPerMonth ? "border-red-500" : ""}`}
              />
              {errors.daysPerMonth && (
                <p className="text-xs text-red-600 flex items-center space-x-1">
                  <AlertTriangle className="h-3 w-3" />
                  <span>{errors.daysPerMonth.message}</span>
                </p>
              )}
            </div>

            {/* Submit Button */}
            <div className="flex items-end">
              <Button
                type="submit"
                disabled={isSubmitting || !hasLiveData}
                className="w-full btn-modern bg-green-600 hover:bg-green-700 text-white h-11"
              >
                {isSubmitting ? (
                  <>
                    <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                    Adding...
                  </>
                ) : (
                  <>
                    <Plus className="h-4 w-4 mr-2" />
                    Add Appliance
                  </>
                )}
              </Button>
            </div>
          </div>

          {/* Live Calculation Display */}
          <AnimatePresence>
            {hasLiveData && (
              <motion.div
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: "auto" }}
                exit={{ opacity: 0, height: 0 }}
                className="bg-gradient-to-r from-green-50 to-blue-50 p-6 rounded-xl border border-green-200"
              >
                <div className="flex items-center space-x-2 mb-4">
                  <Calculator className="h-5 w-5 text-green-600" />
                  <span className="font-semibold text-green-800">Live Cost Preview</span>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="bg-white p-4 rounded-lg border border-green-200">
                    <div className="text-sm text-green-600 mb-1">Monthly Usage</div>
                    <div className="text-xl font-bold text-green-800">{liveCalculation.kwh.toFixed(1)} kWh</div>
                    <div className="text-xs text-gray-600">
                      {estimatedPower}W × {hoursPerDay}h × {daysPerMonth}d
                    </div>
                  </div>

                  <div className="bg-white p-4 rounded-lg border border-blue-200">
                    <div className="text-sm text-blue-600 mb-1">
                      {settings && isSlabBasedRegion(settings.region) ? "Additional Monthly Cost" : "Monthly Cost"}
                    </div>
                    <div className="text-xl font-bold text-blue-800">
                      {formatExactCurrency(liveCalculation.additionalCost)}
                    </div>
                    {settings && isSlabBasedRegion(settings.region) && (
                      <div className="text-xs text-gray-600">Based on slab rates</div>
                    )}
                  </div>

                  {settings && isSlabBasedRegion(settings.region) && (
                    <div className="bg-white p-4 rounded-lg border border-purple-200">
                      <div className="text-sm text-purple-600 mb-1">New Total Usage</div>
                      <div className="text-xl font-bold text-purple-800">
                        {(currentTotal.kWh + liveCalculation.kwh).toFixed(1)} kWh
                      </div>
                      <div className="text-xs text-gray-600">
                        Total bill: {formatExactCurrency(currentTotal.cost + liveCalculation.additionalCost)}
                      </div>
                    </div>
                  )}
                </div>

                {/* Efficiency Tip */}
                <div className="mt-4 bg-yellow-50 p-3 rounded-lg border border-yellow-200">
                  <div className="flex items-center space-x-2 mb-1">
                    <Lightbulb className="h-4 w-4 text-yellow-600" />
                    <span className="text-sm font-medium text-yellow-700">💡 Efficiency Tip</span>
                  </div>
                  <div className="text-sm text-yellow-800">
                    {liveCalculation.additionalCost > 500
                      ? "This appliance will significantly increase your bill. Consider energy-efficient alternatives."
                      : liveCalculation.additionalCost > 200
                        ? "Moderate cost impact. Use during off-peak hours to save money."
                        : "Low cost impact. This appliance is quite efficient!"}
                  </div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>

          {/* Form Validation Errors */}
          {Object.keys(errors).length > 0 && (
            <Alert className="border-red-200 bg-red-50">
              <AlertTriangle className="h-4 w-4 text-red-600" />
              <AlertDescription className="text-red-800">
                Please fix the errors above before adding the appliance.
              </AlertDescription>
            </Alert>
          )}
        </form>
      </CardContent>
    </Card>
  )
}
