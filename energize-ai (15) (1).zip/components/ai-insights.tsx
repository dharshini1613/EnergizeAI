"use client"

import { useState, useEffect } from "react"
import { motion } from "framer-motion"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Skeleton } from "@/components/ui/skeleton"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Brain, TrendingUp, Lightbulb, RefreshCw, Zap, AlertCircle, Wifi, WifiOff } from "lucide-react"
import { AIService, type PredictionResponse } from "@/lib/aiService"

interface AIInsightsProps {
  readings: any[]
  appliances: any[]
  className?: string
}

export function AIInsights({ readings, appliances, className }: AIInsightsProps) {
  const [insights, setInsights] = useState<PredictionResponse | null>(null)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [isOnline, setIsOnline] = useState(true)
  const [serviceAvailable, setServiceAvailable] = useState<boolean | null>(null)

  const checkServiceHealth = async () => {
    const available = await AIService.checkServiceHealth()
    setServiceAvailable(available)
    return available
  }

  const fetchInsights = async () => {
    setLoading(true)
    setError(null)

    try {
      const readingValues = readings.map((r) => r.reading).filter((r) => !isNaN(r) && r > 0)
      const result = await AIService.getEnergyReport(readingValues, appliances)

      setInsights(result)
      setError(null)
      setServiceAvailable(false) // Always show as local analysis
    } catch (err) {
      console.error("AI Insights Error:", err)
      // Provide fallback insights even if there's an error
      setInsights({
        recommendations: [
          "📊 Unable to analyze data at the moment",
          "💡 Try adding more meter readings for better insights",
          "🏠 Register your appliances to get efficiency tips",
        ],
        insights: {
          trend: "stable",
          efficiency: "average",
          suggestions: ["Check back after adding more data"],
        },
      })
      setError("Using basic analysis mode")
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    const handleOnline = () => setIsOnline(true)
    const handleOffline = () => setIsOnline(false)

    window.addEventListener("online", handleOnline)
    window.addEventListener("offline", handleOffline)

    // Always fetch insights when data is available
    if (readings.length > 0 || appliances.length > 0) {
      fetchInsights()
    }

    return () => {
      window.removeEventListener("online", handleOnline)
      window.removeEventListener("offline", handleOffline)
    }
  }, [readings.length, appliances.length])

  if (!isOnline) {
    return (
      <Card className={className}>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <WifiOff className="h-5 w-5 text-gray-400" />
            <span>AI Energy Insights</span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <Alert>
            <AlertCircle className="h-4 w-4" />
            <AlertDescription>
              You're currently offline. AI insights will be available when you reconnect to the internet.
            </AlertDescription>
          </Alert>
        </CardContent>
      </Card>
    )
  }

  if (loading) {
    return (
      <Card className={className}>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Brain className="h-5 w-5 text-purple-600" />
            <span>AI Energy Insights</span>
          </CardTitle>
          <CardDescription>Analyzing your energy data...</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <Skeleton className="h-4 w-full" />
          <Skeleton className="h-4 w-3/4" />
          <Skeleton className="h-4 w-1/2" />
        </CardContent>
      </Card>
    )
  }

  return (
    <Card className={className}>
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="flex items-center space-x-2">
              <Brain className="h-5 w-5 text-purple-600" />
              <span>AI Energy Insights</span>
              {serviceAvailable === false && (
                <Badge variant="outline" className="text-orange-600 border-orange-200">
                  Local Analysis
                </Badge>
              )}
              {serviceAvailable === true && (
                <Badge variant="outline" className="text-green-600 border-green-200">
                  <Wifi className="h-3 w-3 mr-1" />
                  AI Powered
                </Badge>
              )}
            </CardTitle>
            <CardDescription>
              {serviceAvailable === false
                ? "Using local analysis - AI service unavailable"
                : "Personalized recommendations powered by AI"}
            </CardDescription>
          </div>
          <Button onClick={fetchInsights} variant="outline" size="sm" disabled={loading}>
            <RefreshCw className={`h-4 w-4 mr-2 ${loading ? "animate-spin" : ""}`} />
            Refresh
          </Button>
        </div>
      </CardHeader>
      <CardContent className="space-y-6">
        {error && (
          <Alert>
            <AlertCircle className="h-4 w-4" />
            <AlertDescription>{error} The insights below are generated using local analysis.</AlertDescription>
          </Alert>
        )}

        {/* Usage Trend */}
        {insights?.insights && (
          <div className="space-y-3">
            <div className="flex items-center space-x-2">
              <TrendingUp className="h-4 w-4 text-blue-600" />
              <h4 className="font-medium">Usage Analysis</h4>
            </div>
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-2">
                <span className="text-sm text-gray-600">Trend:</span>
                <Badge
                  variant={
                    insights.insights.trend === "increasing"
                      ? "destructive"
                      : insights.insights.trend === "decreasing"
                        ? "default"
                        : "secondary"
                  }
                >
                  {insights.insights.trend}
                </Badge>
              </div>
              <div className="flex items-center space-x-2">
                <span className="text-sm text-gray-600">Efficiency:</span>
                <Badge
                  variant={
                    insights.insights.efficiency === "good"
                      ? "default"
                      : insights.insights.efficiency === "poor"
                        ? "destructive"
                        : "secondary"
                  }
                >
                  {insights.insights.efficiency}
                </Badge>
              </div>
            </div>
          </div>
        )}

        {/* Next Reading Prediction */}
        {insights?.prediction && (
          <div className="space-y-3">
            <div className="flex items-center space-x-2">
              <Zap className="h-4 w-4 text-green-600" />
              <h4 className="font-medium">Prediction</h4>
            </div>
            <div className="bg-green-50 p-4 rounded-lg">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-green-700">Next Expected Reading</p>
                  <p className="text-2xl font-bold text-green-800">{insights.prediction.nextReading?.toFixed(1)} kWh</p>
                </div>
                {insights.prediction.confidence && (
                  <div className="text-right">
                    <p className="text-sm text-green-700">Confidence</p>
                    <p className="text-lg font-semibold text-green-800">
                      {(insights.prediction.confidence * 100).toFixed(0)}%
                    </p>
                  </div>
                )}
              </div>
            </div>
          </div>
        )}

        {/* Recommendations */}
        {insights?.recommendations && insights.recommendations.length > 0 && (
          <div className="space-y-3">
            <div className="flex items-center space-x-2">
              <Lightbulb className="h-4 w-4 text-yellow-600" />
              <h4 className="font-medium">Recommendations</h4>
            </div>
            <div className="space-y-2">
              {insights.recommendations.map((recommendation, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: index * 0.1 }}
                  className="bg-yellow-50 p-3 rounded-lg border-l-4 border-yellow-400"
                >
                  <p className="text-sm text-yellow-800">{recommendation}</p>
                </motion.div>
              ))}
            </div>
          </div>
        )}

        {/* Insights Suggestions */}
        {insights?.insights?.suggestions && insights.insights.suggestions.length > 0 && (
          <div className="space-y-3">
            <div className="flex items-center space-x-2">
              <Brain className="h-4 w-4 text-purple-600" />
              <h4 className="font-medium">Smart Suggestions</h4>
            </div>
            <div className="space-y-2">
              {insights.insights.suggestions.map((suggestion, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: index * 0.1 }}
                  className="bg-purple-50 p-3 rounded-lg border-l-4 border-purple-400"
                >
                  <p className="text-sm text-purple-800">{suggestion}</p>
                </motion.div>
              ))}
            </div>
          </div>
        )}

        {!insights && !loading && (
          <div className="text-center py-8 text-gray-500">
            <Brain className="h-12 w-12 text-gray-300 mx-auto mb-3" />
            <p>Add meter readings and appliances to get AI-powered insights</p>
            <Button onClick={fetchInsights} variant="outline" size="sm" className="mt-3">
              Generate Insights
            </Button>
          </div>
        )}
      </CardContent>
    </Card>
  )
}
