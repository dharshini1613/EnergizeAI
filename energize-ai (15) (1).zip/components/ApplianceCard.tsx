"use client"

import { useState } from "react"
import { motion } from "framer-motion"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Trash2, Zap, Clock, Calendar, TrendingDown, Lightbulb, Fan, Tv, Refrigerator, AirVent } from "lucide-react"
import { formatExactCurrency } from "@/lib/constants"
import type { UserSettings } from "@/lib/types"

interface ApplianceCardProps {
  appliance: any
  rank: number
  settings: UserSettings | null
  onDelete: (id: string) => void
  isSlabBased: boolean
  totalCost: number
  onEdit?: (appliance: any) => void
}

// Appliance icons mapping
const getApplianceIcon = (name: string) => {
  const lowerName = name.toLowerCase()
  if (lowerName.includes("fan")) return Fan
  if (lowerName.includes("tv")) return Tv
  if (lowerName.includes("fridge") || lowerName.includes("refrigerator")) return Refrigerator
  if (lowerName.includes("ac") || lowerName.includes("air")) return AirVent
  return Zap
}

// Get appliance category color
const getCategoryColor = (cost: number) => {
  if (cost > 1000) return "red"
  if (cost > 500) return "orange"
  if (cost > 200) return "yellow"
  return "green"
}

export function ApplianceCard({
  appliance,
  rank,
  settings,
  onDelete,
  isSlabBased,
  totalCost,
  onEdit,
}: ApplianceCardProps) {
  const [isHovered, setIsHovered] = useState(false)
  const [isDeleting, setIsDeleting] = useState(false)

  const IconComponent = getApplianceIcon(appliance.name)
  const categoryColor = getCategoryColor(appliance.monthlyCost)
  const dailyCost = appliance.monthlyCost / 30
  const hourlyCost = appliance.monthlyCost / (appliance.hoursPerDay * appliance.daysPerMonth)

  // Calculate potential savings
  const oneHourLessSavings = hourlyCost * appliance.daysPerMonth
  const isHighCost = appliance.monthlyCost > 500

  const handleDelete = async () => {
    setIsDeleting(true)
    try {
      await onDelete(appliance.id)
    } catch (error) {
      setIsDeleting(false)
    }
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -20 }}
      whileHover={{ y: -4 }}
      transition={{ duration: 0.3 }}
      onHoverStart={() => setIsHovered(true)}
      onHoverEnd={() => setIsHovered(false)}
    >
      <Card
        className={`appliance-card overflow-hidden ${
          isHighCost ? "border-red-200 bg-gradient-to-br from-red-50 to-pink-50" : "border-gray-200 bg-white"
        } ${isHovered ? "shadow-xl" : "shadow-sm"}`}
      >
        <CardContent className="p-6">
          {/* Header */}
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center space-x-4">
              {/* Rank Badge */}
              <div
                className={`w-12 h-12 rounded-full flex items-center justify-center text-sm font-bold shadow-md ${
                  rank === 1
                    ? "bg-red-100 text-red-800 ring-2 ring-red-200"
                    : rank === 2
                      ? "bg-orange-100 text-orange-800 ring-2 ring-orange-200"
                      : rank === 3
                        ? "bg-yellow-100 text-yellow-800 ring-2 ring-yellow-200"
                        : "bg-gray-100 text-gray-800"
                }`}
              >
                #{rank}
              </div>

              {/* Appliance Info */}
              <div>
                <div className="flex items-center space-x-2 mb-1">
                  <IconComponent className="h-5 w-5 text-gray-600" />
                  <h3 className="font-semibold text-xl capitalize text-gray-900">{appliance.name}</h3>
                  {isHighCost && (
                    <Badge variant="destructive" className="text-xs animate-pulse">
                      High Cost
                    </Badge>
                  )}
                </div>
                <div className="flex items-center space-x-4 text-sm text-gray-600">
                  <div className="flex items-center space-x-1">
                    <Zap className="h-3 w-3" />
                    <span>{appliance.power}W</span>
                  </div>
                  <div className="flex items-center space-x-1">
                    <Clock className="h-3 w-3" />
                    <span>{appliance.hoursPerDay}h/day</span>
                  </div>
                  <div className="flex items-center space-x-1">
                    <Calendar className="h-3 w-3" />
                    <span>{appliance.daysPerMonth} days</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Delete Button */}
            <Button
              variant="ghost"
              size="sm"
              onClick={handleDelete}
              disabled={isDeleting}
              className="text-red-600 hover:text-red-700 hover:bg-red-50 p-2 rounded-lg transition-all duration-300 hover:scale-110"
            >
              <Trash2 className={`h-4 w-4 ${isDeleting ? "animate-spin" : ""}`} />
            </Button>
          </div>

          {/* Cost Display */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-4">
            <div className="bg-green-50 p-3 rounded-lg border border-green-200">
              <div className="text-xs text-green-600 mb-1">Monthly Cost</div>
              <div className="text-lg font-bold text-green-800">{formatExactCurrency(appliance.monthlyCost)}</div>
            </div>
            <div className="bg-blue-50 p-3 rounded-lg border border-blue-200">
              <div className="text-xs text-blue-600 mb-1">Daily Cost</div>
              <div className="text-lg font-bold text-blue-800">{formatExactCurrency(dailyCost)}</div>
            </div>
            <div className="bg-purple-50 p-3 rounded-lg border border-purple-200">
              <div className="text-xs text-purple-600 mb-1">Monthly kWh</div>
              <div className="text-lg font-bold text-purple-800">{appliance.monthlyKwh.toFixed(1)}</div>
            </div>
            <div className="bg-orange-50 p-3 rounded-lg border border-orange-200">
              <div className="text-xs text-orange-600 mb-1">Usage Share</div>
              <div className="text-lg font-bold text-orange-800">{appliance.proportionalShare?.toFixed(1) || "0"}%</div>
            </div>
          </div>

          {/* Slab-based Info */}
          {isSlabBased && appliance.effectiveRate && (
            <div className="bg-yellow-50 p-3 rounded-lg border border-yellow-200 mb-4">
              <div className="flex items-center space-x-2 mb-1">
                <Badge className="bg-green-100 text-green-800 border-green-200 text-xs">TN Slab-Based</Badge>
              </div>
              <div className="text-sm text-yellow-700">
                Effective rate: ₹{appliance.effectiveRate.toFixed(2)}/kWh • Share of total bill:{" "}
                {((appliance.monthlyCost / totalCost) * 100).toFixed(1)}%
              </div>
            </div>
          )}

          {/* Savings Suggestion */}
          <div className="bg-gradient-to-r from-blue-50 to-green-50 p-4 rounded-lg border border-blue-200">
            <div className="flex items-center space-x-2 mb-2">
              <Lightbulb className="h-4 w-4 text-blue-600" />
              <span className="text-sm font-medium text-blue-700">💡 Smart Savings Tip</span>
            </div>
            <div className="text-sm text-blue-800">
              <div className="flex items-center space-x-1 mb-1">
                <TrendingDown className="h-3 w-3 text-green-600" />
                <span>Reduce usage by 1 hour daily → Save {formatExactCurrency(oneHourLessSavings)}/month</span>
              </div>
              {isSlabBased && (
                <div className="text-xs text-blue-600 mt-1">
                  * Savings based on proportional share of total slab-based bill
                </div>
              )}
            </div>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  )
}
