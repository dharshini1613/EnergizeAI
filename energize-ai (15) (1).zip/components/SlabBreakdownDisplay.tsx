"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Calculator, Zap, TrendingUp, Info } from "lucide-react"
import { getTamilNaduSlabBreakdown, formatExactCurrency } from "@/lib/constants"
import { motion } from "framer-motion"

interface SlabBreakdownDisplayProps {
  totalUnits: number
  totalCost: number
  className?: string
}

export function SlabBreakdownDisplay({ totalUnits, totalCost, className = "" }: SlabBreakdownDisplayProps) {
  // Safety checks for undefined values
  const safeUnits = totalUnits || 0
  const safeCost = totalCost || 0

  const breakdown = getTamilNaduSlabBreakdown(safeUnits)
  const effectiveRate = safeUnits > 0 ? safeCost / safeUnits : 0

  if (safeUnits <= 0) {
    return (
      <Card className={`card-modern ${className}`}>
        <CardContent className="p-8 text-center">
          <Calculator className="h-12 w-12 text-gray-300 mx-auto mb-4" />
          <p className="text-gray-500">Add appliances to see slab breakdown</p>
        </CardContent>
      </Card>
    )
  }

  return (
    <Card className={`card-modern ${className}`}>
      <CardHeader className="pb-4">
        <CardTitle className="flex items-center space-x-2 text-xl">
          <Calculator className="h-6 w-6 text-green-600" />
          <span>Tamil Nadu LT-1 Slab Breakdown</span>
          <Badge className="bg-green-100 text-green-800 border-green-200">Official TANGEDCO Rates</Badge>
        </CardTitle>
        <CardDescription className="text-base">
          Your {safeUnits.toFixed(1)} kWh consumption breakdown using official domestic slab rates
        </CardDescription>
      </CardHeader>

      <CardContent className="space-y-6">
        {/* Summary Stats */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="bg-green-50 p-4 rounded-xl border border-green-200">
            <div className="text-sm text-green-600 mb-1">Total Usage</div>
            <div className="text-2xl font-bold text-green-800">{safeUnits.toFixed(1)} kWh</div>
          </div>
          <div className="bg-blue-50 p-4 rounded-xl border border-blue-200">
            <div className="text-sm text-blue-600 mb-1">Total Bill</div>
            <div className="text-2xl font-bold text-blue-800">{formatExactCurrency(safeCost)}</div>
          </div>
          <div className="bg-purple-50 p-4 rounded-xl border border-purple-200">
            <div className="text-sm text-purple-600 mb-1">Effective Rate</div>
            <div className="text-2xl font-bold text-purple-800">₹{effectiveRate.toFixed(2)}/kWh</div>
          </div>
        </div>

        {/* Slab Details */}
        <div className="space-y-3">
          <h4 className="font-semibold text-gray-900 flex items-center space-x-2">
            <Zap className="h-4 w-4 text-orange-500" />
            <span>Slab-wise Calculation</span>
          </h4>

          {breakdown.map((slab, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: index * 0.1 }}
              className="bg-gray-50 p-4 rounded-xl border border-gray-200 hover:bg-gray-100 transition-colors"
            >
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center space-x-3">
                  <Badge
                    variant={slab.isFree ? "default" : "secondary"}
                    className={slab.isFree ? "bg-green-100 text-green-800 border-green-200" : ""}
                  >
                    {slab.range} units
                  </Badge>
                  <span className="text-sm text-gray-600">{slab.units.toFixed(1)} units used</span>
                </div>
                <div className="text-right">
                  <div className="font-semibold text-gray-900">{slab.isFree ? "FREE" : `₹${slab.rate}/unit`}</div>
                  <div className="text-sm text-gray-600">= {formatExactCurrency(slab.cost)}</div>
                </div>
              </div>

              {/* Progress bar showing usage in this slab */}
              <div className="mt-2">
                <Progress value={(slab.units / Math.max(slab.units, 100)) * 100} className="h-2" />
              </div>
            </motion.div>
          ))}
        </div>

        {/* Total Calculation */}
        <div className="bg-gradient-to-r from-green-50 to-blue-50 p-6 rounded-xl border border-green-200">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <TrendingUp className="h-5 w-5 text-green-600" />
              <span className="font-semibold text-green-800">Final Bill Amount</span>
            </div>
            <div className="text-2xl font-bold text-green-800">{formatExactCurrency(safeCost)}</div>
          </div>
          <div className="mt-2 text-sm text-green-600">Average rate: ₹{effectiveRate.toFixed(2)} per kWh</div>
        </div>

        {/* Savings Tip */}
        <div className="bg-yellow-50 p-4 rounded-xl border border-yellow-200">
          <div className="flex items-start space-x-2">
            <Info className="h-4 w-4 text-yellow-600 mt-0.5" />
            <div>
              <div className="font-medium text-yellow-800 mb-1">💡 Money Saving Tip</div>
              <div className="text-sm text-yellow-700">
                {safeUnits > 400
                  ? `You're in higher slabs! Reducing usage by 50 kWh could save you ₹${(safeCost - getTamilNaduSlabBreakdown(safeUnits - 50).reduce((sum, s) => sum + s.cost, 0)).toFixed(2)}/month`
                  : safeUnits > 200
                    ? "You're using efficient amounts. Keep it up!"
                    : "Great! You're in the lower cost slabs. Your electricity is very affordable."}
              </div>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
