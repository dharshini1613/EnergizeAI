"use client"

import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar } from "recharts"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { TrendingUp, BarChart3 } from "lucide-react"
import { formatExactCurrency } from "@/lib/constants"
import type { MeterReading } from "@/lib/types"

interface UsageChartProps {
  readings: MeterReading[]
  predictions?: number[]
  type?: "line" | "bar"
  title?: string
}

export function UsageChart({ readings, predictions, type = "line", title = "Daily Usage Trend" }: UsageChartProps) {
  // Prepare chart data
  const chartData = readings.slice(-14).map((reading, index) => ({
    date: new Date(reading.date).toLocaleDateString("en-IN", { month: "short", day: "numeric" }),
    usage: reading.dailyUsage || 0,
    cost: reading.dailyCost || 0,
    reading: reading.reading,
  }))

  // Add predictions if provided
  if (predictions && predictions.length > 0) {
    const lastDate = new Date(readings[readings.length - 1]?.date || new Date())
    predictions.slice(0, 7).forEach((prediction, index) => {
      const futureDate = new Date(lastDate)
      futureDate.setDate(futureDate.getDate() + index + 1)

      const prevReading = index === 0 ? readings[readings.length - 1]?.reading : predictions[index - 1]
      const predictedUsage = prediction - (prevReading || 0)

      chartData.push({
        date: futureDate.toLocaleDateString("en-IN", { month: "short", day: "numeric" }),
        usage: Math.max(0, predictedUsage),
        cost: predictedUsage * 8, // Assuming ₹8/kWh
        reading: prediction,
        isPrediction: true,
      })
    })
  }

  const CustomTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
      const data = payload[0].payload
      return (
        <div className="bg-white p-3 border border-gray-200 rounded-lg shadow-lg">
          <p className="font-medium">{label}</p>
          <p className="text-blue-600">Usage: {data.usage.toFixed(1)} kWh</p>
          <p className="text-green-600">Cost: {formatExactCurrency(data.cost)}</p>
          {data.isPrediction && <p className="text-purple-600 text-xs">Predicted</p>}
        </div>
      )
    }
    return null
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center space-x-2">
          {type === "line" ? (
            <TrendingUp className="h-5 w-5 text-blue-600" />
          ) : (
            <BarChart3 className="h-5 w-5 text-green-600" />
          )}
          <span>{title}</span>
        </CardTitle>
        <CardDescription>
          {predictions ? "Last 14 days + 7-day prediction" : "Last 14 days usage pattern"}
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className="h-64">
          <ResponsiveContainer width="100%" height="100%">
            {type === "line" ? (
              <LineChart data={chartData}>
                <CartesianGrid strokeDasharray="3 3" className="opacity-30" />
                <XAxis
                  dataKey="date"
                  className="text-xs"
                  tick={{ fontSize: 12 }}
                  angle={-45}
                  textAnchor="end"
                  height={60}
                />
                <YAxis className="text-xs" tick={{ fontSize: 12 }} />
                <Tooltip content={<CustomTooltip />} />
                <Line
                  type="monotone"
                  dataKey="usage"
                  stroke="#3b82f6"
                  strokeWidth={2}
                  dot={(props) => {
                    const { payload, cx, cy } = props
                    // Add a unique key using cx and cy coordinates plus payload data
                    const dotKey = `dot-${cx}-${cy}-${payload.date}`

                    return (
                      <circle
                        key={dotKey}
                        cx={cx}
                        cy={cy}
                        r={4}
                        fill={payload.isPrediction ? "#8b5cf6" : "#3b82f6"}
                        stroke={payload.isPrediction ? "#8b5cf6" : "#3b82f6"}
                        strokeWidth={2}
                        strokeDasharray={payload.isPrediction ? "3,3" : "0"}
                      />
                    )
                  }}
                  strokeDasharray={(entry: any) => (entry.isPrediction ? "5,5" : "0")}
                />
              </LineChart>
            ) : (
              <BarChart data={chartData}>
                <CartesianGrid strokeDasharray="3 3" className="opacity-30" />
                <XAxis
                  dataKey="date"
                  className="text-xs"
                  tick={{ fontSize: 12 }}
                  angle={-45}
                  textAnchor="end"
                  height={60}
                />
                <YAxis className="text-xs" tick={{ fontSize: 12 }} />
                <Tooltip content={<CustomTooltip />} />
                <Bar dataKey="usage" fill="#10b981" radius={[4, 4, 0, 0]} />
              </BarChart>
            )}
          </ResponsiveContainer>
        </div>

        {predictions && (
          <div className="mt-4 flex items-center justify-center space-x-4 text-sm">
            <div className="flex items-center space-x-2">
              <div className="w-3 h-3 bg-blue-500 rounded-full"></div>
              <span>Actual</span>
            </div>
            <div className="flex items-center space-x-2">
              <div className="w-3 h-3 bg-purple-500 rounded-full border-2 border-dashed border-purple-300"></div>
              <span>Predicted</span>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  )
}
