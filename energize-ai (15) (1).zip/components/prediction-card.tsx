"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Skeleton } from "@/components/ui/skeleton"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { TrendingUp, RefreshCw, AlertCircle, Wifi, WifiOff } from "lucide-react"
import { AIService, type PredictionResponse } from "@/lib/aiService"

interface PredictionCardProps {
  readings: number[]
  title?: string
  className?: string
}

export function PredictionCard({ readings, title = "Usage Prediction", className }: PredictionCardProps) {
  const [prediction, setPrediction] = useState<PredictionResponse | null>(null)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [isOnline, setIsOnline] = useState(navigator.onLine)

  const fetchPrediction = async () => {
    setLoading(true)
    setError(null)

    try {
      const result = await AIService.predictNextReading(readings)
      setPrediction(result)
      setError(null)
    } catch (err) {
      console.error("Prediction Error:", err)
      // Provide basic prediction even on error
      if (readings.length >= 2) {
        const lastReading = readings[readings.length - 1]
        const avgIncrease =
          readings.length > 2 ? (readings[readings.length - 1] - readings[0]) / (readings.length - 1) : 5 // Default 5 kWh daily usage

        setPrediction({
          prediction: {
            nextReading: lastReading + Math.max(avgIncrease, 1),
            estimatedUsage: Math.max(avgIncrease, 1),
            confidence: 0.6,
          },
          recommendations: ["📊 Prediction based on your usage history"],
        })
      } else {
        setError("Need at least 2 readings for predictions")
      }
    } finally {
      setLoading(false)
    }
  }

  // Listen for online/offline events
  useEffect(() => {
    const handleOnline = () => setIsOnline(true)
    const handleOffline = () => setIsOnline(false)

    window.addEventListener("online", handleOnline)
    window.addEventListener("offline", handleOffline)

    return () => {
      window.removeEventListener("online", handleOffline)
      window.removeEventListener("offline", handleOffline)
    }
  }, [])

  return (
    <Card className={className}>
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="flex items-center space-x-2">
              <TrendingUp className="h-5 w-5 text-blue-600" />
              <span>{title}</span>
              {!isOnline && <WifiOff className="h-4 w-4 text-gray-400" />}
              {isOnline && <Wifi className="h-4 w-4 text-green-500" />}
            </CardTitle>
            <CardDescription>
              {isOnline ? "AI-powered energy consumption forecast" : "Offline - predictions unavailable"}
            </CardDescription>
          </div>
          <Button
            onClick={fetchPrediction}
            variant="outline"
            size="sm"
            disabled={loading || readings.length < 3 || !isOnline}
          >
            <RefreshCw className={`h-4 w-4 mr-2 ${loading ? "animate-spin" : ""}`} />
            Predict
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        {!isOnline ? (
          <Alert>
            <WifiOff className="h-4 w-4" />
            <AlertDescription>
              You're currently offline. Predictions will be available when you reconnect.
            </AlertDescription>
          </Alert>
        ) : loading ? (
          <div className="space-y-3">
            <Skeleton className="h-4 w-full" />
            <Skeleton className="h-8 w-24" />
            <Skeleton className="h-4 w-3/4" />
          </div>
        ) : error ? (
          <Alert>
            <AlertCircle className="h-4 w-4" />
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        ) : prediction?.prediction ? (
          <div className="space-y-4">
            <div className="bg-blue-50 p-4 rounded-lg">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-blue-700">Next Expected Reading</p>
                  <p className="text-2xl font-bold text-blue-800">
                    {prediction.prediction.nextReading?.toFixed(1)} kWh
                  </p>
                </div>
                {prediction.prediction.confidence && (
                  <Badge variant="outline" className="text-blue-700">
                    {(prediction.prediction.confidence * 100).toFixed(0)}% confidence
                  </Badge>
                )}
              </div>
            </div>
            {prediction.prediction.estimatedUsage && (
              <div>
                <p className="text-sm text-gray-600">Estimated Usage</p>
                <p className="text-lg font-semibold">{prediction.prediction.estimatedUsage.toFixed(1)} kWh</p>
              </div>
            )}
            {prediction.recommendations && prediction.recommendations.length > 0 && (
              <div className="space-y-2">
                <p className="text-sm font-medium text-gray-700">Recommendations:</p>
                {prediction.recommendations.map((rec, index) => (
                  <p key={index} className="text-xs text-gray-600 bg-gray-50 p-2 rounded">
                    {rec}
                  </p>
                ))}
              </div>
            )}
          </div>
        ) : (
          <div className="text-center py-4 text-gray-500">
            <p className="text-sm">
              {readings.length < 3
                ? "Add at least 3 meter readings to get predictions"
                : "Click 'Predict' to get AI-powered forecasts"}
            </p>
          </div>
        )}
      </CardContent>
    </Card>
  )
}
