"use client"

import type React from "react"

import { useState } from "react"
import { motion } from "framer-motion"
import { collection, writeBatch, doc } from "firebase/firestore"
import { db } from "@/lib/firebase"
import { validateApplianceCSVRow } from "@/lib/validation"
import { getErrorMessage } from "@/lib/errorMessages"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import { ErrorAlert } from "@/components/ui/error-alert"
import { useToast } from "@/hooks/use-toast"
import { Loader2, Upload, FileSpreadsheet, CheckCircle, AlertCircle, Info, Download, Zap } from "lucide-react"
import { trackDataImport } from "@/lib/analytics"

interface ImportApplianceRow {
  name: string
  power: number
  hoursPerDay: number
  daysPerMonth: number
  category: "essential" | "optional"
  valid: boolean
  errors: string[]
}

interface ApplianceImportProps {
  existingAppliances: string[]
  onImportComplete: () => void
}

export function ApplianceImport({ existingAppliances, onImportComplete }: ApplianceImportProps) {
  const [file, setFile] = useState<File | null>(null)
  const [preview, setPreview] = useState<ImportApplianceRow[]>([])
  const [loading, setLoading] = useState(false)
  const [importing, setImporting] = useState(false)
  const [parseError, setParseError] = useState<string | null>(null)
  const { toast } = useToast()

  const handleFileChange = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = event.target.files?.[0]
    if (!selectedFile) return

    setFile(selectedFile)
    setLoading(true)
    setParseError(null)

    try {
      // Validate file type
      if (!selectedFile.name.toLowerCase().endsWith(".csv")) {
        setParseError("Please upload a CSV file (.csv extension)")
        return
      }

      // Check file size (max 5MB)
      if (selectedFile.size > 5 * 1024 * 1024) {
        setParseError("File is too large. Please use files smaller than 5MB.")
        return
      }

      const text = await selectedFile.text()

      if (!text.trim()) {
        setParseError("File is empty. Please upload a file with appliance data.")
        return
      }

      const rows = text.split("\n").filter((row) => row.trim())

      if (rows.length === 0) {
        setParseError("No data found in file.")
        return
      }

      // Skip header row if it exists
      let dataRows = rows
      if (rows.length > 0) {
        const firstRowCols = rows[0].split(",").map((col) => col.trim())
        if (
          firstRowCols.length >= 5 &&
          (firstRowCols[0].toLowerCase().includes("name") || firstRowCols[1].toLowerCase().includes("power"))
        ) {
          dataRows = rows.slice(1)
        }
      }

      if (dataRows.length === 0) {
        setParseError("No data rows found. Please check your file format.")
        return
      }

      if (dataRows.length > 100) {
        setParseError("Too many appliances. Maximum 100 appliances per import.")
        return
      }

      const existingNamesLower = existingAppliances.map((name) => name.toLowerCase())

      const parsedData: ImportApplianceRow[] = dataRows.map((row, index) => {
        const columns = row.split(",").map((col) => col.trim().replace(/"/g, ""))
        const validation = validateApplianceCSVRow(columns, index, existingNamesLower)

        return {
          name: columns[0] || "",
          power: columns[1] ? Number.parseFloat(columns[1]) : 0,
          hoursPerDay: columns[2] ? Number.parseFloat(columns[2]) : 0,
          daysPerMonth: columns[3] ? Number.parseFloat(columns[3]) : 30,
          category: (columns[4]?.toLowerCase() === "essential" ? "essential" : "optional") as "essential" | "optional",
          valid: validation.valid,
          errors: validation.errors,
        }
      })

      setPreview(parsedData)
    } catch (error) {
      console.error("Error parsing file:", error)
      setParseError("Error reading file. Please check the file format.")
    } finally {
      setLoading(false)
    }
  }

  const handleImport = async () => {
    const validRows = preview.filter((row) => row.valid)

    if (validRows.length === 0) {
      toast({
        title: "No Valid Data",
        description: "Please fix the errors in your file before importing.",
        variant: "destructive",
      })
      return
    }

    setImporting(true)

    try {
      const batch = writeBatch(db)

      validRows.forEach((row) => {
        const docRef = doc(collection(db, "appliances"))
        const monthlyKwh = (row.power * row.hoursPerDay * row.daysPerMonth) / 1000
        batch.set(docRef, {
          name: row.name,
          power: row.power,
          hoursPerDay: row.hoursPerDay,
          daysPerMonth: row.daysPerMonth,
          category: row.category,
          monthlyKwh,
          monthlyCost: 0, // Will be calculated after processing
          createdAt: new Date(),
        })
      })

      await batch.commit()

      // Track the import
      trackDataImport(validRows.length)

      toast({
        title: "✅ Import Successful!",
        description: `Successfully imported ${validRows.length} appliances. You can now view them in your appliance tracker.`,
      })

      // Reset form and notify parent
      setFile(null)
      setPreview([])
      setParseError(null)
      const fileInput = document.getElementById("appliance-file-input") as HTMLInputElement
      if (fileInput) fileInput.value = ""

      onImportComplete()
    } catch (error) {
      console.error("Error importing appliances:", error)
      const errorMsg = getErrorMessage(error)
      toast({
        title: errorMsg.title,
        description: errorMsg.description,
        variant: "destructive",
      })
    } finally {
      setImporting(false)
    }
  }

  const downloadSampleCSV = () => {
    const sampleData = [
      "Name,Power(W),Hours/Day,Days/Month,Category",
      "Air Conditioner,1500,8,30,essential",
      "Ceiling Fan,75,12,30,essential",
      "LED TV,120,5,30,optional",
      "Refrigerator,150,24,30,essential",
      "Water Heater,2000,2,30,essential",
      "Washing Machine,500,1,15,optional",
    ].join("\n")

    const blob = new Blob([sampleData], { type: "text/csv" })
    const url = URL.createObjectURL(blob)
    const a = document.createElement("a")
    a.href = url
    a.download = "sample-appliances.csv"
    a.click()
    URL.revokeObjectURL(url)

    toast({
      title: "Sample Downloaded",
      description: "Use this sample file as a template for your appliances.",
    })
  }

  const validCount = preview.filter((row) => row.valid).length
  const invalidCount = preview.length - validCount

  return (
    <div className="space-y-6">
      {/* File Upload */}
      <Card className="card-modern">
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Zap className="h-5 w-5 text-green-600" />
            <span>Import Appliances from CSV</span>
          </CardTitle>
          <CardDescription>
            Upload a CSV file with your appliance data to quickly add multiple appliances at once.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center space-x-4">
            <div className="flex-1 space-y-2">
              <Label htmlFor="appliance-file-input">Select CSV File (max 5MB, 100 appliances)</Label>
              <Input
                id="appliance-file-input"
                type="file"
                accept=".csv"
                onChange={handleFileChange}
                className="input-modern"
              />
            </div>
            <Button variant="outline" onClick={downloadSampleCSV} className="btn-modern">
              <Download className="h-4 w-4 mr-2" />
              Sample CSV
            </Button>
          </div>

          {parseError && (
            <ErrorAlert
              title="File Error"
              description={parseError}
              onRetry={() => {
                setParseError(null)
                const fileInput = document.getElementById("appliance-file-input") as HTMLInputElement
                if (fileInput) fileInput.value = ""
              }}
            />
          )}

          <div className="bg-blue-50 p-4 rounded-lg border border-blue-200">
            <div className="flex items-start space-x-2">
              <Info className="h-5 w-5 text-blue-600 mt-0.5 flex-shrink-0" />
              <div>
                <h4 className="font-medium text-blue-900 mb-2">CSV Format Requirements</h4>
                <ul className="text-sm text-blue-800 space-y-1">
                  <li>• Column order: Name, Power(W), Hours/Day, Days/Month, Category</li>
                  <li>• Power in watts (e.g., 1500 for AC, 75 for fan)</li>
                  <li>• Hours per day: 0-24 (e.g., 8 for AC, 12 for fan)</li>
                  <li>• Days per month: 1-31 (usually 30)</li>
                  <li>• Category: "essential" or "optional"</li>
                  <li>• No duplicate appliance names</li>
                </ul>
                <p className="text-sm text-blue-700 mt-2 font-medium">Example: Air Conditioner,1500,8,30,essential</p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Preview */}
      {preview.length > 0 && (
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
          <Card className="card-modern">
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle className="flex items-center space-x-2">
                    <FileSpreadsheet className="h-5 w-5 text-blue-600" />
                    <span>Import Preview</span>
                  </CardTitle>
                  <CardDescription>Review your appliances before importing</CardDescription>
                </div>
                <div className="flex items-center space-x-4">
                  <div className="flex items-center space-x-2">
                    <CheckCircle className="h-4 w-4 text-green-600" />
                    <span className="text-sm text-green-600 font-medium">{validCount} valid</span>
                  </div>
                  {invalidCount > 0 && (
                    <div className="flex items-center space-x-2">
                      <AlertCircle className="h-4 w-4 text-red-600" />
                      <span className="text-sm text-red-600 font-medium">{invalidCount} invalid</span>
                    </div>
                  )}
                </div>
              </div>
            </CardHeader>
            <CardContent>
              {loading ? (
                <div className="flex justify-center py-8">
                  <Loader2 className="h-8 w-8 animate-spin text-green-600" />
                </div>
              ) : (
                <>
                  <div className="overflow-x-auto max-h-96 overflow-y-auto">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Status</TableHead>
                          <TableHead>Name</TableHead>
                          <TableHead>Power (W)</TableHead>
                          <TableHead>Hours/Day</TableHead>
                          <TableHead>Days/Month</TableHead>
                          <TableHead>Category</TableHead>
                          <TableHead>Monthly kWh</TableHead>
                          <TableHead>Issues</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {preview.map((row, index) => (
                          <TableRow key={index}>
                            <TableCell>
                              <Badge variant={row.valid ? "default" : "destructive"} className="text-xs">
                                {row.valid ? "✓ Valid" : "✗ Invalid"}
                              </Badge>
                            </TableCell>
                            <TableCell className="font-medium capitalize">{row.name || "Missing"}</TableCell>
                            <TableCell>{isNaN(row.power) ? "Invalid" : `${row.power}W`}</TableCell>
                            <TableCell>{isNaN(row.hoursPerDay) ? "Invalid" : `${row.hoursPerDay}h`}</TableCell>
                            <TableCell>{isNaN(row.daysPerMonth) ? "Invalid" : `${row.daysPerMonth} days`}</TableCell>
                            <TableCell>
                              <Badge
                                variant={row.category === "essential" ? "default" : "secondary"}
                                className="text-xs"
                              >
                                {row.category}
                              </Badge>
                            </TableCell>
                            <TableCell>
                              {!isNaN(row.power) && !isNaN(row.hoursPerDay) && !isNaN(row.daysPerMonth)
                                ? `${((row.power * row.hoursPerDay * row.daysPerMonth) / 1000).toFixed(1)} kWh`
                                : "Invalid"}
                            </TableCell>
                            <TableCell>
                              {row.errors.length > 0 ? (
                                <div className="space-y-1">
                                  {row.errors.map((error, errorIndex) => (
                                    <div key={errorIndex} className="text-xs text-red-600 bg-red-50 p-1 rounded">
                                      {error}
                                    </div>
                                  ))}
                                </div>
                              ) : (
                                <span className="text-green-600 text-xs">No issues</span>
                              )}
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>

                  <div className="flex justify-between items-center mt-6">
                    <div className="text-sm text-gray-600">
                      {invalidCount > 0 && (
                        <p>⚠️ Fix the issues above before importing, or only valid appliances will be imported.</p>
                      )}
                    </div>
                    <div className="flex space-x-4">
                      <Button
                        variant="outline"
                        onClick={() => {
                          setFile(null)
                          setPreview([])
                          setParseError(null)
                          const fileInput = document.getElementById("appliance-file-input") as HTMLInputElement
                          if (fileInput) fileInput.value = ""
                        }}
                        className="btn-modern"
                      >
                        Cancel
                      </Button>
                      <Button
                        onClick={handleImport}
                        disabled={validCount === 0 || importing}
                        className="btn-modern bg-green-600 hover:bg-green-700 text-white"
                      >
                        {importing ? (
                          <>
                            <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                            Importing...
                          </>
                        ) : (
                          <>
                            <Upload className="h-4 w-4 mr-2" />
                            Import {validCount} Appliance{validCount !== 1 ? "s" : ""}
                          </>
                        )}
                      </Button>
                    </div>
                  </div>
                </>
              )}
            </CardContent>
          </Card>
        </motion.div>
      )}
    </div>
  )
}
