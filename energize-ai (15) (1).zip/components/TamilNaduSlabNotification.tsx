"use client"

import { useState, useEffect } from "react"
import { motion, AnimatePresence } from "framer-motion"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Button } from "@/components/ui/button"
import { X, Info } from "lucide-react"

interface TamilNaduSlabNotificationProps {
  isVisible: boolean
  onDismiss: () => void
}

export function TamilNaduSlabNotification({ isVisible, onDismiss }: TamilNaduSlabNotificationProps) {
  const [show, setShow] = useState(false)

  useEffect(() => {
    if (isVisible) {
      setShow(true)
    }
  }, [isVisible])

  const handleDismiss = () => {
    setShow(false)
    // Store dismissal in localStorage
    localStorage.setItem("tn-slab-notification-dismissed", "true")
    onDismiss()
  }

  if (!show) return null

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0, y: -20, scale: 0.95 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
        exit={{ opacity: 0, y: -20, scale: 0.95 }}
        transition={{ type: "spring", stiffness: 300, damping: 30 }}
        className="mb-4"
      >
        <Alert className="border-blue-200 bg-blue-50">
          <Info className="h-4 w-4 text-blue-600" />
          <div className="flex items-start justify-between">
            <AlertDescription className="text-blue-800 pr-8">
              <strong>ℹ️ Accurate Billing:</strong> Your estimated bill is calculated using Tamil Nadu's official LT-1
              Domestic Slab Rates, not average rates. This makes the bill more accurate and personalized.
            </AlertDescription>
            <Button
              variant="ghost"
              size="sm"
              onClick={handleDismiss}
              className="h-6 w-6 p-0 text-blue-600 hover:bg-blue-100 hover:text-blue-700 -mt-1"
            >
              <X className="h-4 w-4" />
            </Button>
          </div>
        </Alert>
      </motion.div>
    </AnimatePresence>
  )
}
