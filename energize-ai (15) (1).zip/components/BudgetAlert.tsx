"use client"

import { motion, AnimatePresence } from "framer-motion"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Button } from "@/components/ui/button"
import { X, AlertTriangle, Lightbulb } from "lucide-react"
import { formatExactCurrency } from "@/lib/constants"

interface BudgetAlertProps {
  isVisible: boolean
  budgetStatus: "under" | "near" | "over"
  message: string
  excessAmount?: number
  suggestions?: string[]
  onDismiss: () => void
}

export function BudgetAlert({
  isVisible,
  budgetStatus,
  message,
  excessAmount,
  suggestions,
  onDismiss,
}: BudgetAlertProps) {
  if (!isVisible) return null

  const getAlertVariant = () => {
    switch (budgetStatus) {
      case "over":
        return "destructive"
      case "near":
        return "default"
      default:
        return "default"
    }
  }

  const getIcon = () => {
    switch (budgetStatus) {
      case "over":
        return <AlertTriangle className="h-4 w-4" />
      case "near":
        return <AlertTriangle className="h-4 w-4" />
      default:
        return <Lightbulb className="h-4 w-4" />
    }
  }

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0, y: -50, scale: 0.95 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
        exit={{ opacity: 0, y: -50, scale: 0.95 }}
        transition={{ type: "spring", stiffness: 300, damping: 30 }}
        className="fixed top-20 left-1/2 transform -translate-x-1/2 z-50 w-full max-w-md mx-4"
      >
        <Alert variant={getAlertVariant()} className="shadow-lg border-2">
          <div className="flex items-start justify-between">
            <div className="flex items-start space-x-2">
              {getIcon()}
              <div className="flex-1">
                <AlertDescription className="font-medium mb-2">{message}</AlertDescription>

                {excessAmount && excessAmount > 0 && (
                  <div className="text-sm mb-2">
                    <span className="font-semibold">Excess amount: {formatExactCurrency(excessAmount)}</span>
                  </div>
                )}

                {suggestions && suggestions.length > 0 && (
                  <div className="space-y-1">
                    <p className="text-xs font-medium">💡 Quick tips:</p>
                    {suggestions.slice(0, 2).map((suggestion, index) => (
                      <p key={index} className="text-xs opacity-90">
                        • {suggestion}
                      </p>
                    ))}
                  </div>
                )}
              </div>
            </div>
            <Button variant="ghost" size="sm" onClick={onDismiss} className="h-6 w-6 p-0 hover:bg-transparent">
              <X className="h-4 w-4" />
            </Button>
          </div>
        </Alert>
      </motion.div>
    </AnimatePresence>
  )
}
