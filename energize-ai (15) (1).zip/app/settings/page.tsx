"use client"

import { useState, useEffect } from "react"
import { motion } from "framer-motion"
import { useForm } from "react-hook-form"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { useToast } from "@/hooks/use-toast"
import { Loader2, Save, Settings } from "lucide-react"
import { fetchUserSettings, saveUserSettings } from "@/lib/utils"
import { REGIONAL_RATES, isSlabBasedRegion, getBillingMethod } from "@/lib/constants"
import type { UserSettings } from "@/lib/types"
import { trackPageView } from "@/lib/analytics"
import { Badge } from "@/components/ui/badge"

export default function SettingsPage() {
  const [loading, setLoading] = useState(true)
  const [submitting, setSubmitting] = useState(false)
  const { toast } = useToast()

  const form = useForm<UserSettings>({
    defaultValues: {
      electricityRate: 8,
      region: "Other",
      name: "",
      monthlyBudget: 0,
    },
  })

  useEffect(() => {
    fetchSettings()
    trackPageView("settings")
  }, [])

  const fetchSettings = async () => {
    try {
      const settings = await fetchUserSettings()
      form.reset(settings)
    } catch (error) {
      console.error("Error fetching settings:", error)
    } finally {
      setLoading(false)
    }
  }

  const onSubmit = async (data: UserSettings) => {
    setSubmitting(true)
    try {
      await saveUserSettings(data)
      toast({
        title: "✅ Settings Saved!",
        description: form.watch("monthlyBudget")
          ? `Your preferences and monthly budget of ₹${form.watch("monthlyBudget")} have been updated.`
          : "Your preferences have been updated successfully.",
      })
    } catch (error) {
      console.error("Error saving settings:", error)
      toast({
        title: "Error",
        description: "Failed to save settings",
        variant: "destructive",
      })
    } finally {
      setSubmitting(false)
    }
  }

  const handleRegionChange = (region: string) => {
    form.setValue("region", region)
    if (region in REGIONAL_RATES) {
      form.setValue("electricityRate", REGIONAL_RATES[region as keyof typeof REGIONAL_RATES])
    }
  }

  if (loading) {
    return (
      <div className="space-y-6">
        <div className="flex items-center space-x-2">
          <Loader2 className="h-6 w-6 animate-spin" />
          <span>Loading settings...</span>
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
        <div className="flex items-center space-x-2 mb-6">
          <Settings className="h-8 w-8 text-blue-600" />
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Settings</h1>
            <p className="text-gray-600">Customize your electricity tracking preferences</p>
          </div>
        </div>
      </motion.div>

      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }}>
        <Card>
          <CardHeader>
            <CardTitle>Personal Information</CardTitle>
            <CardDescription>Optional details to personalize your experience</CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
              <div className="space-y-2">
                <Label htmlFor="name">Your Name (Optional)</Label>
                <Input id="name" placeholder="e.g., Rajesh Kumar" {...form.register("name")} className="w-full" />
              </div>
            </form>
          </CardContent>
        </Card>
      </motion.div>

      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }}>
        <Card>
          <CardHeader>
            <CardTitle>Electricity Rate Settings</CardTitle>
            <CardDescription>Set your local electricity rate for accurate cost calculations</CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="region">Your State/Region</Label>
                  <Select onValueChange={handleRegionChange} value={form.watch("region")}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select your state" />
                    </SelectTrigger>
                    <SelectContent>
                      {Object.entries(REGIONAL_RATES).map(([state, rate]) => (
                        <SelectItem key={state} value={state}>
                          {state} - {state === "Tamil Nadu" ? "Slab-based billing" : `₹${rate}/kWh`}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {/* Conditionally show electricity rate field */}
                {!isSlabBasedRegion(form.watch("region")) && (
                  <div className="space-y-2">
                    <Label htmlFor="electricityRate">Electricity Rate (₹/kWh)</Label>
                    <Input
                      id="electricityRate"
                      type="number"
                      step="0.1"
                      {...form.register("electricityRate", { valueAsNumber: true })}
                      className="w-full"
                    />
                    <p className="text-xs text-gray-600">
                      Check your electricity bill for the exact rate per unit (kWh)
                    </p>
                  </div>
                )}
              </div>

              {/* Show Tamil Nadu specific message */}
              {isSlabBasedRegion(form.watch("region")) && (
                <div className="bg-green-50 p-4 rounded-lg border border-green-200">
                  <div className="flex items-center space-x-2 mb-2">
                    <span className="text-green-600">👉</span>
                    <h4 className="font-medium text-green-800">Tamil Nadu Slab-Based Billing</h4>
                  </div>
                  <p className="text-sm text-green-700 mb-2">{getBillingMethod("Tamil Nadu").description}</p>
                  <div className="text-xs text-green-600">
                    <p>• 0-100 units: Free</p>
                    <p>• 101-200 units: ₹2.5/unit</p>
                    <p>• 201-400 units: ₹4.5/unit</p>
                    <p>• 401+ units: Higher slab rates apply</p>
                  </div>
                </div>
              )}

              {/* Add Monthly Budget field */}
              <div className="space-y-2 mt-4">
                <Label htmlFor="monthlyBudget" className="flex items-center space-x-2">
                  <span>Monthly Budget (₹)</span>
                  <Badge variant="outline" className="text-green-600">
                    New
                  </Badge>
                </Label>
                <Input
                  id="monthlyBudget"
                  type="number"
                  step="100"
                  {...form.register("monthlyBudget", { valueAsNumber: true })}
                  className="w-full"
                />
                <p className="text-xs text-gray-600">
                  Your target spending limit for electricity each month. Daily budget: ₹
                  {form.watch("monthlyBudget")
                    ? Math.round(
                        form.watch("monthlyBudget") /
                          new Date(new Date().getFullYear(), new Date().getMonth() + 1, 0).getDate(),
                      )
                    : 0}
                </p>
              </div>

              {/* Update the info section for non-Tamil Nadu users */}
              {!isSlabBasedRegion(form.watch("region")) && (
                <div className="bg-blue-50 p-4 rounded-lg border border-blue-200">
                  <h4 className="font-medium text-blue-800 mb-2">💡 How to find your electricity rate:</h4>
                  <ul className="text-sm text-blue-700 space-y-1">
                    <li>• Check your monthly electricity bill</li>
                    <li>• Look for "Rate per Unit" or "₹/kWh"</li>
                    <li>• It's usually between ₹5-12 per kWh in India</li>
                    <li>• Some states have different rates for different usage slabs</li>
                  </ul>
                </div>
              )}

              <Button type="submit" disabled={submitting} className="w-full bg-green-600 hover:bg-green-700">
                {submitting ? (
                  <>
                    <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                    Saving...
                  </>
                ) : (
                  <>
                    <Save className="h-4 w-4 mr-2" />
                    Save Settings
                  </>
                )}
              </Button>
            </form>
          </CardContent>
        </Card>
      </motion.div>

      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3 }}>
        <Card>
          <CardHeader>
            <CardTitle>About EnergizeAI</CardTitle>
            <CardDescription>Your personal electricity bill assistant</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-center">
                <div className="p-4 bg-green-50 rounded-lg">
                  <div className="text-2xl mb-2">📊</div>
                  <h4 className="font-medium">Track Usage</h4>
                  <p className="text-sm text-gray-600">Monitor daily electricity consumption</p>
                </div>
                <div className="p-4 bg-blue-50 rounded-lg">
                  <div className="text-2xl mb-2">💰</div>
                  <h4 className="font-medium">Save Money</h4>
                  <p className="text-sm text-gray-600">Get tips to reduce your bill</p>
                </div>
                <div className="p-4 bg-purple-50 rounded-lg">
                  <div className="text-2xl mb-2">🏠</div>
                  <h4 className="font-medium">Smart Home</h4>
                  <p className="text-sm text-gray-600">Optimize appliance usage</p>
                </div>
              </div>

              <div className="text-center text-sm text-gray-600">
                <p>Made with ❤️ for Indian households</p>
                <p>Version 2.0 - Now with smart cost tracking!</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </motion.div>
    </div>
  )
}
