"use client"

import type React from "react"

import { useState } from "react"
import { collection, addDoc, getDocs, query, where } from "firebase/firestore"
import { db } from "@/lib/firebase"
import Papa from "papaparse"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Badge } from "@/components/ui/badge"
import { CheckCircle, XCircle, Upload, Download, AlertTriangle } from "lucide-react"
import { useToast } from "@/hooks/use-toast"

interface ApplianceRow {
  name: string
  power: number
  hoursPerDay: number
  daysPerMonth: number
  category: "essential" | "optional"
}

interface ValidationResult {
  isValid: boolean
  errors: string[]
  data?: ApplianceRow
}

export default function ImportAppliancesPage() {
  const [file, setFile] = useState<File | null>(null)
  const [parsedData, setParsedData] = useState<ApplianceRow[]>([])
  const [validationResults, setValidationResults] = useState<ValidationResult[]>([])
  const [isLoading, setIsLoading] = useState(false)
  const [showPreview, setShowPreview] = useState(false)
  const { toast } = useToast()

  // Validate a single appliance row
  const validateRow = (row: any, index: number): ValidationResult => {
    const errors: string[] = []

    // Check if row has required fields
    if (!row.name || typeof row.name !== "string" || row.name.trim().length === 0) {
      errors.push(`Row ${index + 1}: Name is required`)
    }

    if (!row.power || isNaN(Number(row.power)) || Number(row.power) <= 0) {
      errors.push(`Row ${index + 1}: Power must be a positive number`)
    }

    if (
      !row.hoursPerDay ||
      isNaN(Number(row.hoursPerDay)) ||
      Number(row.hoursPerDay) < 0 ||
      Number(row.hoursPerDay) > 24
    ) {
      errors.push(`Row ${index + 1}: Hours per day must be between 0-24`)
    }

    if (
      !row.daysPerMonth ||
      isNaN(Number(row.daysPerMonth)) ||
      Number(row.daysPerMonth) < 0 ||
      Number(row.daysPerMonth) > 31
    ) {
      errors.push(`Row ${index + 1}: Days per month must be between 0-31`)
    }

    if (!row.category || !["essential", "optional"].includes(row.category.toLowerCase())) {
      errors.push(`Row ${index + 1}: Category must be either 'essential' or 'optional'`)
    }

    if (errors.length === 0) {
      const validData: ApplianceRow = {
        name: row.name.trim(),
        power: Number(row.power),
        hoursPerDay: Number(row.hoursPerDay),
        daysPerMonth: Number(row.daysPerMonth),
        category: row.category.toLowerCase() as "essential" | "optional",
      }

      return { isValid: true, errors: [], data: validData }
    }

    return { isValid: false, errors }
  }

  // Handle file selection
  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = event.target.files?.[0]
    if (selectedFile) {
      if (selectedFile.type !== "text/csv" && !selectedFile.name.endsWith(".csv")) {
        toast({
          title: "Invalid file type",
          description: "Please select a CSV file",
          variant: "destructive",
        })
        return
      }

      setFile(selectedFile)
      parseCSV(selectedFile)
    }
  }

  // Parse CSV file
  const parseCSV = (file: File) => {
    setIsLoading(true)

    Papa.parse(file, {
      header: true,
      skipEmptyLines: true,
      complete: (results) => {
        const data = results.data as any[]
        const validationResults = data.map((row, index) => validateRow(row, index))

        setValidationResults(validationResults)
        setParsedData(validationResults.filter((r) => r.isValid).map((r) => r.data!))
        setShowPreview(true)
        setIsLoading(false)

        toast({
          title: "File parsed successfully",
          description: `Found ${data.length} rows, ${validationResults.filter((r) => r.isValid).length} valid`,
        })
      },
      error: (error) => {
        console.error("CSV parsing error:", error)
        toast({
          title: "Parsing failed",
          description: "Failed to parse CSV file. Please check the format.",
          variant: "destructive",
        })
        setIsLoading(false)
      },
    })
  }

  // Check for duplicate names in Firestore
  const checkDuplicates = async (appliances: ApplianceRow[]): Promise<string[]> => {
    const duplicates: string[] = []

    for (const appliance of appliances) {
      const q = query(collection(db, "appliances"), where("name", "==", appliance.name))
      const querySnapshot = await getDocs(q)

      if (!querySnapshot.empty) {
        duplicates.push(appliance.name)
      }
    }

    return duplicates
  }

  // Import appliances to Firestore
  const handleImport = async () => {
    if (parsedData.length === 0) {
      toast({
        title: "No data to import",
        description: "Please upload and validate a CSV file first",
        variant: "destructive",
      })
      return
    }

    setIsLoading(true)

    try {
      // Check for duplicates
      const duplicates = await checkDuplicates(parsedData)

      if (duplicates.length > 0) {
        toast({
          title: "Duplicate appliances found",
          description: `The following appliances already exist: ${duplicates.join(", ")}`,
          variant: "destructive",
        })
        setIsLoading(false)
        return
      }

      // Import all appliances
      let successCount = 0
      let errorCount = 0

      for (const appliance of parsedData) {
        try {
          // Calculate monthly kWh and cost
          const monthlyKwh = (appliance.power * appliance.hoursPerDay * appliance.daysPerMonth) / 1000
          const monthlyCost = monthlyKwh * 5 // Default rate, will be recalculated based on region

          await addDoc(collection(db, "appliances"), {
            ...appliance,
            monthlyKwh,
            monthlyCost,
            createdAt: new Date(),
          })
          successCount++
        } catch (error) {
          console.error(`Error adding appliance ${appliance.name}:`, error)
          errorCount++
        }
      }

      if (successCount > 0) {
        toast({
          title: "Import successful!",
          description: `Successfully imported ${successCount} appliances${errorCount > 0 ? `, ${errorCount} failed` : ""}`,
        })

        // Reset form
        setFile(null)
        setParsedData([])
        setValidationResults([])
        setShowPreview(false)

        // Reset file input
        const fileInput = document.getElementById("csv-file") as HTMLInputElement
        if (fileInput) fileInput.value = ""
      }
    } catch (error) {
      console.error("Import error:", error)
      toast({
        title: "Import failed",
        description: "An error occurred while importing appliances",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  // Download sample CSV
  const downloadSampleCSV = () => {
    const sampleData = [
      ["name", "power", "hoursPerDay", "daysPerMonth", "category"],
      ["Air Conditioner", "1500", "8", "30", "essential"],
      ["Ceiling Fan", "75", "12", "30", "essential"],
      ["LED TV", "120", "5", "30", "optional"],
      ["Refrigerator", "150", "24", "30", "essential"],
      ["Water Heater", "2000", "2", "30", "essential"],
      ["Washing Machine", "500", "1", "15", "optional"],
      ["Microwave", "800", "0.5", "25", "optional"],
      ["Desktop Computer", "300", "6", "30", "optional"],
    ]

    const csvContent = sampleData.map((row) => row.join(",")).join("\n")
    const blob = new Blob([csvContent], { type: "text/csv" })
    const url = window.URL.createObjectURL(blob)
    const link = document.createElement("a")
    link.href = url
    link.download = "sample_appliances.csv"
    link.click()
    window.URL.revokeObjectURL(url)
  }

  return (
    <div className="container mx-auto p-6 max-w-6xl">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">Import Appliances</h1>
        <p className="text-gray-600">Upload a CSV file to bulk import your electrical appliances</p>
      </div>

      {/* Upload Section */}
      <Card className="mb-6">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Upload className="h-5 w-5" />
            Upload CSV File
          </CardTitle>
          <CardDescription>
            Select a CSV file with appliance data. Make sure it includes: name, power, hoursPerDay, daysPerMonth,
            category
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center gap-4">
            <input
              id="csv-file"
              type="file"
              accept=".csv"
              onChange={handleFileChange}
              className="block w-full text-sm text-gray-500 file:mr-4 file:py-2 file:px-4 file:rounded-lg file:border-0 file:text-sm file:font-medium file:bg-green-50 file:text-green-700 hover:file:bg-green-100 file:cursor-pointer cursor-pointer"
            />
            <Button variant="outline" onClick={downloadSampleCSV} className="flex items-center gap-2 whitespace-nowrap">
              <Download className="h-4 w-4" />
              Sample CSV
            </Button>
          </div>

          {file && (
            <Alert>
              <CheckCircle className="h-4 w-4" />
              <AlertDescription>
                Selected file: <strong>{file.name}</strong> ({(file.size / 1024).toFixed(1)} KB)
              </AlertDescription>
            </Alert>
          )}
        </CardContent>
      </Card>

      {/* Validation Results */}
      {validationResults.length > 0 && (
        <Card className="mb-6">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <AlertTriangle className="h-5 w-5" />
              Validation Results
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
              <div className="text-center p-4 bg-green-50 rounded-lg">
                <div className="text-2xl font-bold text-green-600">
                  {validationResults.filter((r) => r.isValid).length}
                </div>
                <div className="text-sm text-green-700">Valid Rows</div>
              </div>
              <div className="text-center p-4 bg-red-50 rounded-lg">
                <div className="text-2xl font-bold text-red-600">
                  {validationResults.filter((r) => !r.isValid).length}
                </div>
                <div className="text-sm text-red-700">Invalid Rows</div>
              </div>
              <div className="text-center p-4 bg-blue-50 rounded-lg">
                <div className="text-2xl font-bold text-blue-600">{validationResults.length}</div>
                <div className="text-sm text-blue-700">Total Rows</div>
              </div>
            </div>

            {/* Show validation errors */}
            {validationResults.some((r) => !r.isValid) && (
              <div className="space-y-2">
                <h4 className="font-medium text-red-700">Validation Errors:</h4>
                {validationResults
                  .filter((r) => !r.isValid)
                  .map((result, index) => (
                    <Alert key={index} variant="destructive">
                      <XCircle className="h-4 w-4" />
                      <AlertDescription>{result.errors.join(", ")}</AlertDescription>
                    </Alert>
                  ))}
              </div>
            )}
          </CardContent>
        </Card>
      )}

      {/* Preview Table */}
      {showPreview && parsedData.length > 0 && (
        <Card className="mb-6">
          <CardHeader>
            <CardTitle>Preview - Valid Appliances ({parsedData.length})</CardTitle>
            <CardDescription>These appliances will be imported to your account</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <table className="w-full border-collapse border border-gray-200 rounded-lg">
                <thead>
                  <tr className="bg-gray-50">
                    <th className="border border-gray-200 px-4 py-2 text-left">Name</th>
                    <th className="border border-gray-200 px-4 py-2 text-left">Power (W)</th>
                    <th className="border border-gray-200 px-4 py-2 text-left">Hours/Day</th>
                    <th className="border border-gray-200 px-4 py-2 text-left">Days/Month</th>
                    <th className="border border-gray-200 px-4 py-2 text-left">Category</th>
                    <th className="border border-gray-200 px-4 py-2 text-left">Monthly kWh</th>
                  </tr>
                </thead>
                <tbody>
                  {parsedData.map((appliance, index) => {
                    const monthlyKwh = (appliance.power * appliance.hoursPerDay * appliance.daysPerMonth) / 1000
                    return (
                      <tr key={index} className="hover:bg-gray-50">
                        <td className="border border-gray-200 px-4 py-2 font-medium">{appliance.name}</td>
                        <td className="border border-gray-200 px-4 py-2">{appliance.power}W</td>
                        <td className="border border-gray-200 px-4 py-2">{appliance.hoursPerDay}h</td>
                        <td className="border border-gray-200 px-4 py-2">{appliance.daysPerMonth} days</td>
                        <td className="border border-gray-200 px-4 py-2">
                          <Badge variant={appliance.category === "essential" ? "default" : "secondary"}>
                            {appliance.category}
                          </Badge>
                        </td>
                        <td className="border border-gray-200 px-4 py-2">{monthlyKwh.toFixed(1)} kWh</td>
                      </tr>
                    )
                  })}
                </tbody>
              </table>
            </div>

            <div className="mt-6 flex justify-end">
              <Button
                onClick={handleImport}
                disabled={isLoading || parsedData.length === 0}
                className="bg-green-600 hover:bg-green-700 text-white"
              >
                {isLoading ? "Importing..." : `Import ${parsedData.length} Appliances`}
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Instructions */}
      <Card>
        <CardHeader>
          <CardTitle>CSV Format Instructions</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div>
              <h4 className="font-medium mb-2">Required Columns:</h4>
              <ul className="list-disc list-inside space-y-1 text-sm text-gray-600">
                <li>
                  <strong>name</strong> - Appliance name (e.g., "Air Conditioner")
                </li>
                <li>
                  <strong>power</strong> - Power consumption in watts (e.g., 1500)
                </li>
                <li>
                  <strong>hoursPerDay</strong> - Daily usage hours (0-24)
                </li>
                <li>
                  <strong>daysPerMonth</strong> - Monthly usage days (1-31)
                </li>
                <li>
                  <strong>category</strong> - Either "essential" or "optional"
                </li>
              </ul>
            </div>

            <div>
              <h4 className="font-medium mb-2">Example CSV Content:</h4>
              <pre className="bg-gray-100 p-3 rounded text-sm overflow-x-auto">
                {`name,power,hoursPerDay,daysPerMonth,category
Air Conditioner,1500,8,30,essential
Ceiling Fan,75,12,30,essential
LED TV,120,5,30,optional`}
              </pre>
            </div>

            <Alert>
              <AlertTriangle className="h-4 w-4" />
              <AlertDescription>
                <strong>Note:</strong> Duplicate appliance names will be rejected. Make sure each appliance has a unique
                name.
              </AlertDescription>
            </Alert>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
