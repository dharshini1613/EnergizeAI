"use client"

import { useState, useEffect } from "react"
import { motion } from "framer-motion"
import { collection, query, orderBy, limit, getDocs } from "firebase/firestore"
import { db } from "@/lib/firebase"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Skeleton } from "@/components/ui/skeleton"
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts"
import { Zap, TrendingUp, DollarSign, Calendar, Activity } from "lucide-react"
import { calculateUsage } from "@/lib/utils"
import { ELECTRICITY_RATE_PER_KWH, formatCurrency, getBillingMethod } from "@/lib/constants"
import { AIInsights } from "@/components/ai-insights"
import { PredictionCard } from "@/components/prediction-card"
import type { MeterReading, UsageSummary } from "@/lib/types"
import { trackPageView } from "@/lib/analytics"

export default function Dashboard() {
  const [readings, setReadings] = useState<MeterReading[]>([])
  const [appliances, setAppliances] = useState<any[]>([])
  const [summary, setSummary] = useState<UsageSummary | null>(null)
  const [loading, setLoading] = useState(true)
  const [settings, setSettings] = useState<{ region: string } | null>(null)

  useEffect(() => {
    fetchData()
    trackPageView("dashboard")
  }, [])

  const fetchData = async () => {
    try {
      // Fetch recent readings
      const readingsQuery = query(collection(db, "readings"), orderBy("createdAt", "desc"), limit(30))
      const readingsSnapshot = await getDocs(readingsQuery)
      const readingsData = readingsSnapshot.docs.map((doc) => ({
        id: doc.id,
        ...doc.data(),
      })) as MeterReading[]

      // Fetch appliances
      const appliancesQuery = query(collection(db, "appliances"), orderBy("createdAt", "desc"))
      const appliancesSnapshot = await getDocs(appliancesQuery)
      const appliancesData = appliancesSnapshot.docs.map((doc) => ({
        id: doc.id,
        ...doc.data(),
      }))

      // Fetch settings (assuming you have a 'settings' collection)
      const settingsQuery = query(collection(db, "settings"), limit(1)) // Assuming only one settings document
      const settingsSnapshot = await getDocs(settingsQuery)
      const settingsData = settingsSnapshot.docs.map((doc) => ({
        id: doc.id,
        ...doc.data(),
      }))[0] // Get the first settings document

      setSettings(settingsData || null)

      const readingsWithUsage = calculateUsage(readingsData.reverse(), settings?.region)
      setReadings(readingsWithUsage)
      setAppliances(appliancesData)

      // Calculate summary with Indian Rupees
      const totalUsage = readingsWithUsage.reduce((sum, reading) => sum + (reading.usage || 0), 0)
      const dailyAvg = totalUsage / Math.max(readingsWithUsage.length - 1, 1)
      const estimatedBill = totalUsage * ELECTRICITY_RATE_PER_KWH // ₹8 per kWh

      setSummary({
        totalUsageThisMonth: totalUsage,
        dailyAverage: dailyAvg,
        estimatedBill,
        usageLevel: totalUsage < 300 ? "low" : totalUsage < 600 ? "medium" : "high",
      })
    } catch (error) {
      console.error("Error fetching data:", error)
    } finally {
      setLoading(false)
    }
  }

  const chartData = readings.slice(-7).map((reading, index) => ({
    date: new Date(reading.date).toLocaleDateString(),
    usage: reading.usage || 0,
    reading: reading.reading,
  }))

  const readingValues = readings.map((r) => r.reading).filter((r) => !isNaN(r))

  if (loading) {
    return (
      <div className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {[...Array(4)].map((_, i) => (
            <Card key={i}>
              <CardHeader className="pb-2">
                <Skeleton className="h-4 w-24" />
              </CardHeader>
              <CardContent>
                <Skeleton className="h-8 w-16 mb-2" />
                <Skeleton className="h-3 w-20" />
              </CardContent>
            </Card>
          ))}
        </div>
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <Card>
            <CardHeader>
              <Skeleton className="h-6 w-32" />
            </CardHeader>
            <CardContent>
              <Skeleton className="h-64 w-full" />
            </CardContent>
          </Card>
          <Card>
            <CardHeader>
              <Skeleton className="h-6 w-32" />
            </CardHeader>
            <CardContent>
              <Skeleton className="h-64 w-full" />
            </CardContent>
          </Card>
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="flex items-center justify-between"
      >
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Energy Dashboard</h1>
          <p className="text-gray-600">Monitor your energy consumption with AI-powered insights</p>
        </div>
        <Badge
          variant={
            summary?.usageLevel === "low" ? "default" : summary?.usageLevel === "medium" ? "secondary" : "destructive"
          }
          className="text-sm"
        >
          {summary?.usageLevel?.toUpperCase()} USAGE
        </Badge>
        {settings && (
          <Badge variant="outline" className="text-blue-600 border-blue-200 ml-2">
            {getBillingMethod(settings.region).description}
          </Badge>
        )}
      </motion.div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }}>
          <Card className="bg-gradient-to-br from-green-50 to-green-100 border-green-200">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-green-700">Total Usage This Month</CardTitle>
              <Zap className="h-4 w-4 text-green-600" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-green-800">
                {summary?.totalUsageThisMonth.toFixed(1) || "0"} kWh
              </div>
              <p className="text-xs text-green-600">Energy consumed this period</p>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }}>
          <Card className="bg-gradient-to-br from-blue-50 to-blue-100 border-blue-200">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-blue-700">Daily Average</CardTitle>
              <Activity className="h-4 w-4 text-blue-600" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-blue-800">{summary?.dailyAverage.toFixed(1) || "0"} kWh</div>
              <p className="text-xs text-blue-600">Average daily consumption</p>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3 }}>
          <Card className="bg-gradient-to-br from-purple-50 to-purple-100 border-purple-200">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-purple-700">Estimated Bill</CardTitle>
              <DollarSign className="h-4 w-4 text-purple-600" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-purple-800">{formatCurrency(summary?.estimatedBill || 0)}</div>
              <p className="text-xs text-purple-600">Based on ₹{ELECTRICITY_RATE_PER_KWH}/kWh</p>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.4 }}>
          <Card className="bg-gradient-to-br from-orange-50 to-orange-100 border-orange-200">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-orange-700">Total Readings</CardTitle>
              <Calendar className="h-4 w-4 text-orange-600" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-orange-800">{readings.length}</div>
              <p className="text-xs text-orange-600">Meter readings recorded</p>
            </CardContent>
          </Card>
        </motion.div>
      </div>

      {/* Charts and AI Insights */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Usage Trend Chart */}
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.5 }}>
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <TrendingUp className="h-5 w-5 text-green-600" />
                <span>Usage Trend (Last 7 Days)</span>
              </CardTitle>
              <CardDescription>Daily energy consumption pattern</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-64">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={chartData}>
                    <CartesianGrid strokeDasharray="3 3" className="opacity-30" />
                    <XAxis dataKey="date" className="text-xs" tick={{ fontSize: 12 }} />
                    <YAxis className="text-xs" tick={{ fontSize: 12 }} />
                    <Tooltip
                      contentStyle={{
                        backgroundColor: "white",
                        border: "1px solid #e5e7eb",
                        borderRadius: "8px",
                        boxShadow: "0 4px 6px -1px rgba(0, 0, 0, 0.1)",
                      }}
                    />
                    <Line
                      type="monotone"
                      dataKey="usage"
                      stroke="#10b981"
                      strokeWidth={3}
                      dot={{ fill: "#10b981", strokeWidth: 2, r: 4 }}
                      activeDot={{ r: 6, stroke: "#10b981", strokeWidth: 2 }}
                    />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>
        </motion.div>

        {/* AI Prediction */}
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.6 }}>
          <PredictionCard readings={readingValues} />
        </motion.div>
      </div>

      {/* AI Insights */}
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.7 }}>
        <AIInsights readings={readings} appliances={appliances} />
      </motion.div>
    </div>
  )
}
