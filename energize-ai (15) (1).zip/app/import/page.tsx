"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { motion } from "framer-motion"
import { collection, writeBatch, doc } from "firebase/firestore"
import { db } from "@/lib/firebase"
import { validateCSVRow } from "@/lib/validation"
import { errorMessages, getErrorMessage } from "@/lib/errorMessages"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import { ErrorAlert } from "@/components/ui/error-alert"
import { useToast } from "@/hooks/use-toast"
import { Loader2, Upload, FileSpreadsheet, CheckCircle, AlertCircle, Info, Download } from "lucide-react"
import { trackDataImport, trackPageView } from "@/lib/analytics"

interface ImportRow {
  date: string
  time: string
  reading: number
  valid: boolean
  errors: string[]
}

export default function Import() {
  const [file, setFile] = useState<File | null>(null)
  const [preview, setPreview] = useState<ImportRow[]>([])
  const [loading, setLoading] = useState(false)
  const [importing, setImporting] = useState(false)
  const [parseError, setParseError] = useState<string | null>(null)
  const { toast } = useToast()

  useEffect(() => {
    trackPageView("import")
  }, [])

  const handleFileChange = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = event.target.files?.[0]
    if (!selectedFile) return

    setFile(selectedFile)
    setLoading(true)
    setParseError(null)

    try {
      // Validate file type
      if (!selectedFile.name.toLowerCase().endsWith(".csv")) {
        setParseError(errorMessages.import.invalidFormat)
        return
      }

      // Check file size (max 5MB)
      if (selectedFile.size > 5 * 1024 * 1024) {
        setParseError("File is too large. Please use files smaller than 5MB.")
        return
      }

      const text = await selectedFile.text()

      if (!text.trim()) {
        setParseError(errorMessages.import.emptyFile)
        return
      }

      const rows = text.split("\n").filter((row) => row.trim())

      if (rows.length === 0) {
        setParseError(errorMessages.import.emptyFile)
        return
      }

      // Skip header row if it exists (detect if first row contains non-numeric data in reading column)
      let dataRows = rows
      if (rows.length > 0) {
        const firstRowCols = rows[0].split(",").map((col) => col.trim())
        if (firstRowCols.length >= 3 && isNaN(Number.parseFloat(firstRowCols[2]))) {
          dataRows = rows.slice(1)
        }
      }

      if (dataRows.length === 0) {
        setParseError("No data rows found. Please check your file format.")
        return
      }

      if (dataRows.length > 1000) {
        setParseError(errorMessages.import.tooManyRows)
        return
      }

      const parsedData: ImportRow[] = dataRows.map((row, index) => {
        const columns = row.split(",").map((col) => col.trim().replace(/"/g, ""))
        const validation = validateCSVRow(columns, index)

        return {
          date: columns[0] || "",
          time: columns[1] || "",
          reading: columns[2] ? Number.parseFloat(columns[2]) : 0,
          valid: validation.valid,
          errors: validation.errors,
        }
      })

      setPreview(parsedData)
    } catch (error) {
      console.error("Error parsing file:", error)
      setParseError(errorMessages.import.parseError)
    } finally {
      setLoading(false)
    }
  }

  const handleImport = async () => {
    const validRows = preview.filter((row) => row.valid)

    if (validRows.length === 0) {
      toast({
        title: "No Valid Data",
        description: "Please fix the errors in your file before importing.",
        variant: "destructive",
      })
      return
    }

    setImporting(true)

    try {
      const batch = writeBatch(db)

      validRows.forEach((row) => {
        const docRef = doc(collection(db, "readings"))
        batch.set(docRef, {
          date: row.date,
          time: row.time,
          reading: row.reading,
          createdAt: new Date(),
        })
      })

      await batch.commit()

      // Track the import
      trackDataImport(validRows.length)

      toast({
        title: "✅ Import Successful",
        description: `Successfully imported ${validRows.length} meter readings. You can now view them in your readings page.`,
      })

      // Reset form
      setFile(null)
      setPreview([])
      setParseError(null)
      const fileInput = document.getElementById("file-input") as HTMLInputElement
      if (fileInput) fileInput.value = ""
    } catch (error) {
      console.error("Error importing data:", error)
      const errorMsg = getErrorMessage(error)
      toast({
        title: errorMsg.title,
        description: errorMsg.description,
        variant: "destructive",
      })
    } finally {
      setImporting(false)
    }
  }

  const downloadSampleCSV = () => {
    const sampleData = [
      "Date,Time,Reading",
      "2024-01-15,09:30,1250.5",
      "2024-01-16,09:30,1265.2",
      "2024-01-17,09:30,1278.8",
    ].join("\n")

    const blob = new Blob([sampleData], { type: "text/csv" })
    const url = URL.createObjectURL(blob)
    const a = document.createElement("a")
    a.href = url
    a.download = "sample-meter-readings.csv"
    a.click()
    URL.revokeObjectURL(url)

    toast({
      title: "Sample Downloaded",
      description: "Use this sample file as a template for your meter readings.",
    })
  }

  const validCount = preview.filter((row) => row.valid).length
  const invalidCount = preview.length - validCount

  return (
    <div className="space-y-6">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="flex items-center justify-between"
      >
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Import Readings</h1>
          <p className="text-gray-600">Upload CSV files to import multiple meter readings at once</p>
        </div>
        <Button variant="outline" onClick={downloadSampleCSV} className="hidden sm:flex">
          <Download className="h-4 w-4 mr-2" />
          Download Sample
        </Button>
      </motion.div>

      {/* File Upload */}
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }}>
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Upload className="h-5 w-5 text-green-600" />
              <span>Upload CSV File</span>
            </CardTitle>
            <CardDescription>
              Upload a CSV file with your meter readings. Make sure to follow the format requirements below.
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="file-input">Select CSV File (max 5MB, 1000 rows)</Label>
              <Input id="file-input" type="file" accept=".csv" onChange={handleFileChange} className="w-full" />
            </div>

            {parseError && (
              <ErrorAlert
                title="File Error"
                description={parseError}
                onRetry={() => {
                  setParseError(null)
                  const fileInput = document.getElementById("file-input") as HTMLInputElement
                  if (fileInput) fileInput.value = ""
                }}
              />
            )}

            <div className="bg-blue-50 p-4 rounded-lg">
              <div className="flex items-start space-x-2">
                <Info className="h-5 w-5 text-blue-600 mt-0.5 flex-shrink-0" />
                <div>
                  <h4 className="font-medium text-blue-900 mb-2">{errorMessages.csvFormat.title}</h4>
                  <ul className="text-sm text-blue-800 space-y-1">
                    {errorMessages.csvFormat.requirements.map((req, index) => (
                      <li key={index}>• {req}</li>
                    ))}
                  </ul>
                  <p className="text-sm text-blue-700 mt-2 font-medium">{errorMessages.csvFormat.example}</p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </motion.div>

      {/* Preview */}
      {preview.length > 0 && (
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }}>
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle className="flex items-center space-x-2">
                    <FileSpreadsheet className="h-5 w-5 text-blue-600" />
                    <span>Import Preview</span>
                  </CardTitle>
                  <CardDescription>Review your data before importing</CardDescription>
                </div>
                <div className="flex items-center space-x-4">
                  <div className="flex items-center space-x-2">
                    <CheckCircle className="h-4 w-4 text-green-600" />
                    <span className="text-sm text-green-600 font-medium">{validCount} valid</span>
                  </div>
                  {invalidCount > 0 && (
                    <div className="flex items-center space-x-2">
                      <AlertCircle className="h-4 w-4 text-red-600" />
                      <span className="text-sm text-red-600 font-medium">{invalidCount} invalid</span>
                    </div>
                  )}
                </div>
              </div>
            </CardHeader>
            <CardContent>
              {loading ? (
                <div className="flex justify-center py-8">
                  <Loader2 className="h-8 w-8 animate-spin text-green-600" />
                </div>
              ) : (
                <>
                  <div className="overflow-x-auto max-h-96 overflow-y-auto">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Status</TableHead>
                          <TableHead>Date</TableHead>
                          <TableHead>Time</TableHead>
                          <TableHead>Reading (kWh)</TableHead>
                          <TableHead>Issues</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {preview.map((row, index) => (
                          <TableRow key={index}>
                            <TableCell>
                              <Badge variant={row.valid ? "default" : "destructive"}>
                                {row.valid ? "✓ Valid" : "✗ Invalid"}
                              </Badge>
                            </TableCell>
                            <TableCell>{row.date || "Missing"}</TableCell>
                            <TableCell>{row.time || "Missing"}</TableCell>
                            <TableCell>{isNaN(row.reading) ? "Invalid" : row.reading}</TableCell>
                            <TableCell>
                              {row.errors.length > 0 ? (
                                <div className="space-y-1">
                                  {row.errors.map((error, errorIndex) => (
                                    <div key={errorIndex} className="text-xs text-red-600 bg-red-50 p-1 rounded">
                                      {error}
                                    </div>
                                  ))}
                                </div>
                              ) : (
                                <span className="text-green-600 text-xs">No issues</span>
                              )}
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>

                  <div className="flex justify-between items-center mt-6">
                    <div className="text-sm text-gray-600">
                      {invalidCount > 0 && (
                        <p>⚠️ Fix the issues above before importing, or only valid rows will be imported.</p>
                      )}
                    </div>
                    <div className="flex space-x-4">
                      <Button
                        variant="outline"
                        onClick={() => {
                          setFile(null)
                          setPreview([])
                          setParseError(null)
                          const fileInput = document.getElementById("file-input") as HTMLInputElement
                          if (fileInput) fileInput.value = ""
                        }}
                      >
                        Cancel
                      </Button>
                      <Button
                        onClick={handleImport}
                        disabled={validCount === 0 || importing}
                        className="bg-green-600 hover:bg-green-700"
                      >
                        {importing ? (
                          <>
                            <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                            Importing...
                          </>
                        ) : (
                          <>
                            <Upload className="h-4 w-4 mr-2" />
                            Import {validCount} Reading{validCount !== 1 ? "s" : ""}
                          </>
                        )}
                      </Button>
                    </div>
                  </div>
                </>
              )}
            </CardContent>
          </Card>
        </motion.div>
      )}
    </div>
  )
}
