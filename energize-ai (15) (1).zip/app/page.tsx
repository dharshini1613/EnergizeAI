"use client"

import { useState, useEffect } from "react"
import { motion } from "framer-motion"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Skeleton } from "@/components/ui/skeleton"
import { TrendingUp, TrendingDown, Zap, Calendar, Settings, Plus } from "lucide-react"
import { fetchReadings, fetchUserSettings, getDashboardSummary, fetchAppliances, generateAIInsights } from "@/lib/utils"
import { formatCurrency, formatExactCurrency, getBillingMethod } from "@/lib/constants"
import { trackPageView, trackBudgetExceeded } from "@/lib/analytics"
import { OnboardingModal } from "@/components/OnboardingModal"
import { BudgetAlert } from "@/components/BudgetAlert"
import { TamilNaduSlabNotification } from "@/components/TamilNaduSlabNotification"
import { CostDisplay } from "@/components/CostDisplay"
import { UsageChart } from "@/components/UsageChart"
import { ApplianceBreakdown } from "@/components/ApplianceBreakdown"
import { MonthlyReportGenerator } from "@/components/MonthlyReportGenerator"
import type { UserSettings, DashboardSummary, AIInsight } from "@/lib/types"
import Link from "next/link"
import { TamilNaduBillingInfo } from "@/components/TamilNaduBillingInfo"

export default function Dashboard() {
  const [summary, setSummary] = useState<DashboardSummary | null>(null)
  const [insights, setInsights] = useState<AIInsight | null>(null)
  const [settings, setSettings] = useState<UserSettings | null>(null)
  const [readings, setReadings] = useState<any[]>([])
  const [appliances, setAppliances] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [showOnboarding, setShowOnboarding] = useState(false)
  const [showBudgetAlert, setShowBudgetAlert] = useState(false)
  const [showTNNotification, setShowTNNotification] = useState(false)

  useEffect(() => {
    fetchDashboardData()
    trackPageView("dashboard")
  }, [])

  useEffect(() => {
    // Check if Tamil Nadu notification should be shown
    if (settings?.region === "Tamil Nadu") {
      const dismissed = localStorage.getItem("tn-slab-notification-dismissed")
      if (!dismissed) {
        setShowTNNotification(true)
      }
    }
  }, [settings])

  const fetchDashboardData = async () => {
    try {
      const [readingsData, userSettings, appliancesData] = await Promise.all([
        fetchReadings(),
        fetchUserSettings(),
        fetchAppliances(),
      ])

      setSettings(userSettings)
      setReadings(readingsData)
      setAppliances(appliancesData)

      // Check if onboarding is needed
      if (!userSettings.onboardingComplete) {
        setShowOnboarding(true)
        setLoading(false)
        return
      }

      if (readingsData.length > 0) {
        const dashboardSummary = getDashboardSummary(readingsData, userSettings)
        setSummary(dashboardSummary)

        // Generate AI insights
        const aiInsights = generateAIInsights(readingsData, appliancesData)
        setInsights(aiInsights)

        // Check budget alert
        if (dashboardSummary.budgetStatus === "over") {
          setShowBudgetAlert(true)
          trackBudgetExceeded(dashboardSummary.todayCost - (userSettings.dailyBudget || 100))
        }
      }
    } catch (error) {
      console.error("Error fetching dashboard data:", error)
    } finally {
      setLoading(false)
    }
  }

  const handleOnboardingComplete = (newSettings: UserSettings) => {
    setSettings(newSettings)
    setShowOnboarding(false)
    fetchDashboardData()
  }

  if (showOnboarding) {
    return <OnboardingModal isOpen={true} onComplete={handleOnboardingComplete} />
  }

  if (loading) {
    return (
      <div className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {[...Array(4)].map((_, i) => (
            <Card key={i} className="card-modern">
              <CardHeader className="pb-2">
                <Skeleton className="h-4 w-24" />
              </CardHeader>
              <CardContent>
                <Skeleton className="h-8 w-16 mb-2" />
                <Skeleton className="h-3 w-20" />
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    )
  }

  if (!summary) {
    return (
      <div className="text-center py-12">
        <Zap className="h-16 w-16 text-gray-300 mx-auto mb-4" />
        <h2 className="text-2xl font-bold text-gray-900 mb-2">Welcome to EnergizeAI!</h2>
        <p className="text-gray-600 mb-6">
          Start by adding your first meter reading to track your electricity usage and stay within budget.
        </p>
        <Link href="/readings">
          <Button className="btn-modern bg-primary-green hover:bg-green-600 text-white">
            <Plus className="h-4 w-4 mr-2" />
            Add First Reading
          </Button>
        </Link>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 via-white to-green-50">
      <div className="container mx-auto px-4 py-8 space-y-8">
        {/* Tamil Nadu Slab Notification */}
        {settings?.region === "Tamil Nadu" && (
          <TamilNaduSlabNotification isVisible={showTNNotification} onDismiss={() => setShowTNNotification(false)} />
        )}

        {/* Tamil Nadu Billing Information */}
        {settings?.region === "Tamil Nadu" && (
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.05 }}>
            <TamilNaduBillingInfo region={settings.region} />
          </motion.div>
        )}

        {/* Budget Alert */}
        <BudgetAlert
          isVisible={showBudgetAlert}
          budgetStatus={summary.budgetStatus}
          message={summary.budgetMessage}
          excessAmount={
            summary.budgetStatus === "over" ? summary.todayCost - (settings?.dailyBudget || 100) : undefined
          }
          suggestions={insights?.recommendations.slice(0, 2)}
          onDismiss={() => setShowBudgetAlert(false)}
        />

        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex items-center justify-between"
        >
          <div>
            <h1 className="text-4xl font-bold text-gray-900 mb-2">
              {settings?.name ? `Welcome back, ${settings.name}!` : "Your Energy Dashboard"}
            </h1>
            <p className="text-lg text-gray-600">
              Track your daily usage and stay within your ₹{settings?.monthlyBudget} monthly budget
            </p>
          </div>
          <div className="flex items-center space-x-2">
            {settings && (
              <Badge variant="outline" className="text-blue-600 border-blue-200">
                {getBillingMethod(settings.region).description}
              </Badge>
            )}
            <Link href="/settings">
              <Button variant="outline" size="sm" className="btn-modern bg-primary-green hover:bg-green-600 text-white">
                <Settings className="h-4 w-4 mr-2" />
                Settings
              </Button>
            </Link>
          </div>
        </motion.div>

        {/* Today's Summary */}
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }}>
          <Card
            className={`card-modern border-2 ${
              summary.budgetStatus === "under"
                ? "border-green-200 bg-gradient-to-r from-green-50 to-blue-50"
                : summary.budgetStatus === "near"
                  ? "border-yellow-200 bg-gradient-to-r from-yellow-50 to-orange-50"
                  : "border-red-200 bg-gradient-to-r from-red-50 to-pink-50"
            }`}
          >
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Calendar className="h-5 w-5 text-blue-600" />
                <span>Today's Usage</span>
                <span className="text-2xl">{summary.budgetEmoji}</span>
                <Badge
                  variant={
                    summary.budgetStatus === "under"
                      ? "default"
                      : summary.budgetStatus === "near"
                        ? "secondary"
                        : "destructive"
                  }
                >
                  {summary.budgetStatus === "under"
                    ? "Under Budget"
                    : summary.budgetStatus === "near"
                      ? "Near Budget"
                      : "Over Budget"}
                </Badge>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div>
                  <p className="text-sm text-gray-600">Energy Used</p>
                  <p className="text-2xl font-bold text-blue-800">{summary.todayUsage.toFixed(1)} kWh</p>
                </div>
                <div>
                  <p className="text-sm text-gray-600">Cost Today</p>
                  <CostDisplay
                    amount={summary.todayCost}
                    region={settings?.region || "Other"}
                    showBadge={false}
                    exact={true}
                    className="text-green-800"
                    units={summary.todayUsage} // Today's usage in units
                  />
                </div>
                <div>
                  <p className="text-sm text-gray-600">Daily Budget</p>
                  <p className="text-2xl font-bold text-purple-800">
                    {formatExactCurrency(settings?.dailyBudget || 100)}
                  </p>
                </div>
                <div>
                  <p className="text-sm text-gray-600">vs Yesterday</p>
                  <div className="flex items-center space-x-1">
                    {summary.savings > 0 ? (
                      <>
                        <TrendingDown className="h-4 w-4 text-green-600" />
                        <span className="text-green-600 font-semibold">Saved {formatCurrency(summary.savings)}</span>
                      </>
                    ) : summary.savings < 0 ? (
                      <>
                        <TrendingUp className="h-4 w-4 text-red-600" />
                        <span className="text-red-600 font-semibold">+{formatCurrency(Math.abs(summary.savings))}</span>
                      </>
                    ) : (
                      <span className="text-gray-600">Same as yesterday</span>
                    )}
                  </div>
                </div>
              </div>

              <div
                className="mt-4 p-3 rounded-lg border"
                style={{
                  backgroundColor:
                    summary.budgetStatus === "under"
                      ? "#dcfce7"
                      : summary.budgetStatus === "near"
                        ? "#fef3c7"
                        : "#fee2e2",
                  borderColor:
                    summary.budgetStatus === "under"
                      ? "#16a34a"
                      : summary.budgetStatus === "near"
                        ? "#d97706"
                        : "#dc2626",
                }}
              >
                <p
                  className="font-medium"
                  style={{
                    color:
                      summary.budgetStatus === "under"
                        ? "#15803d"
                        : summary.budgetStatus === "near"
                          ? "#92400e"
                          : "#991b1b",
                  }}
                >
                  {summary.budgetMessage}
                </p>
              </div>
            </CardContent>
          </Card>
        </motion.div>

        {/* Quick Stats */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }}>
            <Card className="card-modern">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium text-gray-700">Weekly Average</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-blue-600">{summary.weeklyAverage.toFixed(1)} kWh/day</div>
                <p className="text-xs text-gray-600">
                  {formatCurrency(summary.weeklyAverage * (settings?.electricityRate || 8))}/day
                </p>
              </CardContent>
            </Card>
          </motion.div>

          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3 }}>
            <Card className="card-modern">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium text-gray-700">Monthly Estimate</CardTitle>
              </CardHeader>
              <CardContent>
                <CostDisplay
                  amount={summary.monthlyEstimate}
                  region={settings?.region || "Other"}
                  label={`${((summary.monthlyEstimate / (settings?.monthlyBudget || 3000)) * 100).toFixed(0)}% of budget`}
                  className="text-purple-600"
                  units={summary.weeklyAverage * 30} // Estimated monthly units
                />
              </CardContent>
            </Card>
          </motion.div>

          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.4 }}>
            <Card className="card-modern">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium text-gray-700">Remaining Budget</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-orange-600">{formatCurrency(summary.remainingBudget)}</div>
                <p className="text-xs text-gray-600">For {summary.daysInMonth - new Date().getDate()} days left</p>
              </CardContent>
            </Card>
          </motion.div>
        </div>

        {/* Charts and Insights */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Usage Chart */}
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.5 }}>
            <UsageChart
              readings={readings}
              predictions={insights?.predictions}
              title="Daily Usage & 7-Day Prediction"
            />
          </motion.div>

          {/* AI Insights */}
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.6 }}>
            <Card className="card-modern">
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <span>🧠</span>
                  <span>AI Insights</span>
                  <Badge variant="outline" className="text-purple-600">
                    {(insights?.confidence || 0 * 100).toFixed(0)}% confidence
                  </Badge>
                </CardTitle>
                <CardDescription>Smart analysis of your usage patterns</CardDescription>
              </CardHeader>
              <CardContent>
                {insights ? (
                  <div className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <div className="text-center p-3 bg-blue-50 rounded">
                        <div className="text-sm text-blue-600">Trend</div>
                        <div className="font-semibold capitalize text-blue-800">{insights.trend}</div>
                      </div>
                      <div className="text-center p-3 bg-green-50 rounded">
                        <div className="text-sm text-green-600">Efficiency</div>
                        <div className="font-semibold capitalize text-green-800">{insights.efficiency}</div>
                      </div>
                    </div>

                    <div>
                      <h4 className="font-medium mb-2">💡 Smart Recommendations</h4>
                      <div className="space-y-2">
                        {insights.recommendations.slice(0, 3).map((rec, index) => (
                          <div key={index} className="p-2 bg-yellow-50 rounded text-sm text-yellow-800">
                            {rec}
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                ) : (
                  <div className="text-center py-4 text-gray-500">
                    <p>Add more readings to get AI insights</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </motion.div>
        </div>

        {/* Appliance Breakdown */}
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.7 }}>
          <ApplianceBreakdown appliances={appliances} />
        </motion.div>

        {/* Monthly Report */}
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.8 }}>
          <MonthlyReportGenerator readings={readings} appliances={appliances} settings={settings!} />
        </motion.div>

        {/* Quick Actions */}
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.9 }}>
          <Card className="card-modern">
            <CardHeader>
              <CardTitle>Quick Actions</CardTitle>
              <CardDescription>Manage your electricity tracking</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <Link href="/readings">
                  <Button
                    className="w-full btn-modern bg-primary-green hover:bg-green-600 text-white"
                    variant="outline"
                  >
                    <Plus className="h-4 w-4 mr-2" />
                    Add Reading
                  </Button>
                </Link>
                <Link href="/appliance-tracker">
                  <Button
                    className="w-full btn-modern bg-primary-green hover:bg-green-600 text-white"
                    variant="outline"
                  >
                    <Zap className="h-4 w-4 mr-2" />
                    Track Appliances
                  </Button>
                </Link>
                <Link href="/import">
                  <Button
                    className="w-full btn-modern bg-primary-green hover:bg-green-600 text-white"
                    variant="outline"
                  >
                    <TrendingUp className="h-4 w-4 mr-2" />
                    Import Data
                  </Button>
                </Link>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </div>
  )
}
