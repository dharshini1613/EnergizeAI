"use client"

import { useState, useEffect } from "react"
import { motion } from "framer-motion"
import { useForm } from "react-hook-form"
import { collection, addDoc, deleteDoc, doc } from "firebase/firestore"
import { db } from "@/lib/firebase"
import { calculateDailyUsage, fetchReadings, fetchUserSettings } from "@/lib/utils"
import { formatExactCurrency } from "@/lib/constants"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import { useToast } from "@/hooks/use-toast"
import { Loader2, Plus, Trash2, TrendingUp, Calendar } from "lucide-react"
import type { MeterReading, UserSettings } from "@/lib/types"
import { trackMeterReading, trackPageView } from "@/lib/analytics"
import { predictNext7Days } from "@/lib/constants"

export default function Readings() {
  const [readings, setReadings] = useState<MeterReading[]>([])
  const [settings, setSettings] = useState<UserSettings | null>(null)
  const [loading, setLoading] = useState(true)
  const [submitting, setSubmitting] = useState(false)
  const [nextPrediction, setNextPrediction] = useState<number>(0)
  const { toast } = useToast()

  const form = useForm({
    defaultValues: {
      date: new Date().toISOString().split("T")[0],
      reading: "",
    },
  })

  useEffect(() => {
    fetchData()
    trackPageView("readings")
  }, [])

  const fetchData = async () => {
    try {
      const [readingsData, userSettings] = await Promise.all([fetchReadings(), fetchUserSettings()])

      const readingsWithUsage = calculateDailyUsage(readingsData, userSettings.region)
      setReadings(readingsWithUsage)
      setSettings(userSettings)

      // Calculate prediction
      if (readingsData.length > 0) {
        const readingValues = readingsData.map((r) => r.reading)
        const predictions = predictNext7Days(readingValues)
        if (predictions.length > 0) {
          setNextPrediction(predictions[0]) // Use first prediction
        }
      }
    } catch (error) {
      console.error("Error fetching data:", error)
    } finally {
      setLoading(false)
    }
  }

  const onSubmit = async (data: any) => {
    setSubmitting(true)
    try {
      const readingValue = Number.parseFloat(data.reading)

      // Validate reading
      if (isNaN(readingValue) || readingValue < 0) {
        toast({
          title: "Invalid Reading",
          description: "Please enter a valid meter reading number",
          variant: "destructive",
        })
        return
      }

      // Check if reading is lower than previous
      if (readings.length > 0) {
        const latestReading = readings[0].reading
        if (readingValue < latestReading) {
          toast({
            title: "Reading Too Low",
            description: "New reading cannot be lower than your previous reading",
            variant: "destructive",
          })
          return
        }
      }

      await addDoc(collection(db, "readings"), {
        date: data.date,
        reading: readingValue,
        createdAt: new Date(),
      })

      trackMeterReading(readingValue)

      toast({
        title: "✅ Reading Added!",
        description: `Meter reading of ${readingValue} kWh recorded for ${data.date}`,
      })

      form.reset({
        date: new Date().toISOString().split("T")[0],
        reading: "",
      })

      fetchData()
    } catch (error) {
      console.error("Error adding reading:", error)
      toast({
        title: "Error",
        description: "Failed to add reading",
        variant: "destructive",
      })
    } finally {
      setSubmitting(false)
    }
  }

  const deleteReading = async (id: string) => {
    try {
      await deleteDoc(doc(db, "readings", id))
      toast({
        title: "✅ Reading Deleted",
        description: "Meter reading removed successfully",
      })
      fetchData()
    } catch (error) {
      console.error("Error deleting reading:", error)
      toast({
        title: "Error",
        description: "Failed to delete reading",
        variant: "destructive",
      })
    }
  }

  return (
    <div className="space-y-6">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="flex items-center justify-between"
      >
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Meter Readings</h1>
          <p className="text-gray-600">Track your daily electricity usage and costs</p>
        </div>
        {nextPrediction > 0 && (
          <div className="text-right">
            <div className="text-sm text-gray-600">Next Expected Reading</div>
            <div className="text-2xl font-bold text-blue-600">{nextPrediction.toFixed(1)} kWh</div>
          </div>
        )}
      </motion.div>

      {/* Add Reading Form */}
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }}>
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Plus className="h-5 w-5 text-green-600" />
              <span>Add Today's Reading</span>
            </CardTitle>
            <CardDescription>Enter the number shown on your electricity meter (in kWh)</CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={form.handleSubmit(onSubmit)} className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="space-y-2">
                <Label htmlFor="date">Date</Label>
                <Input id="date" type="date" {...form.register("date")} className="w-full" />
              </div>

              <div className="space-y-2">
                <Label htmlFor="reading">Meter Reading (kWh)</Label>
                <Input
                  id="reading"
                  type="number"
                  step="0.1"
                  placeholder="e.g., 1250.5"
                  {...form.register("reading")}
                  className="w-full"
                />
              </div>

              <div className="flex items-end">
                <Button type="submit" disabled={submitting} className="w-full bg-green-600 hover:bg-green-700">
                  {submitting ? (
                    <>
                      <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                      Adding...
                    </>
                  ) : (
                    <>
                      <Plus className="h-4 w-4 mr-2" />
                      Add Reading
                    </>
                  )}
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>
      </motion.div>

      {/* Readings Table */}
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }}>
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Calendar className="h-5 w-5 text-blue-600" />
              <span>Your Reading History</span>
            </CardTitle>
            <CardDescription>Daily usage and costs calculated automatically</CardDescription>
          </CardHeader>
          <CardContent>
            {loading ? (
              <div className="flex justify-center py-8">
                <Loader2 className="h-8 w-8 animate-spin text-green-600" />
              </div>
            ) : readings.length === 0 ? (
              <div className="text-center py-12">
                <TrendingUp className="h-16 w-16 text-gray-300 mx-auto mb-4" />
                <h3 className="text-lg font-medium text-gray-900 mb-2">No readings yet</h3>
                <p className="text-gray-600 mb-4">
                  Add your first meter reading above to start tracking your electricity usage.
                </p>
                <p className="text-sm text-gray-500">
                  💡 Tip: Take readings at the same time each day for accurate tracking
                </p>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Date</TableHead>
                      <TableHead>Meter Reading</TableHead>
                      <TableHead>Daily Usage</TableHead>
                      <TableHead>Daily Cost</TableHead>
                      <TableHead>Level</TableHead>
                      <TableHead className="w-[100px]">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {readings.map((reading) => (
                      <TableRow key={reading.id}>
                        <TableCell>{new Date(reading.date).toLocaleDateString("en-IN")}</TableCell>
                        <TableCell className="font-medium">{reading.reading} kWh</TableCell>
                        <TableCell>{reading.dailyUsage ? `${reading.dailyUsage.toFixed(1)} kWh` : "-"}</TableCell>
                        <TableCell>{reading.dailyCost ? formatExactCurrency(reading.dailyCost) : "-"}</TableCell>
                        <TableCell>
                          {reading.dailyCost && (
                            <Badge
                              variant={
                                reading.dailyCost < 50
                                  ? "default"
                                  : reading.dailyCost < 150
                                    ? "secondary"
                                    : "destructive"
                              }
                            >
                              {reading.dailyCost < 50 ? "🟢 Good" : reading.dailyCost < 150 ? "🟡 Okay" : "🔴 High"}
                            </Badge>
                          )}
                        </TableCell>
                        <TableCell>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => reading.id && deleteReading(reading.id)}
                            className="text-red-600 hover:text-red-700 hover:bg-red-50"
                            title="Delete this reading"
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            )}
          </CardContent>
        </Card>
      </motion.div>
    </div>
  )
}
