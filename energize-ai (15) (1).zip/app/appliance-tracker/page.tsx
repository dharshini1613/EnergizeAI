"use client"

import { useState, useEffect, useMemo } from "react"
import { motion, AnimatePresence } from "framer-motion"
import { collection, addDoc, deleteDoc, doc } from "firebase/firestore"
import { db } from "@/lib/firebase"
import {
  calculateTamilNaduApplianceCosts,
  isSlabBasedRegion,
  getBillingMethod,
  formatExactCurrency,
} from "@/lib/constants"
import { fetchAppliances, fetchUserSettings } from "@/lib/utils"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { useToast } from "@/hooks/use-toast"
import { Info, PieChart, Zap, Upload, Plus } from "lucide-react"
import type { Appliance, UserSettings } from "@/lib/types"
import { trackApplianceAdded, trackPageView } from "@/lib/analytics"

// Import components
import { AddApplianceForm } from "@/components/AddApplianceForm"
import { ApplianceCard } from "@/components/ApplianceCard"
import { SlabBreakdownDisplay } from "@/components/SlabBreakdownDisplay"
import { UsageProgressBar } from "@/components/UsageProgressBar"
import { ApplianceImport } from "@/components/ApplianceImport"

export default function ApplianceTracker() {
  const [appliances, setAppliances] = useState<Appliance[]>([])
  const [processedData, setProcessedData] = useState<any>(null)
  const [settings, setSettings] = useState<UserSettings | null>(null)
  const [loading, setLoading] = useState(true)
  const [submitting, setSubmitting] = useState(false)
  const { toast } = useToast()

  useEffect(() => {
    fetchData()
    trackPageView("appliance_tracker")
  }, [])

  useEffect(() => {
    if (settings && appliances.length > 0) {
      processApplianceCosts()
    } else if (settings) {
      // Reset processed data when no appliances
      setProcessedData({
        appliances: [],
        totalMonthlyKwh: 0,
        totalMonthlyCost: 0,
        breakdown: [],
        effectiveRate: settings.electricityRate,
      })
    }
  }, [appliances, settings])

  const fetchData = async () => {
    try {
      const [appliancesData, userSettings] = await Promise.all([fetchAppliances(), fetchUserSettings()])
      setAppliances(appliancesData)
      setSettings(userSettings)
    } catch (error) {
      console.error("Error fetching data:", error)
      toast({
        title: "Error",
        description: "Failed to load data. Please refresh the page.",
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  const processApplianceCosts = () => {
    if (!settings) return

    if (isSlabBasedRegion(settings.region)) {
      // Use Tamil Nadu proportional billing with CORRECTED logic
      const result = calculateTamilNaduApplianceCosts(appliances)
      setProcessedData(result)
    } else {
      // Use standard per-appliance billing
      const processed = appliances.map((appliance) => ({
        ...appliance,
        monthlyKwh: (appliance.power * appliance.hoursPerDay * appliance.daysPerMonth) / 1000,
        monthlyCost:
          (appliance.power * appliance.hoursPerDay * appliance.daysPerMonth * settings.electricityRate) / 1000,
      }))
      setProcessedData({
        appliances: processed,
        totalMonthlyKwh: processed.reduce((sum, app) => sum + app.monthlyKwh, 0),
        totalMonthlyCost: processed.reduce((sum, app) => sum + app.monthlyCost, 0),
        breakdown: [],
        effectiveRate: settings.electricityRate,
      })
    }
  }

  const handleAddAppliance = async (data: any) => {
    setSubmitting(true)
    try {
      const monthlyKwh = (data.power * data.hoursPerDay * data.daysPerMonth) / 1000

      const applianceData = {
        ...data,
        monthlyKwh,
        monthlyCost: 0, // Will be calculated after processing
        createdAt: new Date(),
      }

      await addDoc(collection(db, "appliances"), applianceData)

      trackApplianceAdded({
        name: data.name,
        power: data.power,
        category: data.category,
      })

      toast({
        title: "✅ Appliance Added!",
        description: `${data.name} has been added to your tracking list`,
        className: "success-bounce",
      })

      fetchData()
    } catch (error) {
      console.error("Error adding appliance:", error)
      toast({
        title: "Error",
        description: "Failed to add appliance. Please try again.",
        variant: "destructive",
      })
    } finally {
      setSubmitting(false)
    }
  }

  const handleDeleteAppliance = async (id: string) => {
    try {
      await deleteDoc(doc(db, "appliances", id))
      toast({
        title: "✅ Appliance Removed",
        description: "Appliance deleted successfully",
      })
      fetchData()
    } catch (error) {
      console.error("Error deleting appliance:", error)
      toast({
        title: "Error",
        description: "Failed to delete appliance",
        variant: "destructive",
      })
    }
  }

  // Memoize current total to prevent object recreation on every render
  const currentTotal = useMemo(
    () => ({
      kWh: processedData?.totalMonthlyKwh || 0,
      cost: processedData?.totalMonthlyCost || 0,
    }),
    [processedData?.totalMonthlyKwh, processedData?.totalMonthlyCost],
  )

  // Get existing appliance names for import validation
  const existingApplianceNames = appliances.map((app) => app.name)

  // Sort appliances by cost (highest first)
  const sortedAppliances = processedData?.appliances
    ? [...processedData.appliances].sort((a, b) => b.monthlyCost - a.monthlyCost)
    : []

  // Get top 3 appliances
  const topAppliances = sortedAppliances.slice(0, 3)

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-green-50 via-white to-green-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-green-600 mx-auto mb-4"></div>
          <p className="text-gray-600">Loading your appliances...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 via-white to-green-50">
      <div className="container mx-auto px-4 py-8 space-y-8">
        {/* Header */}
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="text-center">
          <h1 className="text-4xl font-bold text-gray-900 mb-2">Smart Appliance Tracker</h1>
          <p className="text-lg text-gray-600 mb-6">Track which appliances cost you the most money</p>

          {/* Total Stats Card */}
          <div className="card-modern p-8 max-w-5xl mx-auto bg-gradient-to-r from-green-50 to-blue-50 border-green-200">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
              <div className="text-center">
                <div className="text-sm text-gray-600 mb-2">Total Monthly Usage</div>
                <div className="text-3xl font-bold text-green-600">
                  {processedData?.totalMonthlyKwh?.toFixed(1) || "0"} kWh
                </div>
              </div>
              <div className="text-center">
                <div className="text-sm text-gray-600 mb-2">Total Monthly Cost</div>
                <div className="text-3xl font-bold text-green-600">
                  {formatExactCurrency(processedData?.totalMonthlyCost || 0)}
                </div>
              </div>
              <div className="text-center">
                <div className="text-sm text-gray-600 mb-2">Effective Rate</div>
                <div className="text-3xl font-bold text-green-600">
                  ₹{processedData?.effectiveRate?.toFixed(2) || "0"}/kWh
                </div>
              </div>
              <div className="text-center">
                <div className="text-sm text-gray-600 mb-2">Appliances</div>
                <div className="text-3xl font-bold text-green-600">{appliances.length}</div>
              </div>
            </div>

            {settings && (
              <div className="mt-6 pt-6 border-t border-green-200 text-center">
                <div className="flex items-center justify-center space-x-4">
                  <div className="bg-green-100 text-green-700 border-green-300 px-4 py-2 rounded-full text-sm font-medium">
                    {getBillingMethod(settings.region).badge}
                  </div>
                  {topAppliances.length > 0 && (
                    <div className="text-sm text-gray-600">
                      Top consumer: <span className="font-medium capitalize">{topAppliances[0].name}</span> (
                      {formatExactCurrency(topAppliances[0].monthlyCost)}/month)
                    </div>
                  )}
                </div>
              </div>
            )}
          </div>
        </motion.div>

        {/* Tamil Nadu Billing Info */}
        {settings && isSlabBasedRegion(settings.region) && (
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }}>
            <Alert className="card-modern border-green-200 bg-green-50">
              <Info className="h-5 w-5 text-green-600" />
              <AlertDescription className="text-green-800 text-base">
                <strong>Tamil Nadu LT-1 Slab Billing:</strong> Total electricity usage (
                {processedData?.totalMonthlyKwh?.toFixed(1) || "0"} kWh) is billed using official slab rates, then
                distributed proportionally across appliances based on their consumption share.
              </AlertDescription>
            </Alert>
          </motion.div>
        )}

        {/* Progress Bar */}
        {processedData && (
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }}>
            <UsageProgressBar
              currentUsage={processedData.totalMonthlyKwh}
              currentCost={processedData.totalMonthlyCost}
              goalUsage={400}
              goalBudget={settings?.monthlyBudget || 2000}
            />
          </motion.div>
        )}

        {/* Add Appliance Tabs */}
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3 }}>
          <Card className="card-modern">
            <CardHeader>
              <CardTitle>Add Appliances</CardTitle>
              <CardDescription>
                Add appliances individually or import multiple appliances from a CSV file
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Tabs defaultValue="manual" className="w-full">
                <TabsList className="grid w-full grid-cols-2">
                  <TabsTrigger value="manual" className="flex items-center space-x-2">
                    <Plus className="h-4 w-4" />
                    <span>Add Manually</span>
                  </TabsTrigger>
                  <TabsTrigger value="import" className="flex items-center space-x-2">
                    <Upload className="h-4 w-4" />
                    <span>Import CSV</span>
                  </TabsTrigger>
                </TabsList>
                <TabsContent value="manual" className="mt-6">
                  <AddApplianceForm
                    onSubmit={handleAddAppliance}
                    settings={settings}
                    currentTotal={currentTotal}
                    isSubmitting={submitting}
                  />
                </TabsContent>
                <TabsContent value="import" className="mt-6">
                  <ApplianceImport existingAppliances={existingApplianceNames} onImportComplete={fetchData} />
                </TabsContent>
              </Tabs>
            </CardContent>
          </Card>
        </motion.div>

        {/* Slab Breakdown */}
        {settings && isSlabBasedRegion(settings.region) && processedData && (
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.4 }}>
            <SlabBreakdownDisplay
              totalUnits={processedData.totalMonthlyKwh}
              totalCost={processedData.totalMonthlyCost}
            />
          </motion.div>
        )}

        {/* Appliances List */}
        {sortedAppliances.length > 0 ? (
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.5 }}>
            <Card className="card-modern">
              <CardHeader>
                <CardTitle className="flex items-center space-x-2 text-xl">
                  <PieChart className="h-6 w-6 text-blue-600" />
                  <span>Your Appliances</span>
                  <span className="text-sm text-gray-500">({sortedAppliances.length} total)</span>
                </CardTitle>
                <CardDescription className="text-base">
                  Ranked by monthly cost •{" "}
                  {settings && isSlabBasedRegion(settings.region)
                    ? "Costs distributed proportionally using Tamil Nadu slab rates"
                    : "Individual appliance costs"}
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                  <AnimatePresence>
                    {sortedAppliances.map((appliance, index) => (
                      <ApplianceCard
                        key={appliance.id}
                        appliance={appliance}
                        rank={index + 1}
                        settings={settings}
                        onDelete={handleDeleteAppliance}
                        isSlabBased={settings ? isSlabBasedRegion(settings.region) : false}
                        totalCost={processedData?.totalMonthlyCost || 0}
                      />
                    ))}
                  </AnimatePresence>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        ) : (
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.5 }}>
            <Card className="card-modern">
              <CardContent className="p-12 text-center">
                <Zap className="h-16 w-16 text-gray-300 mx-auto mb-4" />
                <h3 className="text-xl font-semibold text-gray-900 mb-2">No Appliances Added Yet</h3>
                <p className="text-gray-600 mb-6">
                  Start tracking your electricity usage by adding appliances manually or importing from a CSV file.
                </p>
                <div className="bg-blue-50 p-4 rounded-lg border border-blue-200 max-w-md mx-auto">
                  <div className="text-sm text-blue-800">
                    💡 <strong>Pro Tip:</strong> Use the CSV import feature to quickly add multiple appliances at once!
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        )}
      </div>
    </div>
  )
}
