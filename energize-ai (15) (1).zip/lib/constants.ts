// Indian electricity pricing and appliance presets
export const DEFAULT_ELECTRICITY_RATE = 8 // ₹8 per kWh (default for India)

// Regional electricity rates across Indian states
export const REGIONAL_RATES = {
  "Andhra Pradesh": 6.5,
  Assam: 7.2,
  Bihar: 5.8,
  Delhi: 8.5,
  Gujarat: 7.8,
  Haryana: 8.2,
  Karnataka: 7.5,
  Kerala: 6.8,
  "Madhya Pradesh": 7.0,
  Maharashtra: 9.5,
  Odisha: 6.2,
  Punjab: 8.0,
  Rajasthan: 7.8,
  "Tamil Nadu": 6.5,
  Telangana: 7.2,
  "Uttar Pradesh": 7.5,
  "West Bengal": 8.2,
  Other: 8.0,
}

// Simplified appliance mapping - NO WATTS INPUT NEEDED
export const APPLIANCE_POWER_MAP: Record<string, number> = {
  // Cooling & Fans
  fan: 75,
  "ceiling fan": 75,
  "table fan": 50,
  "air conditioner": 1500,
  ac: 1500,
  "air cooler": 200,
  "split ac": 1800,
  "window ac": 1200,

  // Lighting
  "tube light": 40,
  "led bulb": 9,
  "cfl bulb": 15,
  "led light": 9,
  bulb: 60,

  // Kitchen
  refrigerator: 200,
  fridge: 200,
  microwave: 1000,
  "mixer grinder": 400,
  induction: 2000,
  "electric kettle": 1500,
  toaster: 800,
  "rice cooker": 700,

  // Electronics
  "led tv": 120,
  tv: 120,
  "smart tv": 150,
  laptop: 60,
  computer: 300,
  "mobile charger": 5,
  "wifi router": 10,

  // Water & Heating
  geyser: 2000,
  "water heater": 2000,
  "water pump": 750,
  "immersion rod": 1500,

  // Cleaning & Laundry
  "washing machine": 500,
  iron: 1000,
  "vacuum cleaner": 1200,

  // Others
  inverter: 100,
  ups: 150,
}

// Get appliance power automatically
export const getAppliancePower = (name: string): number => {
  const searchName = name.toLowerCase().trim()

  // Direct match
  if (APPLIANCE_POWER_MAP[searchName]) {
    return APPLIANCE_POWER_MAP[searchName]
  }

  // Partial match
  for (const [key, power] of Object.entries(APPLIANCE_POWER_MAP)) {
    if (searchName.includes(key) || key.includes(searchName)) {
      return power
    }
  }

  // Default for unknown appliances
  return 100
}

// Get appliance suggestions
export const getApplianceSuggestions = (input: string) => {
  const searchTerm = input.toLowerCase().trim()
  if (!searchTerm) return []

  return Object.keys(APPLIANCE_POWER_MAP)
    .filter((name) => name.includes(searchTerm))
    .map((name) => ({
      name: name.charAt(0).toUpperCase() + name.slice(1),
      power: APPLIANCE_POWER_MAP[name],
    }))
    .slice(0, 5)
}

// Tamil Nadu LT-1 Domestic Slab Rates (Official TANGEDCO) - CORRECTED
export const TAMIL_NADU_SLABS = [
  { min: 0, max: 100, rate: 0 }, // Free for first 100 units
  { min: 101, max: 200, rate: 2.5 }, // ₹2.5/unit for 101-200
  { min: 201, max: 400, rate: 4.5 }, // ₹4.5/unit for 201-400
  { min: 401, max: 500, rate: 5.5 }, // ₹5.5/unit for 401-500
  { min: 501, max: 600, rate: 6.0 }, // ₹6/unit for 501-600
  { min: 601, max: 800, rate: 8.55 }, // ₹8.55/unit for 601-800
  { min: 801, max: 1000, rate: 9.65 }, // ₹9.65/unit for 801-1000
  { min: 1001, max: Number.POSITIVE_INFINITY, rate: 11.8 }, // ₹11.80/unit for >1000
]

// CORRECTED: Calculate cost using Tamil Nadu slab-based tariff
export const calculateTamilNaduSlabCost = (totalUnits: number): number => {
  if (totalUnits <= 0) return 0

  let totalCost = 0
  let remainingUnits = totalUnits

  for (const slab of TAMIL_NADU_SLABS) {
    if (remainingUnits <= 0) break

    // Calculate units that fall in this slab
    const slabStart = slab.min
    const slabEnd = slab.max === Number.POSITIVE_INFINITY ? totalUnits : Math.min(slab.max, totalUnits)

    if (totalUnits > slabStart) {
      const unitsInThisSlab = Math.min(remainingUnits, slabEnd - slabStart + 1)
      if (unitsInThisSlab > 0) {
        totalCost += unitsInThisSlab * slab.rate
        remainingUnits -= unitsInThisSlab
      }
    }
  }

  return totalCost
}

// CORRECTED: Calculate proportional billing for Tamil Nadu appliances
export const calculateTamilNaduApplianceCosts = (
  appliances: Array<{
    id?: string
    name: string
    power: number
    hoursPerDay: number
    daysPerMonth: number
  }>,
) => {
  if (appliances.length === 0) {
    return {
      appliances: [],
      totalMonthlyKwh: 0,
      totalMonthlyCost: 0,
      breakdown: [],
      effectiveRate: 0,
    }
  }

  // Step 1: Calculate individual appliance kWh consumption
  const appliancesWithKwh = appliances.map((appliance) => ({
    ...appliance,
    monthlyKwh: (appliance.power * appliance.hoursPerDay * appliance.daysPerMonth) / 1000,
  }))

  // Step 2: Calculate TOTAL monthly kWh consumption across ALL appliances
  const totalMonthlyKwh = appliancesWithKwh.reduce((sum, app) => sum + app.monthlyKwh, 0)

  // Step 3: Apply Tamil Nadu slab rates to the TOTAL consumption
  const totalMonthlyCost = calculateTamilNaduSlabCost(totalMonthlyKwh)

  // Step 4: Calculate effective rate per kWh
  const effectiveRate = totalMonthlyKwh > 0 ? totalMonthlyCost / totalMonthlyKwh : 0

  // Step 5: Distribute the total cost proportionally based on each appliance's kWh share
  const appliancesWithCosts = appliancesWithKwh.map((appliance) => {
    const proportionalShare = totalMonthlyKwh > 0 ? appliance.monthlyKwh / totalMonthlyKwh : 0
    const monthlyCost = totalMonthlyCost * proportionalShare

    return {
      ...appliance,
      monthlyCost,
      proportionalShare: proportionalShare * 100, // percentage
      effectiveRate: effectiveRate, // rate this appliance effectively pays
    }
  })

  return {
    appliances: appliancesWithCosts,
    totalMonthlyKwh,
    totalMonthlyCost,
    breakdown: getTamilNaduSlabBreakdown(totalMonthlyKwh),
    effectiveRate,
  }
}

// Get detailed slab breakdown for Tamil Nadu billing
export const getTamilNaduSlabBreakdown = (totalUnits: number | undefined | null) => {
  const safeUnits = totalUnits || 0
  if (safeUnits <= 0) return []

  const breakdown = []
  let remainingUnits = safeUnits

  for (const slab of TAMIL_NADU_SLABS) {
    if (remainingUnits <= 0) break

    const slabStart = slab.min
    const slabEnd = slab.max === Number.POSITIVE_INFINITY ? safeUnits : Math.min(slab.max, safeUnits)

    if (safeUnits > slabStart) {
      const unitsInThisSlab = Math.min(remainingUnits, slabEnd - slabStart + 1)
      if (unitsInThisSlab > 0) {
        breakdown.push({
          range: `${slabStart}-${slab.max === Number.POSITIVE_INFINITY ? "∞" : slab.max}`,
          units: unitsInThisSlab,
          rate: slab.rate,
          cost: unitsInThisSlab * slab.rate,
          isFree: slab.rate === 0,
        })
        remainingUnits -= unitsInThisSlab
      }
    }
  }

  return breakdown
}

// Update calculateMonthlyCost function to use slab-based calculation for Tamil Nadu
export const calculateMonthlyCost = (
  monthlyKwh: number,
  ratePerKwh: number = DEFAULT_ELECTRICITY_RATE,
  region = "Other",
): number => {
  if (region === "Tamil Nadu") {
    return calculateTamilNaduSlabCost(monthlyKwh)
  }
  return monthlyKwh * ratePerKwh
}

// Update calculateDailyCost function to use slab-based calculation for Tamil Nadu
export const calculateDailyCost = (
  dailyKwh: number,
  ratePerKwh: number = DEFAULT_ELECTRICITY_RATE,
  region = "Other",
): number => {
  if (region === "Tamil Nadu") {
    // For daily cost, we estimate based on monthly usage pattern
    const estimatedMonthlyUsage = dailyKwh * 30
    const monthlyCost = calculateTamilNaduSlabCost(estimatedMonthlyUsage)
    return monthlyCost / 30
  }
  return dailyKwh * ratePerKwh
}

// Format currency in Indian Rupees with null/undefined safety
export const formatCurrency = (amount: number | undefined | null): string => {
  if (amount === undefined || amount === null || isNaN(amount)) {
    return "₹0"
  }

  if (amount >= 100000) {
    return `₹${(amount / 100000).toFixed(1)}L`
  } else if (amount >= 1000) {
    return `₹${(amount / 1000).toFixed(1)}K`
  }
  return `₹${Math.round(amount)}`
}

// Format exact currency with null/undefined safety
export const formatExactCurrency = (amount: number | undefined | null): string => {
  if (amount === undefined || amount === null || isNaN(amount)) {
    return "₹0.00"
  }
  return `₹${amount.toFixed(2)}`
}

// Get budget status
export const getBudgetStatus = (
  actualCost: number,
  dailyBudget: number,
): { status: "under" | "near" | "over"; emoji: string; message: string } => {
  const percentage = (actualCost / dailyBudget) * 100

  if (percentage <= 80) {
    return {
      status: "under",
      emoji: "🟢",
      message: `Great! You're ${formatCurrency(dailyBudget - actualCost)} under budget today.`,
    }
  } else if (percentage <= 100) {
    return {
      status: "near",
      emoji: "🟡",
      message: `Close to budget. ${formatCurrency(dailyBudget - actualCost)} remaining today.`,
    }
  } else {
    return {
      status: "over",
      emoji: "🔴",
      message: `Over budget by ${formatCurrency(actualCost - dailyBudget)}. Consider reducing usage.`,
    }
  }
}

// Simple prediction using linear regression
export const predictNext7Days = (readings: number[]): number[] => {
  if (readings.length < 2) return []

  const predictions = []
  let lastReading = readings[readings.length - 1]

  // Calculate average daily usage from last 7 days
  const recentReadings = readings.slice(-7)
  const dailyUsages = []
  for (let i = 1; i < recentReadings.length; i++) {
    dailyUsages.push(recentReadings[i] - recentReadings[i - 1])
  }

  const avgDailyUsage = dailyUsages.length > 0 ? dailyUsages.reduce((a, b) => a + b, 0) / dailyUsages.length : 5

  for (let i = 1; i <= 7; i++) {
    lastReading += Math.max(avgDailyUsage, 1)
    predictions.push(Math.round(lastReading * 10) / 10)
  }

  return predictions
}

// Update getBillingMethod to include tooltip message
export const getBillingMethod = (
  region: string,
): {
  method: string
  description: string
  badge: string
  tooltip: string
} => {
  if (region === "Tamil Nadu") {
    return {
      method: "slab",
      description: "Tamil Nadu LT-1 Slab Billing",
      badge: "🎯 TN Slab-Based",
      tooltip:
        "Total electricity usage is billed using Tamil Nadu's official LT-1 slab rates. Cost is distributed proportionally across appliances based on their consumption share.",
    }
  }
  return {
    method: "average",
    description: "Standard Rate Billing",
    badge: "📊 Standard Rate",
    tooltip: "This cost is calculated using standard average rates for your region.",
  }
}

// Check if region uses slab-based billing
export const isSlabBasedRegion = (region: string): boolean => {
  return region === "Tamil Nadu"
}

// Tooltip messages for Tamil Nadu slab calculation
export const getTamilNaduTooltipMessage = () => {
  return "Total electricity usage is billed using Tamil Nadu's official LT-1 slab rates. Each appliance's cost is calculated as a proportion of total consumption."
}

export const getStandardRateTooltipMessage = () => {
  return "This cost is calculated using standard average rates for your region."
}
