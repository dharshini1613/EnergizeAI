import { z } from "zod"

export const meterReadingSchema = z.object({
  date: z.string().min(1, "Date is required"),
  time: z.string().min(1, "Time is required"),
  reading: z.number().min(0, "Reading must be positive"),
})

export const applianceSchema = z.object({
  name: z.string().min(1, "Name is required"),
  power: z.number().min(1, "Power must be positive"),
  hoursPerDay: z.number().min(0).max(24, "Hours must be between 0-24"),
  daysPerMonth: z.number().min(0).max(31, "Days must be between 0-31"),
  category: z.enum(["essential", "optional"]),
})
