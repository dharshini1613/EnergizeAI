import { analytics } from "./firebase"
import { logEvent } from "firebase/analytics"

export const trackEvent = (eventName: string, parameters?: Record<string, any>) => {
  if (analytics) {
    logEvent(analytics, eventName, parameters)
  }
}

// Predefined events for EnergizeAI
export const trackMeterReading = (reading: number) => {
  trackEvent("meter_reading_added", {
    reading_value: reading,
    timestamp: new Date().toISOString(),
  })
}

export const trackApplianceAdded = (appliance: { name: string; power: number; category: string }) => {
  trackEvent("appliance_added", {
    appliance_name: appliance.name,
    power_watts: appliance.power,
    category: appliance.category,
  })
}

export const trackDataImport = (recordCount: number) => {
  trackEvent("data_import", {
    records_imported: recordCount,
    timestamp: new Date().toISOString(),
  })
}

export const trackBudgetSet = (budget: number) => {
  trackEvent("budget_set", {
    monthly_budget: budget,
  })
}

export const trackBudgetExceeded = (amount: number) => {
  trackEvent("budget_exceeded", {
    excess_amount: amount,
  })
}

export const trackReportGenerated = (type: string) => {
  trackEvent("report_generated", {
    report_type: type,
  })
}

export const trackPageView = (pageName: string) => {
  trackEvent("page_view", {
    page_name: pageName,
  })
}

export const trackOnboardingComplete = () => {
  trackEvent("onboarding_complete", {
    timestamp: new Date().toISOString(),
  })
}
