import { initializeApp } from "firebase/app"
import { getFirestore } from "firebase/firestore"
import { getAnalytics } from "firebase/analytics"

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyAUTR0xxB74HlzyGcrX1HLBpD8vR0EHRDY",
  authDomain: "energize-ai-f127b.firebaseapp.com",
  projectId: "energize-ai-f127b",
  storageBucket: "energize-ai-f127b.firebasestorage.app",
  messagingSenderId: "659377116425",
  appId: "1:659377116425:web:ea8b130d875f7aaf312fd8",
  measurementId: "G-7NML2J0MG5",
}

// Initialize Firebase
const app = initializeApp(firebaseConfig)

// Initialize Firestore
export const db = getFirestore(app)

// Initialize Analytics (only in browser environment)
export const analytics = typeof window !== "undefined" ? getAnalytics(app) : null
