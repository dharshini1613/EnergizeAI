// AI Service for energy predictions and recommendations
const AI_API_URL = "https://c63c-35-230-2-210.ngrok-free.app/predict"

import { ELECTRICITY_RATE_PER_KWH, calculateMonthlyCost, formatCurrency } from "./constants"

export interface PredictionRequest {
  readings?: number[]
  appliances?: {
    name: string
    power: number
    hoursPerDay: number
    daysPerMonth: number
  }[]
  timeframe?: "daily" | "weekly" | "monthly"
}

export interface PredictionResponse {
  prediction?: {
    nextReading?: number
    estimatedUsage?: number
    confidence?: number
  }
  recommendations?: string[]
  insights?: {
    trend: "increasing" | "decreasing" | "stable"
    efficiency: "good" | "average" | "poor"
    suggestions: string[]
  }
  error?: string
}

export class AIService {
  private static async makeRequest(data: PredictionRequest): Promise<PredictionResponse> {
    // Always return fallback response to avoid fetch errors
    console.log("AI Service: Using local analysis (external API disabled)")
    return this.generateLocalInsights(data)
  }

  // Enhanced local insights generation with Indian Rupees
  private static generateLocalInsights(data: PredictionRequest): PredictionResponse {
    const response: PredictionResponse = {
      recommendations: [],
      insights: {
        trend: "stable",
        efficiency: "average",
        suggestions: [],
      },
    }

    // Analyze readings if available
    if (data.readings && data.readings.length >= 2) {
      const readings = data.readings.filter((r) => !isNaN(r) && r > 0)

      if (readings.length >= 2) {
        // Calculate usage trend
        const recent = readings.slice(-3)
        const older = readings.length > 3 ? readings.slice(-6, -3) : readings.slice(0, -3)

        const recentAvg = recent.reduce((a, b) => a + b, 0) / recent.length
        const olderAvg = older.length > 0 ? older.reduce((a, b) => a + b, 0) / older.length : recentAvg

        // Determine trend
        const trendThreshold = 0.1 // 10% change threshold
        if (recentAvg > olderAvg * (1 + trendThreshold)) {
          response.insights!.trend = "increasing"
          const extraCost = calculateMonthlyCost((recentAvg - olderAvg) * 30)
          response.recommendations!.push(
            `⚠️ Your energy usage is increasing. This could add ${formatCurrency(extraCost)}/month to your bill.`,
          )
        } else if (recentAvg < olderAvg * (1 - trendThreshold)) {
          response.insights!.trend = "decreasing"
          const savings = calculateMonthlyCost((olderAvg - recentAvg) * 30)
          response.recommendations!.push(
            `✅ Excellent! Your energy usage is decreasing. You're saving ${formatCurrency(savings)}/month.`,
          )
        } else {
          response.insights!.trend = "stable"
          response.recommendations!.push(
            `📊 Your energy usage is stable. Look for optimization opportunities to reduce costs.`,
          )
        }

        // Calculate prediction
        const lastReading = readings[readings.length - 1]
        const secondLastReading = readings[readings.length - 2]
        const dailyUsage = Math.abs(lastReading - secondLastReading)

        // Simple linear prediction
        const avgDailyUsage =
          readings.length > 2 ? (readings[readings.length - 1] - readings[0]) / (readings.length - 1) : dailyUsage

        response.prediction = {
          nextReading: lastReading + Math.max(avgDailyUsage, 1),
          estimatedUsage: Math.max(avgDailyUsage, 1),
          confidence: Math.min(0.8, readings.length / 10), // Higher confidence with more data
        }

        // Usage level analysis with Indian costs
        const totalUsage = readings[readings.length - 1] - readings[0]
        const avgDailyConsumption = totalUsage / Math.max(readings.length - 1, 1)
        const dailyCost = calculateMonthlyCost(avgDailyConsumption)

        if (avgDailyConsumption > 20) {
          response.insights!.efficiency = "poor"
          response.recommendations!.push(
            `🔴 High daily consumption (${formatCurrency(dailyCost * 30)}/month). Consider energy audit and appliance upgrades.`,
          )
        } else if (avgDailyConsumption > 10) {
          response.insights!.efficiency = "average"
          response.recommendations!.push(
            `🟡 Moderate energy usage (${formatCurrency(dailyCost * 30)}/month). Optimize peak usage times.`,
          )
        } else {
          response.insights!.efficiency = "good"
          response.recommendations!.push(
            `🟢 Good energy efficiency (${formatCurrency(dailyCost * 30)}/month)! Maintain current practices.`,
          )
        }
      }
    }

    // Analyze appliances if available with Indian costs
    if (data.appliances && data.appliances.length > 0) {
      const totalMonthlyKwh = data.appliances.reduce(
        (sum, app) => sum + (app.power * app.hoursPerDay * app.daysPerMonth) / 1000,
        0,
      )
      const totalMonthlyCost = calculateMonthlyCost(totalMonthlyKwh)

      // Appliance efficiency analysis
      if (totalMonthlyCost > 2000) {
        response.insights!.efficiency = "poor"
        response.recommendations!.push(
          `🔴 Very high appliance costs (${formatCurrency(totalMonthlyCost)}/month). Priority: Replace with 5-star rated models.`,
        )
      } else if (totalMonthlyCost > 1000) {
        response.insights!.efficiency = "average"
        response.recommendations!.push(
          `🟡 Moderate appliance costs (${formatCurrency(totalMonthlyCost)}/month). Consider upgrading oldest appliances first.`,
        )
      } else {
        response.insights!.efficiency = "good"
        response.recommendations!.push(
          `🟢 Good appliance efficiency (${formatCurrency(totalMonthlyCost)}/month)! Focus on usage optimization.`,
        )
      }

      // Find high-consumption appliances
      const highConsumptionAppliances = data.appliances
        .map((app) => ({
          ...app,
          monthlyKwh: (app.power * app.hoursPerDay * app.daysPerMonth) / 1000,
          monthlyCost: calculateMonthlyCost((app.power * app.hoursPerDay * app.daysPerMonth) / 1000),
        }))
        .filter((app) => app.monthlyCost > 200)
        .sort((a, b) => b.monthlyCost - a.monthlyCost)

      if (highConsumptionAppliances.length > 0) {
        const topConsumer = highConsumptionAppliances[0]
        response.insights!.suggestions.push(
          `🎯 Top cost: ${topConsumer.name} (${formatCurrency(topConsumer.monthlyCost)}/month)`,
        )
        const savings = topConsumer.monthlyCost * 0.25
        response.insights!.suggestions.push(
          `💡 Reduce ${topConsumer.name} usage by 2 hours daily to save ${formatCurrency(savings)}/month`,
        )
      }

      // Category-based recommendations with costs
      const essentialAppliances = data.appliances.filter(
        (app) =>
          app.name.toLowerCase().includes("refrigerator") ||
          app.name.toLowerCase().includes("fan") ||
          app.name.toLowerCase().includes("light"),
      )
      const optionalAppliances = data.appliances.filter((app) => !essentialAppliances.includes(app))

      if (optionalAppliances.length > 0) {
        const optionalCost = optionalAppliances.reduce(
          (sum, app) => sum + calculateMonthlyCost((app.power * app.hoursPerDay * app.daysPerMonth) / 1000),
          0,
        )
        if (optionalCost > 500) {
          response.insights!.suggestions.push(
            `⏰ Optional appliances cost ${formatCurrency(optionalCost)}/month - use during off-peak hours`,
          )
        }
      }
    }

    // General recommendations if no specific data
    if ((!data.readings || data.readings.length < 2) && (!data.appliances || data.appliances.length === 0)) {
      response.recommendations = [
        `📈 Add meter readings to track consumption patterns and costs`,
        `🏠 Register appliances to get personalized cost-saving tips`,
        `⏰ Take readings at the same time daily for accurate tracking`,
        `💡 Start with high-cost appliances like AC, Water Heater, and Fridge`,
        `💰 Current rate: ${formatCurrency(ELECTRICITY_RATE_PER_KWH)}/kWh - optimize usage to save money`,
      ]
    }

    // Add seasonal tips with cost implications
    const currentMonth = new Date().getMonth()
    if (currentMonth >= 3 && currentMonth <= 6) {
      // Summer months (April-July)
      response.insights!.suggestions.push(`☀️ Summer tip: Use fans with AC to save ₹500-1000/month on cooling costs`)
    } else if (currentMonth >= 10 || currentMonth <= 1) {
      // Winter months (Nov-Feb)
      response.insights!.suggestions.push(`❄️ Winter tip: Use LED lights and heaters efficiently to save ₹300-500/month`)
    }

    return response
  }

  // All other methods remain the same but now use local analysis with Indian costs
  static async predictNextReading(readings: number[]): Promise<PredictionResponse> {
    if (readings.length < 2) {
      return {
        recommendations: [
          `📊 Add at least 2 meter readings to get cost predictions`,
          `💡 Tip: Track daily to understand your ${formatCurrency(ELECTRICITY_RATE_PER_KWH)}/kWh costs`,
        ],
        insights: {
          trend: "stable",
          efficiency: "average",
          suggestions: ["Start by recording your current meter reading, then add another reading tomorrow"],
        },
      }
    }

    return this.makeRequest({
      readings: readings.slice(-10),
      timeframe: "daily",
    })
  }

  static async getEfficiencyRecommendations(appliances: any[]): Promise<PredictionResponse> {
    if (appliances.length === 0) {
      return {
        recommendations: [
          `🏠 Add appliances to get personalized cost-saving recommendations`,
          `💡 Start with your biggest cost items: AC, Water Heater, Refrigerator`,
        ],
        insights: {
          trend: "stable",
          efficiency: "average",
          suggestions: [
            "Begin by adding appliances you use most frequently",
            "Check appliance labels for wattage information",
            `Current electricity rate: ${formatCurrency(ELECTRICITY_RATE_PER_KWH)}/kWh`,
          ],
        },
      }
    }

    return this.makeRequest({
      appliances: appliances.map((app) => ({
        name: app.name,
        power: app.power,
        hoursPerDay: app.hoursPerDay,
        daysPerMonth: app.daysPerMonth,
      })),
      timeframe: "monthly",
    })
  }

  static async analyzeUsagePattern(readings: number[]): Promise<PredictionResponse> {
    if (readings.length < 3) {
      return {
        insights: {
          trend: "stable",
          efficiency: "average",
          suggestions: ["Add more readings over the next few days to see cost patterns"],
        },
        recommendations: [`📈 Take readings for at least a week to identify cost-saving opportunities`],
      }
    }

    return this.makeRequest({
      readings: readings,
      timeframe: "weekly",
    })
  }

  static async getEnergyReport(readings: number[], appliances: any[]): Promise<PredictionResponse> {
    return this.makeRequest({
      readings: readings.slice(-30),
      appliances: appliances.map((app) => ({
        name: app.name,
        power: app.power,
        hoursPerDay: app.hoursPerDay,
        daysPerMonth: app.daysPerMonth,
      })),
      timeframe: "monthly",
    })
  }

  static async checkServiceHealth(): Promise<boolean> {
    // Always return false to indicate we're using local analysis
    return false
  }
}
