// Centralized error messages with actionable guidance
export const errorMessages = {
  // Firebase/Network errors
  firebase: {
    connectionFailed: {
      title: "Connection Failed",
      description: "Unable to connect to the database. Please check your internet connection and try again.",
      action: "Retry in a few seconds",
    },
    permissionDenied: {
      title: "Access Denied",
      description: "You don't have permission to perform this action. Please contact support if this continues.",
      action: "Contact support",
    },
    quotaExceeded: {
      title: "Storage Limit Reached",
      description: "Your data storage limit has been exceeded. Consider exporting old data or upgrading your plan.",
      action: "Export data or upgrade",
    },
  },

  // Form validation errors
  readings: {
    dateRequired: "Please select a date for your meter reading",
    dateInvalid: "Please enter a valid date (today or earlier)",
    dateFuture: "Meter reading date cannot be in the future",
    timeRequired: "Please enter the time when you took the reading",
    timeInvalid: "Please use 24-hour format (e.g., 14:30 for 2:30 PM)",
    readingRequired: "Please enter your meter reading value",
    readingInvalid: "Meter reading must be a positive number",
    readingTooLow: "This reading seems unusually low. Please double-check your meter",
    readingTooHigh: "This reading seems unusually high. Please verify the number",
    readingDecrease: "New reading cannot be lower than your previous reading. Please check your meter again.",
  },

  // Appliance validation errors
  appliances: {
    nameRequired: "Please enter a name for your appliance (e.g., 'Living Room TV')",
    nameExists: "An appliance with this name already exists. Try a different name or add a room/location.",
    powerRequired: "Please enter the power consumption in watts (check the appliance label)",
    powerInvalid: "Power must be a positive number (typically between 5W and 5000W)",
    powerTooHigh: "This power value seems very high. Most home appliances use less than 3000W.",
    hoursRequired: "Please enter how many hours per day this appliance runs",
    hoursInvalid: "Hours per day must be between 0 and 24",
    hoursUnrealistic: "This seems like a lot of daily usage. Double-check your estimate.",
    daysRequired: "Please enter how many days per month this appliance is used",
    daysInvalid: "Days per month must be between 0 and 31",
    categoryRequired: "Please select whether this appliance is essential or optional",
  },

  // Import/Export errors
  import: {
    noFile: "Please select a CSV file to import",
    invalidFormat: "This file format is not supported. Please use CSV (.csv) files only.",
    emptyFile: "The selected file appears to be empty. Please check your file and try again.",
    noValidRows: "No valid data found in your file. Please check the format and try again.",
    parseError: "Unable to read your file. Make sure it's a valid CSV with comma-separated values.",
    tooManyRows: "Your file contains too many rows. Please split it into smaller files (max 1000 rows).",
    duplicateData: "Some readings in your file already exist. Only new readings will be imported.",
  },

  export: {
    noData: "No data available to export. Add some meter readings first.",
    exportFailed: "Export failed. Please try again or contact support if the problem persists.",
  },

  // File format guidance
  csvFormat: {
    title: "CSV File Format Guide",
    requirements: [
      "Use comma-separated values (.csv format)",
      "Include headers: Date, Time, Reading",
      "Date format: YYYY-MM-DD (e.g., 2024-01-15)",
      "Time format: HH:MM (e.g., 09:30 or 21:45)",
      "Reading: Positive numbers only (e.g., 1250.5)",
    ],
    example: "Example row: 2024-01-15,09:30,1250.5",
  },
}

// Helper function to get user-friendly error message
export const getErrorMessage = (error: any) => {
  const errorCode = error?.code || error?.message || "unknown"

  // Firebase specific errors
  if (errorCode.includes("permission-denied")) {
    return errorMessages.firebase.permissionDenied
  }
  if (errorCode.includes("quota-exceeded")) {
    return errorMessages.firebase.quotaExceeded
  }
  if (errorCode.includes("network") || errorCode.includes("offline")) {
    return errorMessages.firebase.connectionFailed
  }

  // Default error
  return {
    title: "Something went wrong",
    description: "An unexpected error occurred. Please try again in a moment.",
    action: "Try again",
  }
}
