import { type ClassValue, clsx } from "clsx"
import { twMerge } from "tailwind-merge"
import { collection, query, orderBy, getDocs, doc, setDoc, getDoc } from "firebase/firestore"
import { db } from "./firebase"
import {
  calculateDailyCost,
  getBudgetStatus,
  DEFAULT_ELECTRICITY_RATE,
  predictNext7Days,
  calculateMonthlyCost,
} from "./constants"
import type { Appliance, MeterReading, UserSettings, DashboardSummary, AIInsight, MonthlyReport } from "./types"

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

// Calculate daily usage from readings
export function calculateDailyUsage(readings: MeterReading[], region = "Other"): MeterReading[] {
  if (readings.length < 2) return readings

  const sortedReadings = [...readings].sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime())

  return sortedReadings.map((reading, index) => {
    if (index === 0) {
      return { ...reading, dailyUsage: 0, dailyCost: 0 }
    }

    const prevReading = sortedReadings[index - 1]
    const dailyUsage = Math.max(0, reading.reading - prevReading.reading)
    const dailyCost = calculateDailyCost(dailyUsage, DEFAULT_ELECTRICITY_RATE, region)

    return { ...reading, dailyUsage, dailyCost }
  })
}

// Update getDashboardSummary function to use region-aware calculations
export function getDashboardSummary(readings: MeterReading[], settings: UserSettings): DashboardSummary {
  const readingsWithUsage = calculateDailyUsage(readings, settings.region)
  const today = new Date().toISOString().split("T")[0]
  const yesterday = new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString().split("T")[0]

  const todayReading = readingsWithUsage.find((r) => r.date === today)
  const yesterdayReading = readingsWithUsage.find((r) => r.date === yesterday)

  const todayUsage = todayReading?.dailyUsage || 0
  const todayCost = calculateDailyCost(todayUsage, settings.electricityRate, settings.region)
  const yesterdayUsage = yesterdayReading?.dailyUsage || 0
  const yesterdayCost = calculateDailyCost(yesterdayUsage, settings.electricityRate, settings.region)

  // Weekly average
  const lastWeek = readingsWithUsage.slice(-7)
  const weeklyTotal = lastWeek.reduce((sum, r) => sum + (r.dailyUsage || 0), 0)
  const weeklyAverage = weeklyTotal / Math.max(lastWeek.length, 1)

  // Monthly estimate using region-aware calculation
  const monthlyUsageEstimate = weeklyAverage * 30
  const monthlyEstimate = calculateMonthlyCost(monthlyUsageEstimate, settings.electricityRate, settings.region)

  // Budget calculations
  const daysInMonth = new Date(new Date().getFullYear(), new Date().getMonth() + 1, 0).getDate()
  const dailyBudget = settings.monthlyBudget / daysInMonth
  const budgetStatus = getBudgetStatus(todayCost, dailyBudget)

  // Remaining budget for the month
  const daysPassed = new Date().getDate()
  const usedBudget = daysPassed * dailyBudget
  const remainingBudget = settings.monthlyBudget - usedBudget

  // Savings compared to yesterday
  const savings = yesterdayCost - todayCost

  return {
    todayUsage,
    todayCost,
    yesterdayUsage,
    yesterdayCost,
    weeklyAverage,
    monthlyEstimate,
    budgetStatus: budgetStatus.status,
    budgetEmoji: budgetStatus.emoji,
    budgetMessage: budgetStatus.message,
    savings,
    daysInMonth,
    remainingBudget,
  }
}

// AI Analysis Engine
export function generateAIInsights(readings: MeterReading[], appliances: Appliance[]): AIInsight {
  const readingsWithUsage = calculateDailyUsage(readings, "Other")
  const recentReadings = readingsWithUsage.slice(-14) // Last 2 weeks

  // Trend analysis
  let trend: "increasing" | "decreasing" | "stable" = "stable"
  if (recentReadings.length >= 7) {
    const firstWeek = recentReadings.slice(0, 7)
    const secondWeek = recentReadings.slice(7, 14)

    const firstWeekAvg = firstWeek.reduce((sum, r) => sum + (r.dailyUsage || 0), 0) / firstWeek.length
    const secondWeekAvg = secondWeek.reduce((sum, r) => sum + (r.dailyUsage || 0), 0) / secondWeek.length

    if (secondWeekAvg > firstWeekAvg * 1.1) trend = "increasing"
    else if (secondWeekAvg < firstWeekAvg * 0.9) trend = "decreasing"
  }

  // Efficiency analysis
  const avgDailyUsage = recentReadings.reduce((sum, r) => sum + (r.dailyUsage || 0), 0) / recentReadings.length
  let efficiency: "good" | "average" | "poor" = "average"
  if (avgDailyUsage < 10) efficiency = "good"
  else if (avgDailyUsage > 20) efficiency = "poor"

  // Predictions
  const readingValues = readings.map((r) => r.reading)
  const predictions = predictNext7Days(readingValues)

  // Generate recommendations
  const recommendations = generateRecommendations(appliances, avgDailyUsage, trend)

  // Confidence based on data quality
  const confidence = Math.min(0.9, readings.length / 30) // Higher confidence with more data

  return {
    trend,
    efficiency,
    predictions,
    recommendations,
    confidence,
  }
}

// Generate smart recommendations
function generateRecommendations(appliances: Appliance[], avgDailyUsage: number, trend: string): string[] {
  const recommendations = []

  // High usage appliances
  const expensiveAppliances = appliances
    .filter((a) => a.monthlyCost > 500)
    .sort((a, b) => b.monthlyCost - a.monthlyCost)

  if (expensiveAppliances.length > 0) {
    const top = expensiveAppliances[0]
    const savings = Math.round(top.monthlyCost * 0.25)
    recommendations.push(
      `Reduce ${top.name} usage by 2 hours daily to save ₹${savings}/month. This is your highest cost appliance.`,
    )
  }

  // Trend-based recommendations
  if (trend === "increasing") {
    recommendations.push(
      "Your usage is increasing. Check for appliances left on unnecessarily or consider energy-efficient alternatives.",
    )
  }

  // Usage level recommendations
  if (avgDailyUsage > 15) {
    recommendations.push("High daily usage detected. Use appliances during off-peak hours (11 PM - 6 AM) to save 20%.")
  }

  // General tips
  recommendations.push("Switch to LED bulbs to save ₹100-200/month per bulb.")
  recommendations.push("Set AC temperature to 24°C instead of 18°C to save ₹500-800/month.")
  recommendations.push("Unplug electronics when not in use to save ₹50-100/month on standby power.")

  return recommendations.slice(0, 4) // Limit to 4 recommendations
}

// Generate monthly report
export function generateMonthlyReport(
  readings: MeterReading[],
  appliances: Appliance[],
  settings: UserSettings,
): MonthlyReport {
  const currentDate = new Date()
  const month = currentDate.toLocaleString("default", { month: "long" })
  const year = currentDate.getFullYear()

  const readingsWithUsage = calculateDailyUsage(readings, settings.region)
  const monthlyReadings = readingsWithUsage.filter((r) => {
    const readingDate = new Date(r.date)
    return readingDate.getMonth() === currentDate.getMonth() && readingDate.getFullYear() === year
  })

  const totalUsage = monthlyReadings.reduce((sum, r) => sum + (r.dailyUsage || 0), 0)
  const totalCost = totalUsage * settings.electricityRate
  const budgetUsed = (totalCost / settings.monthlyBudget) * 100
  const savings = Math.max(0, settings.monthlyBudget - totalCost)

  const topAppliances = appliances.sort((a, b) => b.monthlyCost - a.monthlyCost).slice(0, 5)

  const dailyBreakdown = monthlyReadings.map((r) => ({
    date: r.date,
    usage: r.dailyUsage || 0,
    cost: r.dailyCost || 0,
  }))

  const insights = generateAIInsights(readings, appliances)

  return {
    month,
    year,
    totalUsage,
    totalCost,
    budgetUsed,
    savings,
    topAppliances,
    dailyBreakdown,
    recommendations: insights.recommendations,
    trends: [`Usage trend: ${insights.trend}`, `Efficiency: ${insights.efficiency}`],
  }
}

// Fetch user settings
export const fetchUserSettings = async (): Promise<UserSettings> => {
  try {
    const docRef = doc(db, "settings", "user")
    const docSnap = await getDoc(docRef)

    if (docSnap.exists()) {
      const data = docSnap.data() as UserSettings
      // Calculate daily budget if not present
      if (!data.dailyBudget && data.monthlyBudget) {
        const daysInMonth = new Date(new Date().getFullYear(), new Date().getMonth() + 1, 0).getDate()
        data.dailyBudget = data.monthlyBudget / daysInMonth
      }
      return data
    }
  } catch (error) {
    console.error("Error fetching settings:", error)
  }

  return {
    monthlyBudget: 3000,
    electricityRate: DEFAULT_ELECTRICITY_RATE,
    region: "Other",
    dailyBudget: 100,
    onboardingComplete: false,
  }
}

// Save user settings
export const saveUserSettings = async (settings: UserSettings) => {
  try {
    // Calculate daily budget
    const daysInMonth = new Date(new Date().getFullYear(), new Date().getMonth() + 1, 0).getDate()
    settings.dailyBudget = settings.monthlyBudget / daysInMonth

    await setDoc(doc(db, "settings", "user"), settings)
  } catch (error) {
    console.error("Error saving settings:", error)
    throw error
  }
}

// Fetch readings
export const fetchReadings = async (): Promise<MeterReading[]> => {
  try {
    const q = query(collection(db, "readings"), orderBy("date", "desc"))
    const querySnapshot = await getDocs(q)
    return querySnapshot.docs.map((doc) => ({
      id: doc.id,
      ...doc.data(),
    })) as MeterReading[]
  } catch (error) {
    console.error("Error fetching readings:", error)
    return []
  }
}

// Fetch appliances
export const fetchAppliances = async (): Promise<Appliance[]> => {
  try {
    const q = query(collection(db, "appliances"), orderBy("monthlyCost", "desc"))
    const querySnapshot = await getDocs(q)
    return querySnapshot.docs.map((doc) => ({
      id: doc.id,
      ...doc.data(),
    })) as Appliance[]
  } catch (error) {
    console.error("Error fetching appliances:", error)
    return []
  }
}

// Export functions
export function exportToCSV(data: any[], filename: string) {
  const headers = Object.keys(data[0] || {})
  const csvContent = [headers.join(","), ...data.map((row) => headers.map((header) => row[header]).join(","))].join(
    "\n",
  )

  const blob = new Blob([csvContent], { type: "text/csv" })
  const url = URL.createObjectURL(blob)
  const a = document.createElement("a")
  a.href = url
  a.download = filename
  a.click()
  URL.revokeObjectURL(url)
}
