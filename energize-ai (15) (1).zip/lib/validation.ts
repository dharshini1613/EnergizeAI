import { errorMessages } from "./errorMessages"

export const validateMeterReading = (data: any, previousReading?: number) => {
  const errors: Record<string, string> = {}

  // Date validation
  if (!data.date) {
    errors.date = errorMessages.readings.dateRequired
  } else {
    const readingDate = new Date(data.date)
    const today = new Date()
    today.setHours(23, 59, 59, 999) // End of today

    if (isNaN(readingDate.getTime())) {
      errors.date = errorMessages.readings.dateInvalid
    } else if (readingDate > today) {
      errors.date = errorMessages.readings.dateFuture
    }
  }

  // Time validation
  if (!data.time) {
    errors.time = errorMessages.readings.timeRequired
  } else if (!/^([0-1]?[0-9]|2[0-3]):[0-5][0-9]$/.test(data.time)) {
    errors.time = errorMessages.readings.timeInvalid
  }

  // Reading validation
  if (data.reading === undefined || data.reading === null || data.reading === "") {
    errors.reading = errorMessages.readings.readingRequired
  } else {
    const reading = Number(data.reading)
    if (isNaN(reading) || reading < 0) {
      errors.reading = errorMessages.readings.readingInvalid
    } else if (reading < 10) {
      errors.reading = errorMessages.readings.readingTooLow
    } else if (reading > 999999) {
      errors.reading = errorMessages.readings.readingTooHigh
    } else if (previousReading && reading < previousReading) {
      errors.reading = errorMessages.readings.readingDecrease
    }
  }

  return errors
}

export const validateAppliance = (data: any, existingNames: string[] = []) => {
  const errors: Record<string, string> = {}

  // Name validation
  if (!data.name || data.name.trim().length === 0) {
    errors.name = errorMessages.appliances.nameRequired
  } else if (existingNames.includes(data.name.trim().toLowerCase())) {
    errors.name = errorMessages.appliances.nameExists
  }

  // Power validation
  if (!data.power && data.power !== 0) {
    errors.power = errorMessages.appliances.powerRequired
  } else {
    const power = Number(data.power)
    if (isNaN(power) || power <= 0) {
      errors.power = errorMessages.appliances.powerInvalid
    } else if (power > 5000) {
      errors.power = errorMessages.appliances.powerTooHigh
    }
  }

  // Hours validation
  if (data.hoursPerDay === undefined || data.hoursPerDay === null || data.hoursPerDay === "") {
    errors.hoursPerDay = errorMessages.appliances.hoursRequired
  } else {
    const hours = Number(data.hoursPerDay)
    if (isNaN(hours) || hours < 0 || hours > 24) {
      errors.hoursPerDay = errorMessages.appliances.hoursInvalid
    } else if (hours > 20) {
      errors.hoursPerDay = errorMessages.appliances.hoursUnrealistic
    }
  }

  // Days validation
  if (data.daysPerMonth === undefined || data.daysPerMonth === null || data.daysPerMonth === "") {
    errors.daysPerMonth = errorMessages.appliances.daysRequired
  } else {
    const days = Number(data.daysPerMonth)
    if (isNaN(days) || days < 0 || days > 31) {
      errors.daysPerMonth = errorMessages.appliances.daysInvalid
    }
  }

  // Category validation
  if (!data.category) {
    errors.category = errorMessages.appliances.categoryRequired
  }

  return errors
}

export const validateCSVRow = (row: string[], rowIndex: number) => {
  const errors: string[] = []

  if (row.length < 3) {
    errors.push(`Row ${rowIndex + 1}: Missing columns. Expected: Date, Time, Reading`)
    return { valid: false, errors }
  }

  const [date, time, readingStr] = row.map((col) => col.trim())

  // Date validation
  if (!date) {
    errors.push(`Row ${rowIndex + 1}: Date is required`)
  } else if (!Date.parse(date)) {
    errors.push(`Row ${rowIndex + 1}: Invalid date format. Use YYYY-MM-DD (e.g., 2024-01-15)`)
  } else {
    const readingDate = new Date(date)
    const today = new Date()
    if (readingDate > today) {
      errors.push(`Row ${rowIndex + 1}: Date cannot be in the future`)
    }
  }

  // Time validation
  if (!time) {
    errors.push(`Row ${rowIndex + 1}: Time is required`)
  } else if (!/^([0-1]?[0-9]|2[0-3]):[0-5][0-9]$/.test(time)) {
    errors.push(`Row ${rowIndex + 1}: Invalid time format. Use HH:MM (e.g., 09:30 or 21:45)`)
  }

  // Reading validation
  if (!readingStr) {
    errors.push(`Row ${rowIndex + 1}: Reading value is required`)
  } else {
    const reading = Number.parseFloat(readingStr)
    if (isNaN(reading)) {
      errors.push(`Row ${rowIndex + 1}: Reading must be a valid number`)
    } else if (reading < 0) {
      errors.push(`Row ${rowIndex + 1}: Reading cannot be negative`)
    } else if (reading > 999999) {
      errors.push(`Row ${rowIndex + 1}: Reading value seems unusually high`)
    }
  }

  return {
    valid: errors.length === 0,
    errors,
  }
}

// New function for validating appliance CSV rows
export const validateApplianceCSVRow = (row: string[], rowIndex: number, existingNames: string[] = []) => {
  const errors: string[] = []

  if (row.length < 5) {
    errors.push(`Row ${rowIndex + 1}: Missing columns. Expected: Name, Power(W), Hours/Day, Days/Month, Category`)
    return { valid: false, errors }
  }

  const [name, powerStr, hoursStr, daysStr, category] = row.map((col) => col.trim())

  // Name validation
  if (!name) {
    errors.push(`Row ${rowIndex + 1}: Appliance name is required`)
  } else if (name.length < 2) {
    errors.push(`Row ${rowIndex + 1}: Appliance name too short`)
  } else if (existingNames.includes(name.toLowerCase())) {
    errors.push(`Row ${rowIndex + 1}: Appliance "${name}" already exists`)
  }

  // Power validation
  if (!powerStr) {
    errors.push(`Row ${rowIndex + 1}: Power value is required`)
  } else {
    const power = Number.parseFloat(powerStr)
    if (isNaN(power)) {
      errors.push(`Row ${rowIndex + 1}: Power must be a valid number`)
    } else if (power <= 0) {
      errors.push(`Row ${rowIndex + 1}: Power must be greater than 0`)
    } else if (power > 5000) {
      errors.push(`Row ${rowIndex + 1}: Power value seems unusually high (>5000W)`)
    }
  }

  // Hours per day validation
  if (!hoursStr) {
    errors.push(`Row ${rowIndex + 1}: Hours per day is required`)
  } else {
    const hours = Number.parseFloat(hoursStr)
    if (isNaN(hours)) {
      errors.push(`Row ${rowIndex + 1}: Hours per day must be a valid number`)
    } else if (hours < 0 || hours > 24) {
      errors.push(`Row ${rowIndex + 1}: Hours per day must be between 0-24`)
    } else if (hours > 20) {
      errors.push(`Row ${rowIndex + 1}: Hours per day seems unusually high (>20h)`)
    }
  }

  // Days per month validation
  if (!daysStr) {
    errors.push(`Row ${rowIndex + 1}: Days per month is required`)
  } else {
    const days = Number.parseFloat(daysStr)
    if (isNaN(days)) {
      errors.push(`Row ${rowIndex + 1}: Days per month must be a valid number`)
    } else if (days < 0 || days > 31) {
      errors.push(`Row ${rowIndex + 1}: Days per month must be between 0-31`)
    }
  }

  // Category validation
  if (!category) {
    errors.push(`Row ${rowIndex + 1}: Category is required`)
  } else if (!["essential", "optional"].includes(category.toLowerCase())) {
    errors.push(`Row ${rowIndex + 1}: Category must be either "essential" or "optional"`)
  }

  return {
    valid: errors.length === 0,
    errors,
  }
}
