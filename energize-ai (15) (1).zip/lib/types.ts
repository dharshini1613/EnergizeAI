export interface MeterReading {
  id?: string
  date: string
  reading: number
  dailyUsage?: number
  dailyCost?: number
  createdAt?: Date
}

export interface Appliance {
  id?: string
  name: string
  power: number // watts
  hoursPerDay: number
  daysPerMonth: number
  monthlyKwh: number
  monthlyCost: number
  category: "essential" | "optional"
  createdAt?: Date
}

export interface UserSettings {
  monthlyBudget: number
  electricityRate: number
  region: string
  name?: string
  dailyBudget?: number
  onboardingComplete?: boolean
}

export interface DashboardSummary {
  todayUsage: number
  todayCost: number
  yesterdayUsage: number
  yesterdayCost: number
  weeklyAverage: number
  monthlyEstimate: number
  budgetStatus: "under" | "near" | "over"
  budgetEmoji: string
  budgetMessage: string
  savings: number
  daysInMonth: number
  remainingBudget: number
}

export interface AIInsight {
  trend: "increasing" | "decreasing" | "stable"
  efficiency: "good" | "average" | "poor"
  predictions: number[]
  recommendations: string[]
  confidence: number
}

export interface MonthlyReport {
  month: string
  year: number
  totalUsage: number
  totalCost: number
  budgetUsed: number
  savings: number
  topAppliances: Appliance[]
  dailyBreakdown: { date: string; usage: number; cost: number }[]
  recommendations: string[]
  trends: string[]
}
